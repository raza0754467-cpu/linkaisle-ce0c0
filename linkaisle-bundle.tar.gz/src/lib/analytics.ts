import crypto from 'node:crypto';
import { getDb } from './db';

export type AnalyticsEventType =
  | 'platform_visit'
  | 'store_visit'
  | 'product_impression'
  | 'product_click'
  | 'post_view';

export function detectReferrerSource(referrer: string | null | undefined, utmSource?: string | null): string {
  const combined = `${utmSource || ''} ${referrer || ''}`.toLowerCase();
  if (!combined.trim()) return 'Direct';
  if (combined.includes('tiktok')) return 'TikTok';
  if (combined.includes('facebook') || combined.includes('fb.') || combined.includes('fbclid')) return 'Facebook';
  if (combined.includes('instagram') || combined.includes('ig.')) return 'Instagram';
  if (combined.includes('youtube') || combined.includes('youtu.be')) return 'YouTube';
  if (combined.includes('pinterest') || combined.includes('pin.it')) return 'Pinterest';
  if (combined.includes('google.') || combined.includes('bing.') || combined.includes('duckduckgo')) return 'Google';
  if (combined.includes('localhost') || combined.includes('127.0.0.1')) return 'Direct';
  return 'Other';
}

export function hashVisitor(ip: string, userAgent: string): string {
  const day = new Date().toISOString().slice(0, 10);
  return crypto
    .createHash('sha256')
    .update(`${ip}|${userAgent}|${day}`)
    .digest('hex')
    .slice(0, 16);
}

export function detectVisitorCountry(headers: Headers, clientHint?: string | null): string {
  const cf = headers.get('cf-ipcountry');
  if (cf && cf !== 'XX' && cf.length === 2) return cf.toUpperCase();
  const vercel = headers.get('x-vercel-ip-country');
  if (vercel && vercel.length === 2) return vercel.toUpperCase();
  if (clientHint && /^[A-Za-z]{2,10}$/.test(clientHint.trim())) {
    return clientHint.trim().toUpperCase();
  }
  return 'Unknown';
}

export function recordAnalyticsEvent(params: {
  eventType: AnalyticsEventType;
  storeId?: string | null;
  productId?: string | null;
  postId?: string | null;
  referrerSource?: string;
  visitorHash?: string;
  country?: string;
}) {
  const db = getDb();
  const now = new Date().toISOString();
  const source = params.referrerSource || 'Direct';
  const visitorHash = params.visitorHash || 'anon';
  const country = params.country || 'Unknown';

  db.prepare(
    `INSERT INTO analytics_events (store_id, product_id, post_id, event_type, referrer_source, visitor_hash, country, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    params.storeId || null,
    params.productId || null,
    params.postId || null,
    params.eventType,
    source,
    visitorHash,
    country,
    now
  );

  if (params.eventType === 'product_impression' && params.productId) {
    db.prepare('UPDATE products SET impressions = impressions + 1 WHERE id = ?').run(params.productId);
  } else if (params.eventType === 'product_click' && params.productId) {
    db.prepare('UPDATE products SET clicks = clicks + 1 WHERE id = ?').run(params.productId);
  } else if (params.eventType === 'post_view' && params.postId) {
    db.prepare('UPDATE blog_posts SET views = views + 1 WHERE id = ?').run(params.postId);
  }
}

export function getStoreAnalytics(storeId: string) {
  const db = getDb();

  const totals = db
    .prepare(
      `SELECT
        SUM(CASE WHEN event_type = 'store_visit' THEN 1 ELSE 0 END) as store_visits,
        COUNT(DISTINCT CASE WHEN event_type = 'store_visit' THEN visitor_hash END) as unique_visitors,
        SUM(CASE WHEN event_type = 'product_impression' THEN 1 ELSE 0 END) as product_impressions,
        SUM(CASE WHEN event_type = 'product_click' THEN 1 ELSE 0 END) as product_clicks,
        SUM(CASE WHEN event_type = 'post_view' THEN 1 ELSE 0 END) as post_views
       FROM analytics_events
       WHERE store_id = ?`
    )
    .get(storeId) as {
      store_visits: number | null;
      unique_visitors: number | null;
      product_impressions: number | null;
      product_clicks: number | null;
      post_views: number | null;
    };

  const storeVisits = Number(totals?.store_visits || 0);
  const uniqueVisitors = Number(totals?.unique_visitors || 0);
  const productImpressions = Number(totals?.product_impressions || 0);
  const productClicks = Number(totals?.product_clicks || 0);
  const postViews = Number(totals?.post_views || 0);
  const ctr = productImpressions > 0 ? Number(((productClicks / productImpressions) * 100).toFixed(1)) : 0;

  // Last 14 days real activity
  const dailyRows = db
    .prepare(
      `SELECT
        substr(created_at, 1, 10) as day,
        SUM(CASE WHEN event_type = 'store_visit' THEN 1 ELSE 0 END) as visits,
        SUM(CASE WHEN event_type = 'product_impression' THEN 1 ELSE 0 END) as impressions,
        SUM(CASE WHEN event_type = 'product_click' THEN 1 ELSE 0 END) as clicks
       FROM analytics_events
       WHERE store_id = ?
       GROUP BY substr(created_at, 1, 10)
       ORDER BY day DESC
       LIMIT 14`
    )
    .all(storeId) as { day: string; visits: number; impressions: number; clicks: number }[];

  const dayMap = new Map(dailyRows.map((r) => [r.day, r]));
  const dailyTrend: { day: string; label: string; visits: number; impressions: number; clicks: number }[] = [];
  for (let i = 13; i >= 0; i--) {
    const d = new Date(Date.now() - i * 86400000);
    const iso = d.toISOString().slice(0, 10);
    const label = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    const row = dayMap.get(iso);
    dailyTrend.push({
      day: iso,
      label,
      visits: Number(row?.visits || 0),
      impressions: Number(row?.impressions || 0),
      clicks: Number(row?.clicks || 0),
    });
  }

  const referrers = db
    .prepare(
      `SELECT referrer_source as source, COUNT(*) as count
       FROM analytics_events
       WHERE store_id = ? AND event_type IN ('store_visit', 'product_click')
       GROUP BY referrer_source
       ORDER BY count DESC`
    )
    .all(storeId) as { source: string; count: number }[];

  const topProducts = db
    .prepare(
      `SELECT id, title, category, price_display, merchant_name, impressions, clicks, status
       FROM products
       WHERE store_id = ?
       ORDER BY clicks DESC, impressions DESC
       LIMIT 10`
    )
    .all(storeId) as {
      id: string;
      title: string;
      category: string;
      price_display: string;
      merchant_name: string;
      impressions: number;
      clicks: number;
      status: string;
    }[];

  const recentEvents = db
    .prepare(
      `SELECT e.id, e.event_type, e.referrer_source, e.created_at, p.title as product_title
       FROM analytics_events e
       LEFT JOIN products p ON p.id = e.product_id
       WHERE e.store_id = ?
       ORDER BY e.id DESC
       LIMIT 15`
    )
    .all(storeId) as {
      id: number;
      event_type: string;
      referrer_source: string;
      created_at: string;
      product_title: string | null;
    }[];

  const countries = db
    .prepare(
      `SELECT country, COUNT(*) as count
       FROM analytics_events
       WHERE store_id = ? AND event_type IN ('store_visit', 'product_click')
       GROUP BY country
       ORDER BY count DESC`
    )
    .all(storeId) as unknown as { country: string; count: number }[];

  return {
    summary: {
      storeVisits,
      uniqueVisitors,
      productImpressions,
      productClicks,
      postViews,
      ctr,
    },
    dailyTrend,
    referrers,
    countries,
    topProducts,
    recentEvents,
  };
}

export function getPlatformAdminAnalytics() {
  const db = getDb();

  const counts = db
    .prepare(
      `SELECT
        (SELECT COUNT(*) FROM users) as total_users,
        (SELECT COUNT(*) FROM stores) as total_stores,
        (SELECT COUNT(*) FROM stores WHERE is_published = 1 AND is_suspended = 0) as live_stores,
        (SELECT COUNT(*) FROM products) as total_products,
        (SELECT COUNT(*) FROM blog_posts) as total_posts,
        (SELECT COUNT(*) FROM academy_lessons WHERE is_published = 1) as total_lessons`
    )
    .get() as Record<string, number>;

  const events = db
    .prepare(
      `SELECT
        SUM(CASE WHEN event_type = 'platform_visit' THEN 1 ELSE 0 END) as platform_visits,
        SUM(CASE WHEN event_type = 'store_visit' THEN 1 ELSE 0 END) as all_store_visits,
        SUM(CASE WHEN event_type = 'product_impression' THEN 1 ELSE 0 END) as all_impressions,
        SUM(CASE WHEN event_type = 'product_click' THEN 1 ELSE 0 END) as all_clicks,
        COUNT(DISTINCT visitor_hash) as unique_visitors
       FROM analytics_events`
    )
    .get() as Record<string, number | null>;

  const topStores = db
    .prepare(
      `SELECT
        s.id, s.name, s.slug, s.template, s.is_published, s.is_suspended, u.name as owner_name, u.email as owner_email, u.plan as owner_plan,
        (SELECT COUNT(*) FROM products p WHERE p.store_id = s.id) as product_count,
        (SELECT COUNT(*) FROM analytics_events e WHERE e.store_id = s.id AND e.event_type = 'store_visit') as visits,
        (SELECT COUNT(*) FROM analytics_events e WHERE e.store_id = s.id AND e.event_type = 'product_impression') as impressions,
        (SELECT COUNT(*) FROM analytics_events e WHERE e.store_id = s.id AND e.event_type = 'product_click') as clicks
       FROM stores s
       JOIN users u ON u.id = s.user_id
       ORDER BY visits DESC, clicks DESC`
    )
    .all() as {
      id: string;
      name: string;
      slug: string;
      template: string;
      is_published: number;
      is_suspended: number;
      owner_name: string;
      owner_email: string;
      owner_plan: string;
      product_count: number;
      visits: number;
      impressions: number;
      clicks: number;
    }[];

  const referrers = db
    .prepare(
      `SELECT referrer_source as source, COUNT(*) as count
       FROM analytics_events
       WHERE event_type IN ('platform_visit', 'store_visit')
       GROUP BY referrer_source
       ORDER BY count DESC`
    )
    .all() as { source: string; count: number }[];

  return {
    counts,
    traffic: {
      platformVisits: Number(events?.platform_visits || 0),
      allStoreVisits: Number(events?.all_store_visits || 0),
      allImpressions: Number(events?.all_impressions || 0),
      allClicks: Number(events?.all_clicks || 0),
      uniqueVisitors: Number(events?.unique_visitors || 0),
    },
    topStores,
    referrers,
  };
}
