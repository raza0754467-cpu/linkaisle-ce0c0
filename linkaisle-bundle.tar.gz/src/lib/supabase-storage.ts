import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

function getConfig() {
  const url = (process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL || '')
    .trim()
    .replace(/\/$/, '');
  const serviceKey = (process.env.SUPABASE_SERVICE_ROLE_KEY || '').trim();
  return { url, serviceKey, ready: Boolean(url && serviceKey.length > 20) };
}

export function isSupabaseStorageReady(): boolean {
  return getConfig().ready;
}

/**
 * Cold-start synchronous hydration for serverless environments (Netlify / Vercel).
 * Runs ONCE per cold container boot before opening SQLite so all 40 sync DB callers
 * immediately see the latest permanent cloud database stored in Supabase.
 */
export function hydrateDbFromSupabaseSync(dbPath: string): boolean {
  const cfg = getConfig();
  if (!cfg.ready) return false;

  try {
    const dir = path.dirname(dbPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    const script = `
      const fs = require('fs');
      (async () => {
        const res = await fetch(process.env._SB_OBJ_URL, {
          headers: {
            apikey: process.env._SB_KEY,
            Authorization: 'Bearer ' + process.env._SB_KEY,
          },
        });
        if (res.status === 200) {
          const buf = Buffer.from(await res.arrayBuffer());
          if (buf.length > 4096) {
            fs.writeFileSync(process.env._SB_DB_PATH, buf);
            process.stdout.write('HYDRATED:' + buf.length);
            return;
          }
        }
        process.stdout.write('EMPTY:' + res.status);
      })().catch((e) => {
        process.stderr.write(String(e));
        process.exit(1);
      });
    `;

    const out = execFileSync(process.execPath, ['-e', script], {
      timeout: 6000,
      encoding: 'utf8',
      env: {
        ...process.env,
        _SB_OBJ_URL: `${cfg.url}/storage/v1/object/linkaisle-state/affiliforge.db`,
        _SB_KEY: cfg.serviceKey,
        _SB_DB_PATH: dbPath,
      },
    });
    return out.startsWith('HYDRATED:');
  } catch (err) {
    console.warn('[LinkAisle Supabase Hydrate] Falling back to fresh local DB:', err);
    return false;
  }
}

let inFlightUpload: Promise<boolean> | null = null;

/**
 * Persists the current SQLite database file cleanly to Supabase private bucket `linkaisle-state`.
 */
export async function uploadDbSnapshotToSupabase(dbPath: string): Promise<boolean> {
  const cfg = getConfig();
  if (!cfg.ready || !fs.existsSync(dbPath)) return false;

  if (inFlightUpload) {
    try {
      await inFlightUpload;
    } catch {}
  }

  const runUpload = (async () => {
    try {
      const buf = fs.readFileSync(dbPath);
      if (buf.length < 4096) return false;

      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 8000);
      const res = await fetch(`${cfg.url}/storage/v1/object/linkaisle-state/affiliforge.db`, {
        method: 'POST',
        signal: controller.signal,
        headers: {
          apikey: cfg.serviceKey,
          Authorization: `Bearer ${cfg.serviceKey}`,
          'Content-Type': 'application/octet-stream',
          'x-upsert': 'true',
        },
        body: buf,
      });
      clearTimeout(timer);
      if (!res.ok) {
        console.warn('[LinkAisle Supabase Sync] Upload status:', res.status);
        return false;
      }
      return true;
    } catch (err) {
      console.warn('[LinkAisle Supabase Sync] Upload failed:', err);
      return false;
    } finally {
      inFlightUpload = null;
    }
  })();

  inFlightUpload = runUpload;
  return runUpload;
}

/**
 * Uploads user product photos / store logos permanently to Supabase public bucket `linkaisle-uploads`.
 */
export async function uploadPublicImageToSupabase(
  filename: string,
  contentType: string,
  buffer: Buffer
): Promise<string | null> {
  const cfg = getConfig();
  if (!cfg.ready) return null;

  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    const res = await fetch(
      `${cfg.url}/storage/v1/object/linkaisle-uploads/${encodeURIComponent(filename)}`,
      {
        method: 'POST',
        signal: controller.signal,
        headers: {
          apikey: cfg.serviceKey,
          Authorization: `Bearer ${cfg.serviceKey}`,
          'Content-Type': contentType,
          'x-upsert': 'true',
        },
        body: new Uint8Array(buffer),
      }
    );
    clearTimeout(timer);
    if (!res.ok) return null;
    return `${cfg.url}/storage/v1/object/public/linkaisle-uploads/${encodeURIComponent(filename)}`;
  } catch {
    return null;
  }
}
