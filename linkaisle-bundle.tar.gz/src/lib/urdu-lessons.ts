export interface UrduLessonCopy {
  title_ur: string;
  summary_ur: string;
  content_ur: string;
}

export const URDU_ACADEMY_LESSONS: Record<string, UrduLessonCopy> = {
  'how-affiliate-marketing-works': {
    title_ur: 'Affiliate Marketing Asal Me Kaise Kaam Karti Hai (Step-by-Step)',
    summary_ur: 'Shuru se akhir tak samjhein ke affiliate program join karne se le kar clicks track karne aur commission kamane tak pura system kya hai.',
    content_ur: `## Asal System Kya Hai\nAffiliate marketing me aap doosri badi companies ke products recommend karte hain — bina apna stock khareede, bina delivery sambhale, aur bina customer payment handle kiye.\n\n## 5 Aasan Steps\n1. **Affiliate Program Join Karein** (jaise Amazon Associates, Impact.com, ya Daraz Affiliate).\n2. **Apna Special Tracking Link Hasil Karein** har eligible product ke liye.\n3. **Apne AffiliForge Store Par Products Lagayein** clean photo aur faydon ke sath.\n4. **Sahi Visitors Layein** TikTok, Reels, YouTube Shorts, SEO blog, ya policy-safe ads ke zariye.\n5. **Qualifying Sale Par Commission Kamayein** jo seedha aap ke affiliate network dashboard me show hota hai.\n\n## Zaroori Sachai\nTraffic ya clicks ka matlab guaranteed sale nahi hota. Hamesha **Gross Commission** aur **Net Profit** (marketing/domain kharcha nikalne ke baad) ka farq yaad rakhein.`,
  },
  'affiliate-programs-and-approval-guide': {
    title_ur: 'Affiliate Programs (Amazon, Impact & Brands) Se Approval Kaise Lein',
    summary_ur: 'Affiliate companies naye logo ko approve karne se pehle kya check karti hain aur ek clean storefront approval me kaise madad karta hai.',
    content_ur: `## Applications Reject Kyun Hoti Hain?\nBadi affiliate companies check karti hain ke kya aap ke paas ek asli, saaf-suthri, aur useful website hai jahan customers ko waqai faida mile.\n\n## Apply Karne Se Pehle Checklist\n- Kam az kam **5 se 10 real products** ek clear niche (jaise Kitchen ya Tech) me publish karein.\n- Apne store ke Blog section me **2 se 3 original buying guides** likhein.\n- Store ke footer me clear **Affiliate Disclosure** aur **Contact Email** zaroor rakhein (AffiliForge me yeh built-in hai).\n- Kabhi bhi jhooti kamai ka wada na karein aur doosro ka description copy-paste na karein.\n\n## Mashhoor Affiliate Networks\n- **Impact.com:** Hazaron international brands ke affiliate programs ek hi jagah milte hain.\n- **Amazon Associates:** Bohat zyada products, lekin apply karne se pehle unke current rules (ads, disclosures, images) zaroor parhein.\n- **Daraz Affiliate:** Pakistan me local practice aur pehli kamai test karne ke liye acha option hai.`,
  },
  'multi-product-collection-strategy': {
    title_ur: 'Multi-Product Collection Strategy (1 Video/Ad Se Kayi Products)',
    summary_ur: 'Sirf 1 product promote karne ke bajaye 10 products ka curated store page banana zyada smart kyun hai.',
    content_ur: `## Sirf 1 Product Link Me Nuqsan Kya Hai?\nAgar aap ek video bana kar sirf 1 product ka link dein, aur dekhne wale ko wo pasand na aaye (ya us ke paas pehle se ho), to wo visitor zaya ho jata hai.\n\n## Curated Storefront Se Faida Kaise Barhta Hai?\nJab aap visitor ko ek category store par bhejte hain (maslan *"5 Useful Kitchen Gadgets"*), to wo ek hi visit me 6 se 10 related cheezein dekhta hai. Agar Product #1 nahi liya, to Product #3 ya #5 pasand aa sakta hai.\n\n## Behtareen Niches\n- **Home & Kitchen Gadgets:** 15-second video me dikhana bohat aasan hota hai.\n- **Home Office & Tech:** Inki qeemat zyada hoti hai, is liye commission bhi acha mil sakta hai.\n- **Pet Accessories:** Pet owners bar-bar khareedari karte hain.\n- **Organizers & Beauty:** TikTok, Reels aur Pinterest par tezi se viral hote hain.`,
  },
  'building-high-converting-storefront': {
    title_ur: 'High-Trust Storefront Design Aur Sacha Product Copy Likhna',
    summary_ur: 'Product cards, fayday (benefits), aur clear buttons aise kaise banayein ke visitor trust kar ke click kare.',
    content_ur: `## Ache Product Card Ke 4 Hissay\n1. **Saaf Title:** Seedha batayein product kya hai aur kis kaam aata hai.\n2. **Saaf Photo:** Authorized aur clear image lagayein.\n3. **3–4 Short Benefits:** Factory specs nahi, yeh batayein ke yeh product roz-marra ki kaunsi mushkil hal karta hai.\n4. **Clear CTA Button:** *"Check Price on Amazon"* jaisa clear button trust barhata hai.\n\n## Disclosure Lazmi Rakhein\nVisitor ko hamesha saaf batayein ke yeh affiliate links hain. Is se trust banta hai aur FTC/Amazon rules bhi pure hote hain.`,
  },
  'free-organic-traffic-short-videos': {
    title_ur: '0 Rupay Traffic: TikTok, Reels, YouTube Shorts Aur Pinterest',
    summary_ur: 'Bina paid ads par paisa kharch kiye USA aur international customers tak free me kaise pohanchein.',
    content_ur: `## 0 Budget Se Shuruat\nShuru me ads par paisa lagane ki zaroorat nahi. Short vertical videos (20 seconds) aur Pinterest pins bilkul free me international buyers tak pohanch sakte hain.\n\n## 20-Second Video Formula\n- **0–3 Second (Hook):** Roz ki koi chhoti problem dikhayein (*"Kitchen drawer hamesha bikhra rehta hai?"*).\n- **3–15 Second (Solution):** 3 useful gadgets jaldi se dikhayein.\n- **15–20 Second (CTA):** Bio me apne store link par bhejein (*"Teeno gadgets mere Smart Home store list me mojood hain"*).\n\n## Traffic Source Track Karein\nAffiliForge ke **Marketing Kit** se har platform ka alag tracked link (\`?src=tiktok\`, \`?src=facebook\`) copy karein taake Analytics me dikhe kis app se zyada clicks aaye.`,
  },
  'seo-blogging-for-affiliate-stores': {
    title_ur: 'SEO Blogging: Google Search Se Free Visitors Lana',
    summary_ur: 'Useful comparison articles likh kar aur unke andar apne store products embed kar ke lambay arsay tak free traffic hasil karein.',
    content_ur: `## Store Ke Sath Blog Kyun Zaroori Hai?\nSocial media videos kuch din chal kar ruk jati hain, lekin ek acha SEO article (*"Best Eye-Care Desk Lamps Under $50"*) mahino tak Google se free visitors la sakta hai.\n\n## AffiliForge Blog Tips\n- Aise specific sawalat par likhein jo khareedne wale log Google par search karte hain.\n- Har post me apna **SEO Title** aur **SEO Meta Description** zaroor bharein.\n- Post ke andar **Embed Store Products** select karein taake parhne wala wahin se deal par click kar sake.`,
  },
  'paid-ads-and-policy-compliance': {
    title_ur: 'International Paid Ads Aur Affiliate Rules (Ahem Ehtiyat)',
    summary_ur: 'Facebook, TikTok ya Google Ads par ek bhi rupiya lagane se pehle kaunse rules check karna zaroori hain.',
    content_ur: `## Bina Rules Parhe Ads Kabhi Na Chalayein\nInternational audiences (jaise USA) ko Meta ya TikTok ads chalane se pehle apne affiliate program ki latest policy zaroor check karein.\n\n## Aam Ghalatiyan Jin Se Account Ban Ho Sakta Hai\n- **Direct Linking Ban:** Zyada tar affiliate programs direct ad-to-affiliate-link ki ijazat nahi dete — ek original curated website (jaise aap ka AffiliForge store) chahiye hota hai.\n- **Brand Name Bidding:** Google Ads me kisi brand ke trademark naam par bina permission bid na karein.\n- **Ad Arbitrage Risk:** Raptive ya Mediavine jaise ad networks low-quality paid traffic par account suspend kar sakte hain — kabhi fake ya sasta bot traffic na khareedein.\n\n## Chhotay Test Se Shuru Karein\nPaid ads tabhi test karein jab aap ka store pehle organic visitors par clicks aur interest dikha chuka ho.`,
  },
  'understanding-analytics-revenue-vs-profit': {
    title_ur: 'Real Analytics Samajhna: Impressions, Clicks, CTR Aur Net Profit',
    summary_ur: 'Apne AffiliForge dashboard ke real numbers aur Amazon/Impact dashboard ke numbers ko mila kar sahi faislay kaise karein.',
    content_ur: `## Har Affiliate Ke 2 Dashboards Hote Hain\n1. **AffiliForge Studio Dashboard:** Yahan aap ke 100% real **Store Visits, Product Impressions, Outbound Clicks, CTR %, aur Traffic Sources** dikhte hain.\n2. **Affiliate Network Dashboard (Amazon/Impact):** Yahan asli **Sales, Approved Commissions, Returns, aur Payouts** dikhte hain.\n\n## Outbound CTR Formula\n\`CTR = (Outbound Clicks / Product Impressions) × 100\`\nAgar log store par aa rahe hain lekin click nahi kar rahe, to photos aur headlines behtar karein. Agar clicks zyada hain lekin sale nahi ho rahi, to zyada trusted aur ache reviews wale products lagayein.\n\n## Asli Munafa (Net Profit)\n\`Net Profit = Approved Commissions - (Ads + Domain/Tools + Refunds)\``,
  },
};
