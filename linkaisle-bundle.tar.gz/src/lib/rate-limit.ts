interface Bucket {
  count: number;
  resetAt: number;
}

declare global {
  // eslint-disable-next-line no-var
  var __affiliforgeRateLimit: Map<string, Bucket> | undefined;
}

const store = global.__affiliforgeRateLimit || new Map<string, Bucket>();
global.__affiliforgeRateLimit = store;

export function checkRateLimit(
  key: string,
  maxRequests = 25,
  windowMs = 15 * 60 * 1000
): { allowed: boolean; remaining: number; retryAfterSeconds: number } {
  const now = Date.now();
  const existing = store.get(key);

  if (!existing || existing.resetAt <= now) {
    store.set(key, { count: 1, resetAt: now + windowMs });
    return { allowed: true, remaining: maxRequests - 1, retryAfterSeconds: 0 };
  }

  if (existing.count >= maxRequests) {
    return {
      allowed: false,
      remaining: 0,
      retryAfterSeconds: Math.ceil((existing.resetAt - now) / 1000),
    };
  }

  existing.count += 1;
  return { allowed: true, remaining: maxRequests - existing.count, retryAfterSeconds: 0 };
}
