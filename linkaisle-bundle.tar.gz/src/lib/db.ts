import { DatabaseSync } from 'node:sqlite';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { DEFAULT_PLAN_LIMITS, MonetizationConfig, PlanLimits } from './types';
import { URDU_ACADEMY_LESSONS } from './urdu-lessons';
import {
  hydrateDbFromSupabaseSync,
  isSupabaseStorageReady,
  uploadDbSnapshotToSupabase,
} from './supabase-storage';

const IS_SERVERLESS = Boolean(
  process.env.VERCEL || process.env.NETLIFY || process.env.AWS_LAMBDA_FUNCTION_NAME
);
const DATA_DIR = IS_SERVERLESS
  ? path.join(os.tmpdir(), 'linkaisle-data')
  : path.join(process.cwd(), 'data');
const DB_PATH = path.join(DATA_DIR, 'affiliforge.db');

declare global {
  // eslint-disable-next-line no-var
  var __affiliforgeDb: DatabaseSync | undefined;
}

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const parts = stored.split(':');
  if (parts.length !== 2) return false;
  const [salt, keyHex] = parts;
  const derived = crypto.scryptSync(password, salt, 64);
  const keyBuf = Buffer.from(keyHex, 'hex');
  if (derived.length !== keyBuf.length) return false;
  return crypto.timingSafeEqual(derived, keyBuf);
}

export function createId(prefix: string): string {
  return `${prefix}_${crypto.randomBytes(8).toString('hex')}`;
}

export function slugify(input: string): string {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60) || `item-${crypto.randomBytes(3).toString('hex')}`;
}

function initSchema(db: DatabaseSync) {
  db.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;

    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user',
      plan TEXT NOT NULL DEFAULT 'free',
      status TEXT NOT NULL DEFAULT 'active',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sessions (
      token TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS stores (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      slug TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      tagline TEXT NOT NULL DEFAULT '',
      description TEXT NOT NULL DEFAULT '',
      template TEXT NOT NULL DEFAULT 'kitchen',
      primary_color TEXT NOT NULL DEFAULT '#4f46e5',
      accent_color TEXT NOT NULL DEFAULT '#10b981',
      logo_url TEXT NOT NULL DEFAULT '',
      hero_title TEXT NOT NULL DEFAULT '',
      hero_subtitle TEXT NOT NULL DEFAULT '',
      hero_cta TEXT NOT NULL DEFAULT 'Explore Top Picks',
      disclosure_text TEXT NOT NULL DEFAULT 'As an affiliate partner, we may earn a small commission on qualifying purchases made through links on this site at no extra cost to you.',
      contact_email TEXT NOT NULL DEFAULT '',
      social_tiktok TEXT NOT NULL DEFAULT '',
      social_instagram TEXT NOT NULL DEFAULT '',
      social_youtube TEXT NOT NULL DEFAULT '',
      social_facebook TEXT NOT NULL DEFAULT '',
      is_published INTEGER NOT NULL DEFAULT 1,
      is_suspended INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS products (
      id TEXT PRIMARY KEY,
      store_id TEXT NOT NULL,
      title TEXT NOT NULL,
      slug TEXT NOT NULL,
      category TEXT NOT NULL DEFAULT 'General',
      price_display TEXT NOT NULL DEFAULT '$29.99',
      original_price TEXT NOT NULL DEFAULT '',
      image_url TEXT NOT NULL DEFAULT '',
      short_description TEXT NOT NULL DEFAULT '',
      description TEXT NOT NULL DEFAULT '',
      benefits TEXT NOT NULL DEFAULT '[]',
      affiliate_url TEXT NOT NULL,
      merchant_name TEXT NOT NULL DEFAULT 'Amazon',
      badge TEXT NOT NULL DEFAULT '',
      is_featured INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'published',
      impressions INTEGER NOT NULL DEFAULT 0,
      clicks INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS blog_posts (
      id TEXT PRIMARY KEY,
      store_id TEXT NOT NULL,
      title TEXT NOT NULL,
      slug TEXT NOT NULL,
      excerpt TEXT NOT NULL DEFAULT '',
      content TEXT NOT NULL DEFAULT '',
      cover_image TEXT NOT NULL DEFAULT '',
      category TEXT NOT NULL DEFAULT 'Guides',
      seo_title TEXT NOT NULL DEFAULT '',
      seo_description TEXT NOT NULL DEFAULT '',
      featured_product_ids TEXT NOT NULL DEFAULT '[]',
      status TEXT NOT NULL DEFAULT 'published',
      views INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS analytics_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      store_id TEXT,
      product_id TEXT,
      post_id TEXT,
      event_type TEXT NOT NULL,
      referrer_source TEXT NOT NULL DEFAULT 'Direct',
      visitor_hash TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_analytics_store_date ON analytics_events(store_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_analytics_type_date ON analytics_events(event_type, created_at);
    CREATE INDEX IF NOT EXISTS idx_products_store ON products(store_id);
    CREATE INDEX IF NOT EXISTS idx_posts_store ON blog_posts(store_id);

    CREATE TABLE IF NOT EXISTS academy_lessons (
      id TEXT PRIMARY KEY,
      module_number INTEGER NOT NULL,
      order_index INTEGER NOT NULL,
      slug TEXT NOT NULL UNIQUE,
      title TEXT NOT NULL,
      summary TEXT NOT NULL,
      content TEXT NOT NULL,
      duration_minutes INTEGER NOT NULL DEFAULT 6,
      level TEXT NOT NULL DEFAULT 'Beginner',
      is_published INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS platform_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
  `);
}

function seedIfNeeded(db: DatabaseSync) {
  const existingUsers = db.prepare('SELECT COUNT(*) as count FROM users').get() as { count: number };
  if (existingUsers.count > 0) return;

  const now = new Date().toISOString();

  // 1. Platform Settings
  const upsertSetting = db.prepare('INSERT OR REPLACE INTO platform_settings (key, value) VALUES (?, ?)');
  upsertSetting.run('platform_name', 'LinkAisle');
  upsertSetting.run('platform_tagline', 'Build your affiliate product store in minutes.');
  upsertSetting.run('plan_limits', JSON.stringify(DEFAULT_PLAN_LIMITS));
  upsertSetting.run('allow_registrations', 'true');

  // 2. Platform Owner Super Admin (No temporary demo accounts)
  const adminId = 'usr_admin_001';

  const insertUser = db.prepare(`
    INSERT INTO users (id, name, email, password_hash, role, plan, status, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);

  insertUser.run(
    adminId,
    'Raza (Platform Owner)',
    'raza0754467@gmail.com',
    hashPassword('Admin@1234'),
    'admin',
    'pro',
    'active',
    now
  );

  // 3. Official Example Published Store (Owned by Platform Owner)
  const demoStoreId = 'str_demo_001';
  db.prepare(`
    INSERT INTO stores (
      id, user_id, slug, name, tagline, description, template,
      primary_color, accent_color, logo_url, hero_title, hero_subtitle, hero_cta,
      disclosure_text, contact_email, social_tiktok, social_instagram, social_youtube, social_facebook,
      is_published, is_suspended, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    demoStoreId,
    adminId,
    'smart-home-finds',
    'Smart Home Finds',
    'Practical kitchen & home gadgets curated for modern living.',
    'We test and curate problem-solving home and kitchen upgrades that actually save time every day.',
    'kitchen',
    '#c2410c',
    '#15803d',
    '',
    'Smart Kitchen & Home Finds That Actually Save Time',
    'One curated collection of high-utility home gadgets, desk essentials, and organizers — handpicked with transparent affiliate links.',
    'Browse Curated Deals',
    'Affiliate Disclosure: Smart Home Finds participates in affiliate programs. When you click an external deal link and make a qualifying purchase, we may earn a commission at no additional cost to you.',
    'hello@smarthomefinds.example',
    'https://tiktok.com',
    'https://instagram.com',
    'https://youtube.com',
    '',
    1,
    0,
    now,
    now
  );

  // 4. Demo Curated Products (Real impressions=0, clicks=0 initially!)
  const insertProduct = db.prepare(`
    INSERT INTO products (
      id, store_id, title, slug, category, price_display, original_price,
      image_url, short_description, description, benefits, affiliate_url,
      merchant_name, badge, is_featured, status, impressions, clicks, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, ?, ?)
  `);

  const demoProducts = [
    {
      id: 'prd_demo_01',
      title: 'Precision Digital Kitchen Scale (0.1g Accuracy)',
      slug: 'precision-digital-kitchen-scale',
      category: 'Kitchen',
      price_display: '$24.99',
      original_price: '$34.99',
      image_url: 'https://images.unsplash.com/photo-1585515320310-259814833e62?auto=format&fit=crop&w=800&q=80',
      short_description: 'Slim stainless-steel scale with instant tare, backlit LCD, and 5 measurement units.',
      description: 'Built for meal prep, pour-over coffee, and baking accuracy. Features a spill-resistant brushed stainless platform and auto-shutoff battery saver.',
      benefits: ['0.1g precision for coffee & baking', 'Easy-clean stainless steel platform', 'Instant zero/tare button', 'Compact drawer-friendly slim profile'],
      affiliate_url: 'https://www.amazon.com/s?k=digital+kitchen+scale',
      merchant_name: 'Amazon',
      badge: 'Best Seller',
      is_featured: 1,
    },
    {
      id: 'prd_demo_02',
      title: 'Handheld Rechargeable Milk Frother Wand',
      slug: 'rechargeable-milk-frother-wand',
      category: 'Coffee & Tea',
      price_display: '$19.50',
      original_price: '$27.00',
      image_url: 'https://images.unsplash.com/photo-1517701604599-bb29b565090c?auto=format&fit=crop&w=800&q=80',
      short_description: 'USB-C rechargeable 3-speed frother that makes cafe-style microfoam in 15 seconds.',
      description: 'Skip disposable AA batteries. This whisper-quiet stainless whisk creates thick foam for lattes, iced matcha, and protein shakes in seconds.',
      benefits: ['USB-C rechargeable (no battery waste)', '3 speed settings for latte or matcha', 'Includes stainless countertop stand', 'Rinses clean in 5 seconds'],
      affiliate_url: 'https://www.amazon.com/s?k=rechargeable+milk+frother',
      merchant_name: 'Amazon',
      badge: 'Viral Pick',
      is_featured: 1,
    },
    {
      id: 'prd_demo_03',
      title: 'Airtight Pantry Storage Container Set (14-Piece)',
      slug: 'airtight-pantry-storage-set',
      category: 'Organization',
      price_display: '$38.99',
      original_price: '$49.99',
      image_url: 'https://images.unsplash.com/photo-1584568694244-14fbdf83bd30?auto=format&fit=crop&w=800&q=80',
      short_description: 'Stackable BPA-free clear containers with silicone locking lids and chalkboard labels.',
      description: 'Transform cluttered shelves into a clean, visible pantry. Universal lid sizes mean you never hunt for matching covers again.',
      benefits: ['Silicone-sealed airtight freshness', 'Stackable space-saving geometry', 'Includes reusable labels & marker', 'Dishwasher-safe BPA-free body'],
      affiliate_url: 'https://www.amazon.com/s?k=airtight+pantry+containers',
      merchant_name: 'Impact Partner',
      badge: 'Top Rated',
      is_featured: 1,
    },
    {
      id: 'prd_demo_04',
      title: 'Expandable Bamboo Drawer Organizer',
      slug: 'expandable-bamboo-drawer-organizer',
      category: 'Organization',
      price_display: '$29.95',
      original_price: '$39.00',
      image_url: 'https://images.unsplash.com/photo-1556911220-bff31c812dba?auto=format&fit=crop&w=800&q=80',
      short_description: 'Adjustable 6-to-8 slot eco-friendly bamboo cutlery tray that fits almost any kitchen drawer.',
      description: 'Glides smoothly from 13 to 19.6 inches wide so your utensils stay neatly separated without sliding around every time you open the drawer.',
      benefits: ['Expands smoothly from 13" to 19.6"', 'Water-resistant natural bamboo', 'Deep slots hold full cutlery sets', 'Zero tools required to fit'],
      affiliate_url: 'https://www.amazon.com/s?k=expandable+bamboo+drawer+organizer',
      merchant_name: 'Amazon',
      badge: '',
      is_featured: 0,
    },
    {
      id: 'prd_demo_05',
      title: 'LED Monitor Light Bar & Eye-Care Desk Lamp',
      slug: 'led-monitor-light-bar',
      category: 'Home Office',
      price_display: '$44.00',
      original_price: '$59.00',
      image_url: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=800&q=80',
      short_description: 'Zero-glare asymmetric lighting that clips onto your screen and frees up desk space.',
      description: 'Illuminates your keyboard and notebook evenly without reflecting on your monitor. Adjustable warm-to-cool color temperatures reduce late-night eye fatigue.',
      benefits: ['Zero screen glare optical design', 'Saves 100% of desk lamp footprint', 'Stepless warm/cool dimming knob', 'USB powered directly from monitor'],
      affiliate_url: 'https://www.amazon.com/s?k=monitor+light+bar',
      merchant_name: 'Amazon',
      badge: 'Editor Choice',
      is_featured: 1,
    },
    {
      id: 'prd_demo_06',
      title: 'Single-Serve Precision Pour-Over Coffee Maker',
      slug: 'precision-pour-over-coffee-maker',
      category: 'Coffee & Tea',
      price_display: '$34.50',
      original_price: '$45.00',
      image_url: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=800&q=80',
      short_description: 'Borosilicate glass carafe with reusable double-mesh stainless filter for rich morning brews.',
      description: 'Enjoy clean, aromatic coffee without paper filters. Heat-resistant collar lets you pour comfortably straight from counter to mug.',
      benefits: ['Paperless stainless steel micro-filter', 'Thick borosilicate heat-proof glass', 'Brews 1 to 3 cups in under 3 minutes', 'Dishwasher safe'],
      affiliate_url: 'https://www.amazon.com/s?k=pour+over+coffee+maker+glass',
      merchant_name: 'Impact Partner',
      badge: 'New',
      is_featured: 0,
    },
  ];

  for (const p of demoProducts) {
    insertProduct.run(
      p.id,
      demoStoreId,
      p.title,
      p.slug,
      p.category,
      p.price_display,
      p.original_price,
      p.image_url,
      p.short_description,
      p.description,
      JSON.stringify(p.benefits),
      p.affiliate_url,
      p.merchant_name,
      p.badge,
      p.is_featured,
      'published',
      now,
      now
    );
  }

  // 5. Demo SEO Blog Articles
  const insertPost = db.prepare(`
    INSERT INTO blog_posts (
      id, store_id, title, slug, excerpt, content, cover_image, category,
      seo_title, seo_description, featured_product_ids, status, views, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'published', 0, ?, ?)
  `);

  insertPost.run(
    'pst_demo_01',
    demoStoreId,
    '5 Under-$45 Kitchen Upgrades That Actually Save Time Every Morning',
    '5-kitchen-upgrades-that-save-time',
    'Skip gimmicky gadgets. Here are five practical kitchen tools that speed up morning coffee, meal prep, and pantry organization.',
    `Most viral kitchen gadgets end up buried in the back of a cabinet after one week. Instead of novelty tools, the highest-value upgrades fix small daily friction points.\n\n## 1. Upgrade Your Morning Coffee Routine\nA rechargeable milk frother and a clean pour-over carafe let you make coffeehouse drinks at home in under three minutes—without bulky machines crowding your counter.\n\n## 2. Weigh Ingredients Once, Clean Fewer Dishes\nA precision digital kitchen scale replaces half a drawer of measuring cups. Place your bowl directly on the scale, hit tare, and measure directly into the mix.\n\n## 3. Visibility Prevents Food Waste\nMoving dry staples into uniform airtight containers makes grocery planning effortless because you immediately see what is running low.\n\n## Final Checklist Before Buying\nAlways measure your drawer depth and shelf height before ordering organizers, and look for stainless steel or borosilicate glass parts that last for years.`,
    'https://images.unsplash.com/photo-1556910103-1c02745aae4d?auto=format&fit=crop&w=1000&q=80',
    'Kitchen Guides',
    '5 Practical Kitchen Upgrades Under $45 (2026 Buyer Guide)',
    'Discover five practical, time-saving kitchen gadgets under $45 including digital scales, frothers, and pantry storage.',
    JSON.stringify(['prd_demo_01', 'prd_demo_02', 'prd_demo_03']),
    now,
    now
  );

  insertPost.run(
    'pst_demo_02',
    demoStoreId,
    'How to Build a Glare-Free Home Desk Setup for Late-Night Work',
    'glare-free-home-desk-setup',
    'Eye strain ruins focus. Learn how asymmetric monitor lighting and simple cable-free organization make your desk calmer and sharper.',
    `Working late under harsh ceiling lights causes glare on glossy screens and fast eye fatigue. The fix does not require an expensive office remodel.\n\n## Why Asymmetric Lighting Matters\nUnlike traditional desk lamps that shine sideways into your screen, a clip-on monitor light bar aims light downward onto your keyboard and notebook while keeping the display completely glare-free.\n\n## Keep Your Surface Clear\nPair vertical lighting with a slim drawer organizer so everyday tools stay within reach without cluttering your visual field.`,
    'https://images.unsplash.com/photo-1499750310107-5fef28a66643?auto=format&fit=crop&w=1000&q=80',
    'Home Office',
    'Glare-Free Desk Lighting Guide for Remote Workers',
    'Learn how monitor light bars and minimalist desk organization prevent eye strain and save desk space.',
    JSON.stringify(['prd_demo_05', 'prd_demo_04']),
    now,
    now
  );

  // 6. Affiliate Academy Lessons (8 structured lessons covering the exact handover roadmap)
  const insertLesson = db.prepare(`
    INSERT INTO academy_lessons (
      id, module_number, order_index, slug, title, summary, content,
      duration_minutes, level, is_published, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
  `);

  const lessons = [
    {
      id: 'les_01',
      module_number: 1,
      order_index: 1,
      slug: 'how-affiliate-marketing-works',
      title: 'How Affiliate Marketing Actually Works (Step-by-Step)',
      summary: 'Understand the exact flow from choosing a program to sharing links, tracking clicks, and earning qualifying commissions.',
      duration_minutes: 5,
      level: 'Beginner',
      content: `## The Core Mechanism\nAffiliate marketing lets you recommend products from established brands without buying inventory, handling shipping, or processing customer payments.\n\n## The 5-Step Flow\n1. **Join an affiliate program** (such as Amazon Associates, Impact.com, or brand partner portals).\n2. **Generate your unique tracking link** for eligible products.\n3. **Publish products on your curated storefront** using AffiliForge.\n4. **Bring interested visitors** through helpful short videos, SEO articles, or compliant ads.\n5. **Earn commission on qualifying purchases** tracked inside your affiliate partner's dashboard.\n\n## Important Reality Check\nTraffic and clicks do not automatically guarantee sales. Always distinguish between **gross commissions** and **net profit** after deducting any marketing, domain, or tool expenses.`,
    },
    {
      id: 'les_02',
      module_number: 1,
      order_index: 2,
      slug: 'affiliate-programs-and-approval-guide',
      title: 'Applying to Affiliate Programs (Amazon, Impact & Brand Partners)',
      summary: 'What affiliate networks look for before approving beginners and how a clean storefront improves approval chances.',
      duration_minutes: 7,
      level: 'Beginner',
      content: `## Why Applications Get Rejected\nAffiliate networks review whether you have a real, original, policy-compliant destination where customers genuinely benefit from your recommendations.\n\n## Before You Apply Checklist\n- Publish **5 to 10 real curated products** in one focused niche.\n- Write **2 to 3 original buying guides** in your store's Blog section.\n- Include a clear **Affiliate Disclosure** and **Contact Email** (built automatically into every AffiliForge store).\n- Never promise guaranteed outcomes or copy/paste copyrighted descriptions word-for-word.\n\n## Major Networks to Research\n- **Impact.com:** Marketplace connecting publishers with thousands of international software and consumer brands.\n- **Amazon Associates:** Broad product selection; always read current Operating Agreement rules on paid ads, disclosures, and image usage.\n- **Local Regional Programs:** Programs like Daraz Affiliate (for South Asia) can be great for testing your first clicks locally.`,
    },
    {
      id: 'les_03',
      module_number: 2,
      order_index: 3,
      slug: 'multi-product-collection-strategy',
      title: 'The Multi-Product Collection Strategy (1 Entry Point, Many Choices)',
      summary: 'Why sending visitors to a curated collection page beats promoting just one single item.',
      duration_minutes: 6,
      level: 'Beginner',
      content: `## Why Single-Product Links Waste Visitors\nIf you make a video or post for one $30 item and a visitor already owns it, you lose that visitor immediately.\n\n## How Collection Storefronts Multiply Opportunities\nWhen you send visitors to a **category storefront** (e.g., *"Top 10 Time-Saving Kitchen Upgrades"*), visitors browse 6–10 related items in one visit. Even if they skip Product #1, Product #4 or #6 might be exactly what they need.\n\n## Best Niches for Curated Stores\n- **Home & Kitchen Gadgets:** Easy to demonstrate visually in 15-second videos.\n- **Desk & Remote-Work Tech:** Higher average order values.\n- **Pet Essentials:** Passionate repeat buyers.\n- **Beauty & Everyday Organizers:** High shareability on TikTok, Reels, and Pinterest.`,
    },
    {
      id: 'les_04',
      module_number: 2,
      order_index: 4,
      slug: 'building-high-converting-storefront',
      title: 'Designing Your Storefront & Writing Honest Product Copy',
      summary: 'How to structure product cards, benefits, and disclosures so visitors trust your links.',
      duration_minutes: 6,
      level: 'Beginner',
      content: `## Anatomy of a High-Trust Product Listing\n1. **Clear Title:** State what the product is and its main hook.\n2. **Crisp Image:** Use authorized/clean imagery that matches the product.\n3. **3–4 Scannable Benefits:** Focus on the problem it solves, not boring factory specs.\n4. **Clear CTA Button:** Use transparent buttons like *"View Deal on Amazon"* rather than misleading traps.\n\n## Always Include Disclosures\nTrust is long-term revenue. Both FTC regulations and affiliate program agreements require clear disclosure that outbound links may earn a commission.`,
    },
    {
      id: 'les_05',
      module_number: 3,
      order_index: 5,
      slug: 'free-organic-traffic-short-videos',
      title: 'Zero-Budget Traffic: TikTok, Instagram Reels, Shorts & Pinterest',
      summary: 'How to drive consistent international visitors to your storefront without spending money on ads.',
      duration_minutes: 8,
      level: 'Intermediate',
      content: `## Starting at $0 Ad Budget\nYou do not need paid ads to validate your niche. Short-form vertical video and visual search platforms can reach international buyers for free.\n\n## Repeatable 20-Second Video Formula\n- **0–3s Hook:** Show the everyday annoyance (*"Tired of cluttered kitchen drawers?"*).\n- **3–15s Solution:** Show 3 curated gadgets solving the problem cleanly.\n- **15–20s CTA:** Direct viewers to your curated store link in bio (*"All 3 are organized in my Smart Home list"*).\n\n## Tracking Which Platform Works Best\nAffiliForge automatically detects incoming referrer sources (**TikTok, Facebook, Instagram, YouTube, Pinterest, Google**) so your Analytics dashboard shows exactly where your real clicks come from.`,
    },
    {
      id: 'les_06',
      module_number: 3,
      order_index: 6,
      slug: 'seo-blogging-for-affiliate-stores',
      title: 'SEO Blogging: Bringing Free Google Search Traffic to Your Store',
      summary: 'How to write comparison guides and embed affiliate products inside articles for compounding search visits.',
      duration_minutes: 7,
      level: 'Intermediate',
      content: `## Why Pair a Storefront with a Blog?\nSocial videos spike fast and fade in days. Helpful SEO articles (*"Best Glare-Free Desk Lamps for Night Work"*) can bring search visitors month after month.\n\n## Practical SEO Rules Inside AffiliForge\n- Target **specific buyer-intent questions**, not impossible broad keywords.\n- Fill out custom **SEO Title** and **SEO Meta Description** in your Blog Manager.\n- Attach **Featured Store Products** directly inside each blog post so readers can click out naturally while reading.`,
    },
    {
      id: 'les_07',
      module_number: 4,
      order_index: 7,
      slug: 'paid-ads-and-policy-compliance',
      title: 'International Paid Ads & Affiliate Compliance Rules',
      summary: 'Critical rules to check before ever spending a single dollar on Meta, TikTok, or Google Ads.',
      duration_minutes: 8,
      level: 'Pro',
      content: `## Never Run Paid Ads Blindly\nBefore running international campaigns (e.g., targeting USA audiences via Meta Ads Manager), verify every rule in your affiliate program's current agreement.\n\n## Common Policy Traps to Avoid\n- **Direct Linking Bans:** Many programs forbid sending paid ad clicks directly to an affiliate link; a value-adding collection website with original content is typically required.\n- **Brand Bidding Restrictions:** Never bid on trademarked merchant names in search ads without written permission.\n- **Display Ad Arbitrage Risks:** Premium display ad networks (like Mediavine or Raptive) have strict traffic-quality and authenticity policies — never buy low-quality traffic expecting guaranteed ad arbitrage profits.\n\n## Start Small & Measure\nOnly test paid ads after your storefront already converts organic visitors, and always set strict daily spend caps.`,
    },
    {
      id: 'les_08',
      module_number: 4,
      order_index: 8,
      slug: 'understanding-analytics-revenue-vs-profit',
      title: 'Reading Analytics: Impressions, Clicks, CTR & Real Net Profit',
      summary: 'Learn how to interpret your store dashboard metrics alongside external affiliate network reports.',
      duration_minutes: 6,
      level: 'Pro',
      content: `## Two Dashboards Every Affiliate Tracks\n1. **Your Store Dashboard (AffiliForge):** Tracks real Store Visits, Product Impressions, Outbound Affiliate Clicks, CTR %, and Traffic Sources.\n2. **Your Affiliate Network Dashboard (Amazon/Impact):** Tracks final Purchases, Approved Commissions, Returns, and Payouts.\n\n## Key Metric: Outbound CTR\n\`CTR = (Outbound Clicks / Product Impressions) × 100\`\nIf people visit your store but rarely click products, improve your product images, prices, or headlines. If they click often but nobody buys on the merchant's site, pick better-reviewed products with stronger buyer intent.\n\n## Always Calculate Net Profit\n\`Net Profit = Approved Commissions - (Ad Spend + Domain/Tools + Refunds)\``,
    },
  ];

  for (const lesson of lessons) {
    insertLesson.run(
      lesson.id,
      lesson.module_number,
      lesson.order_index,
      lesson.slug,
      lesson.title,
      lesson.summary,
      lesson.content,
      lesson.duration_minutes,
      lesson.level,
      now
    );
  }
}

function runMigrations(db: DatabaseSync) {
  const cols = db.prepare('PRAGMA table_info(academy_lessons)').all() as { name: string }[];
  const names = new Set(cols.map((c) => c.name));
  if (!names.has('title_ur')) {
    db.exec(`ALTER TABLE academy_lessons ADD COLUMN title_ur TEXT NOT NULL DEFAULT ''`);
  }
  if (!names.has('summary_ur')) {
    db.exec(`ALTER TABLE academy_lessons ADD COLUMN summary_ur TEXT NOT NULL DEFAULT ''`);
  }
  if (!names.has('content_ur')) {
    db.exec(`ALTER TABLE academy_lessons ADD COLUMN content_ur TEXT NOT NULL DEFAULT ''`);
  }

  const updateUrdu = db.prepare(
    `UPDATE academy_lessons
     SET title_ur = ?, summary_ur = ?, content_ur = ?
     WHERE slug = ? AND (title_ur = '' OR content_ur = '')`
  );
  for (const [slug, copy] of Object.entries(URDU_ACADEMY_LESSONS)) {
    updateUrdu.run(copy.title_ur, copy.summary_ur, copy.content_ur, slug);
  }

  // Step 3: Owner Monetization Engine tables (idempotent)
  db.exec(`
    CREATE TABLE IF NOT EXISTS upgrade_requests (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      requested_plan TEXT NOT NULL,
      billing_cycle TEXT NOT NULL DEFAULT 'monthly',
      amount_usd REAL NOT NULL DEFAULT 0,
      payment_method TEXT NOT NULL,
      transaction_ref TEXT NOT NULL,
      notes TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'pending',
      admin_note TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      reviewed_at TEXT NOT NULL DEFAULT '',
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS partner_tools (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      category TEXT NOT NULL DEFAULT 'Affiliate Networks',
      tagline TEXT NOT NULL DEFAULT '',
      description TEXT NOT NULL DEFAULT '',
      affiliate_url TEXT NOT NULL,
      commission_note TEXT NOT NULL DEFAULT '',
      badge TEXT NOT NULL DEFAULT '',
      clicks INTEGER NOT NULL DEFAULT 0,
      is_published INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL
    );
  `);

  const toolCount = db.prepare('SELECT COUNT(*) as count FROM partner_tools').get() as { count: number };
  if (toolCount.count === 0) {
    const now = new Date().toISOString();
    const insertTool = db.prepare(
      `INSERT INTO partner_tools (
        id, name, category, tagline, description, affiliate_url, commission_note, badge, clicks, is_published, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 1, ?)`
    );

    const defaultTools = [
      {
        id: 'tl_impact',
        name: 'Impact.com',
        category: 'Affiliate Networks',
        tagline: 'Connect with 1,000+ global consumer & SaaS affiliate brands.',
        description: 'Apply to international brands from one publisher dashboard, track conversions, and withdraw commissions globally.',
        affiliate_url: 'https://impact.com',
        commission_note: 'Replace with your Impact referral link in Admin Panel',
        badge: 'Top Network',
      },
      {
        id: 'tl_amazon',
        name: 'Amazon Associates',
        category: 'Affiliate Networks',
        tagline: 'Promote millions of everyday kitchen, home, and tech products.',
        description: 'High buyer trust across the USA and international markets. Review current Operating Agreement policies before running paid ads.',
        affiliate_url: 'https://affiliate-program.amazon.com',
        commission_note: 'Direct official portal',
        badge: 'Beginner Friendly',
      },
      {
        id: 'tl_canva',
        name: 'Canva',
        category: 'Design & Video',
        tagline: 'Create short vertical videos, thumbnails, and store logos for free.',
        description: 'Design TikTok/Reels product showcases and clean storefront branding in minutes without design software.',
        affiliate_url: 'https://www.canva.com',
        commission_note: 'Replace with your Canva affiliate link in Admin Panel',
        badge: 'Free Tier',
      },
      {
        id: 'tl_namecheap',
        name: 'Namecheap Domains',
        category: 'Domains & Hosting',
        tagline: 'Register a custom .com domain (~$10–$15/year) when ready to scale.',
        description: 'Move from free subdomains to your own branded .com domain once your traffic and store clicks start growing.',
        affiliate_url: 'https://www.namecheap.com',
        commission_note: 'Replace with your Namecheap affiliate link in Admin Panel',
        badge: 'Custom Domain',
      },
      {
        id: 'tl_cloudflare',
        name: 'Cloudflare Pages',
        category: 'Domains & Hosting',
        tagline: 'Fast global web hosting & DNS with a generous commercial-friendly free tier.',
        description: 'Deploy storefronts globally with free SSL, fast edge caching, and clean custom domain routing.',
        affiliate_url: 'https://pages.cloudflare.com',
        commission_note: 'Free infrastructure tool',
        badge: '$0 Hosting',
      },
      {
        id: 'tl_ga4',
        name: 'Google Analytics (GA4)',
        category: 'Analytics & SEO',
        tagline: 'Free real-time visitor geography, device, and audience insights.',
        description: 'Pair GA4 with AffiliForge real click tracking to inspect USA vs. global visitor behavior in detail.',
        affiliate_url: 'https://analytics.google.com',
        commission_note: '100% Free Google tool',
        badge: 'Essential',
      },
    ];

    for (const t of defaultTools) {
      insertTool.run(
        t.id,
        t.name,
        t.category,
        t.tagline,
        t.description,
        t.affiliate_url,
        t.commission_note,
        t.badge,
        now
      );
    }
  }

  // Default Step 3 Monetization Settings (inserted only if missing)
  const ensureSetting = db.prepare('INSERT OR IGNORE INTO platform_settings (key, value) VALUES (?, ?)');
  ensureSetting.run('ads_enabled', 'false');
  ensureSetting.run('ad_network_label', 'Sponsored Partner / Ad Slot');
  ensureSetting.run('ad_sponsor_title', 'Ready for Custom Domain & Premium Affiliate Tools?');
  ensureSetting.run(
    'ad_sponsor_desc',
    'Explore our verified zero-to-pro affiliate toolkit including Impact.com, Canva, and affordable domains.'
  );
  ensureSetting.run('ad_sponsor_cta_text', 'Explore Partner Toolkit');
  ensureSetting.run('ad_sponsor_cta_url', '/tools');
  ensureSetting.run(
    'payment_instructions',
    'Send your subscription amount via Payoneer, Local Bank Transfer, or Easypaisa/JazzCash, then submit your Transaction Reference ID below. The platform owner verifies and upgrades your plan within 24 hours.'
  );

  // Country targeting & availability + Owner email migration (idempotent)
  const storeCols = new Set(
    (db.prepare('PRAGMA table_info(stores)').all() as { name: string }[]).map((c) => c.name)
  );
  if (!storeCols.has('target_country')) {
    db.exec(`ALTER TABLE stores ADD COLUMN target_country TEXT NOT NULL DEFAULT 'US'`);
  }
  if (!storeCols.has('currency')) {
    db.exec(`ALTER TABLE stores ADD COLUMN currency TEXT NOT NULL DEFAULT 'USD'`);
  }

  const productCols = new Set(
    (db.prepare('PRAGMA table_info(products)').all() as { name: string }[]).map((c) => c.name)
  );
  if (!productCols.has('available_countries')) {
    db.exec(`ALTER TABLE products ADD COLUMN available_countries TEXT NOT NULL DEFAULT '["US","CA","UK"]'`);
    // Give demo products realistic varied target countries
    db.prepare(`UPDATE products SET available_countries = '["US","CA","UK"]' WHERE id IN ('prd_demo_01','prd_demo_02')`).run();
    db.prepare(`UPDATE products SET available_countries = '["GLOBAL"]' WHERE id IN ('prd_demo_03','prd_demo_05')`).run();
    db.prepare(`UPDATE products SET available_countries = '["US","UK","AE","PK"]' WHERE id IN ('prd_demo_04','prd_demo_06')`).run();
  }

  const analyticsCols = new Set(
    (db.prepare('PRAGMA table_info(analytics_events)').all() as { name: string }[]).map((c) => c.name)
  );
  if (!analyticsCols.has('country')) {
    db.exec(`ALTER TABLE analytics_events ADD COLUMN country TEXT NOT NULL DEFAULT 'Unknown'`);
  }

  // Update seeded owner account email to raza0754467@gmail.com
  const oldAdmin = db.prepare(`SELECT id FROM users WHERE id = 'usr_admin_001' AND email = 'admin@affiliforge.local'`).get();
  if (oldAdmin) {
    const emailTaken = db.prepare(`SELECT id FROM users WHERE email = 'raza0754467@gmail.com'`).get();
    if (!emailTaken) {
      db.prepare(`UPDATE users SET email = 'raza0754467@gmail.com', name = 'Raza (Platform Owner)' WHERE id = 'usr_admin_001'`).run();
    }
  }

  // Upgrade platform branding to LinkAisle & keep beginner /tools free of domain/hosting confusion
  db.prepare(`UPDATE platform_settings SET value = 'LinkAisle' WHERE key = 'platform_name' AND value = 'AffiliForge'`).run();
  db.prepare(`UPDATE platform_settings SET value = 'Build your affiliate product store in minutes.' WHERE key = 'platform_tagline'`).run();
  db.prepare(`DELETE FROM partner_tools WHERE id IN ('tl_namecheap', 'tl_cloudflare')`).run();

  const ensureTool = db.prepare(
    `INSERT OR IGNORE INTO partner_tools (
      id, name, category, tagline, description, affiliate_url, commission_note, badge, clicks, is_published, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 1, ?)`
  );
  const nowIso = new Date().toISOString();
  ensureTool.run(
    'tl_daraz',
    'Daraz Affiliate Program',
    'Affiliate Networks',
    'Promote thousands of products across Pakistan & South Asia.',
    'Easy beginner approval for creators targeting shoppers in Pakistan. Copy product links directly into your LinkAisle store.',
    'https://www.daraz.pk/wow/gcp/daraz/channel/pk/affiliate/affiliate-program',
    'Local Pakistan network',
    'Pakistan Friendly',
    nowIso
  );
  ensureTool.run(
    'tl_capcut',
    'CapCut Video Editor',
    'Design & Video',
    'Edit fast TikTok, Instagram Reels & YouTube Shorts product videos on mobile.',
    'Free mobile and desktop video editor ideal for creating 15–20 second product showcases that drive visitors to your store link.',
    'https://www.capcut.com',
    'Free mobile video tool',
    'Free App',
    nowIso
  );

  // Migrate demo creator account to clean temp email test@linkaisle.local / Test@1234
  const oldDemo = db.prepare(`SELECT id FROM users WHERE id = 'usr_demo_001' AND email = 'demo@affiliforge.local'`).get();
  if (oldDemo) {
    const taken = db.prepare(`SELECT id FROM users WHERE email = 'test@linkaisle.local'`).get();
    if (!taken) {
      db.prepare(
        `UPDATE users SET email = 'test@linkaisle.local', name = 'Test Creator', password_hash = ? WHERE id = 'usr_demo_001'`
      ).run(hashPassword('Test@1234'));
    }
  }

  // Ensure demo store has 8 products (2 full clean rows of 4 on desktop!)
  const ensureDemoProduct = db.prepare(
    `INSERT OR IGNORE INTO products (
      id, store_id, title, slug, category, price_display, original_price,
      image_url, short_description, description, benefits, available_countries, affiliate_url,
      merchant_name, badge, is_featured, status, impressions, clicks, created_at, updated_at
    ) VALUES (?, 'str_demo_001', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'published', 0, 0, ?, ?)`
  );
  ensureDemoProduct.run(
    'prd_demo_07',
    'Magnetic Under-Cabinet Motion LED Strip (3-Pack)',
    'magnetic-motion-led-strip',
    'Kitchen',
    '$26.99',
    '$36.00',
    'https://images.unsplash.com/photo-1565814329452-e1efa11c5b89?auto=format&fit=crop&w=800&q=80',
    'USB-C rechargeable warm-white sensor lights that snap onto any kitchen cabinet in 10 seconds.',
    'Brighten dark countertops and closets automatically when you walk by. Magnetic backing makes recharging effortless without removing any brackets.',
    JSON.stringify(['No wiring or drilling needed', 'Auto motion sensor saves battery', 'Warm & neutral light modes', 'USB-C fast rechargeable']),
    JSON.stringify(['US', 'CA', 'UK', 'AE']),
    'https://www.amazon.com/s?k=under+cabinet+motion+led+lights',
    'Amazon',
    'Popular',
    0,
    nowIso,
    nowIso
  );
  ensureDemoProduct.run(
    'prd_demo_08',
    'Foldable Aluminum Laptop Riser Stand',
    'foldable-aluminum-laptop-stand',
    'Home Office',
    '$22.50',
    '$32.00',
    'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?auto=format&fit=crop&w=800&q=80',
    'Ergonomic 6-angle ventilated aluminum stand that improves posture and cools your laptop.',
    'Lifts your screen to eye level to stop neck strain during long workdays, then folds flat into a slim sleeve for travel or office commutes.',
    JSON.stringify(['Fits 10" to 17" laptops', 'Solid brushed aluminum frame', 'Open airflow cooling design', 'Folds flat for backpacks']),
    JSON.stringify(['GLOBAL']),
    'https://www.amazon.com/s?k=foldable+aluminum+laptop+stand',
    'Impact Partner',
    'Top Pick',
    0,
    nowIso,
    nowIso
  );

  // Price Reviser & Listing Quality columns on products (idempotent)
  const pColsNow = new Set(
    (db.prepare('PRAGMA table_info(products)').all() as { name: string }[]).map((c) => c.name)
  );
  if (!pColsNow.has('rating')) {
    db.exec(`ALTER TABLE products ADD COLUMN rating REAL NOT NULL DEFAULT 4.7`);
  }
  if (!pColsNow.has('review_count')) {
    db.exec(`ALTER TABLE products ADD COLUMN review_count INTEGER NOT NULL DEFAULT 142`);
  }
  if (!pColsNow.has('last_checked_at')) {
    db.exec(`ALTER TABLE products ADD COLUMN last_checked_at TEXT NOT NULL DEFAULT ''`);
  }
  if (!pColsNow.has('price_status')) {
    db.exec(`ALTER TABLE products ADD COLUMN price_status TEXT NOT NULL DEFAULT 'unverified'`);
  }
  if (!pColsNow.has('last_price_note')) {
    db.exec(`ALTER TABLE products ADD COLUMN last_price_note TEXT NOT NULL DEFAULT ''`);
  }
  if (!pColsNow.has('quality_score')) {
    db.exec(`ALTER TABLE products ADD COLUMN quality_score INTEGER NOT NULL DEFAULT 88`);
  }

  // Real Password Reset Tokens & Real Product Buyer Reviews tables
  db.exec(`
    CREATE TABLE IF NOT EXISTS password_resets (
      token TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      used INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS product_reviews (
      id TEXT PRIMARY KEY,
      product_id TEXT NOT NULL,
      author_name TEXT NOT NULL,
      rating INTEGER NOT NULL DEFAULT 5,
      comment TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_reviews_product ON product_reviews(product_id, created_at);
  `);

  const pColsExtra = new Set(
    (db.prepare('PRAGMA table_info(products)').all() as { name: string }[]).map((c) => c.name)
  );
  if (!pColsExtra.has('asin')) {
    db.exec(`ALTER TABLE products ADD COLUMN asin TEXT NOT NULL DEFAULT ''`);
  }
  if (!pColsExtra.has('amazon_marketplace')) {
    db.exec(`ALTER TABLE products ADD COLUMN amazon_marketplace TEXT NOT NULL DEFAULT ''`);
  }
  if (!pColsExtra.has('sales_rank')) {
    db.exec(`ALTER TABLE products ADD COLUMN sales_rank TEXT NOT NULL DEFAULT ''`);
  }
  if (!pColsExtra.has('availability_status')) {
    db.exec(`ALTER TABLE products ADD COLUMN availability_status TEXT NOT NULL DEFAULT ''`);
  }

  // Clean up temporary local test account if present, preserving flagship store under Owner
  const tempUser = db
    .prepare("SELECT id FROM users WHERE email = 'test@linkaisle.local'")
    .get() as { id: string } | undefined;
  if (tempUser) {
    db.prepare("UPDATE stores SET user_id = 'usr_admin_001' WHERE user_id = ?").run(tempUser.id);
    db.prepare('DELETE FROM sessions WHERE user_id = ?').run(tempUser.id);
    db.prepare('DELETE FROM users WHERE id = ?').run(tempUser.id);
  }
}

export async function persistDbToCloud(): Promise<void> {
  if (!isSupabaseStorageReady()) return;
  try {
    await uploadDbSnapshotToSupabase(DB_PATH);
  } catch {}
}

export function getDb(): DatabaseSync {
  if (!global.__affiliforgeDb) {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    const hydratedFromCloud =
      IS_SERVERLESS && !fs.existsSync(DB_PATH)
        ? hydrateDbFromSupabaseSync(DB_PATH)
        : false;
    const db = new DatabaseSync(DB_PATH);
    initSchema(db);
    seedIfNeeded(db);
    runMigrations(db);
    global.__affiliforgeDb = db;
    if (IS_SERVERLESS && !hydratedFromCloud && isSupabaseStorageReady()) {
      void uploadDbSnapshotToSupabase(DB_PATH);
    }
  }
  return global.__affiliforgeDb;
}

export function getPlatformSettings(): {
  platform_name: string;
  platform_tagline: string;
  plan_limits: PlanLimits;
  allow_registrations: boolean;
  monetization: MonetizationConfig;
} {
  const db = getDb();
  const rows = db.prepare('SELECT key, value FROM platform_settings').all() as { key: string; value: string }[];
  const map = new Map(rows.map((r) => [r.key, r.value]));

  let planLimits = DEFAULT_PLAN_LIMITS;
  try {
    const raw = map.get('plan_limits');
    if (raw) planLimits = JSON.parse(raw);
  } catch {
    planLimits = DEFAULT_PLAN_LIMITS;
  }

  return {
    platform_name: map.get('platform_name') || 'LinkAisle',
    platform_tagline: map.get('platform_tagline') || 'Build your affiliate product store in minutes.',
    plan_limits: planLimits,
    allow_registrations: (map.get('allow_registrations') || 'true') === 'true',
    monetization: {
      ads_enabled: (map.get('ads_enabled') || 'false') === 'true',
      ad_network_label: map.get('ad_network_label') || 'Sponsored Partner / Ad Slot',
      ad_sponsor_title: map.get('ad_sponsor_title') || 'Explore Verified Affiliate Tools',
      ad_sponsor_desc:
        map.get('ad_sponsor_desc') ||
        'Discover free and low-cost tools recommended inside our Partner Toolkit.',
      ad_sponsor_cta_text: map.get('ad_sponsor_cta_text') || 'View Toolkit',
      ad_sponsor_cta_url: map.get('ad_sponsor_cta_url') || '/tools',
      payment_instructions:
        map.get('payment_instructions') ||
        'Submit your payment method and transaction reference below to upgrade your plan.',
    },
  };
}
