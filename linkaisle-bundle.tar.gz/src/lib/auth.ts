import crypto from 'node:crypto';
import { cookies } from 'next/headers';
import { getDb, persistDbToCloud, refreshDbFromCloudSync } from './db';
import { User } from './types';

export const SESSION_COOKIE = 'affiliforge_session';
const SESSION_TTL_DAYS = 14;

export async function createSession(userId: string): Promise<string> {
  const db = getDb();
  const token = crypto.randomBytes(32).toString('hex');
  const now = new Date();
  const expires = new Date(now.getTime() + SESSION_TTL_DAYS * 24 * 60 * 60 * 1000);

  db.prepare(
    'INSERT INTO sessions (token, user_id, expires_at, created_at) VALUES (?, ?, ?, ?)'
  ).run(token, userId, expires.toISOString(), now.toISOString());

  await persistDbToCloud();

  const cookieStore = await cookies();
  cookieStore.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    expires,
  });

  return token;
}

export async function destroySession(): Promise<void> {
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_COOKIE)?.value;
  if (token) {
    const db = getDb();
    db.prepare('DELETE FROM sessions WHERE token = ?').run(token);
    await persistDbToCloud();
  }
  cookieStore.delete(SESSION_COOKIE);
}

export async function getCurrentUser(): Promise<User | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_COOKIE)?.value;
  if (!token) return null;

  let db = getDb();
  let row = db
    .prepare(
      `SELECT u.id, u.name, u.email, u.role, u.plan, u.status, u.created_at, s.expires_at
       FROM sessions s
       JOIN users u ON u.id = s.user_id
       WHERE s.token = ?`
    )
    .get(token) as (User & { expires_at: string }) | undefined;

  // On serverless, if another container just created this session, pull latest cloud snapshot once
  if (!row && refreshDbFromCloudSync()) {
    db = getDb();
    row = db
      .prepare(
        `SELECT u.id, u.name, u.email, u.role, u.plan, u.status, u.created_at, s.expires_at
         FROM sessions s
         JOIN users u ON u.id = s.user_id
         WHERE s.token = ?`
      )
      .get(token) as (User & { expires_at: string }) | undefined;
  }

  if (!row) return null;

  if (new Date(row.expires_at).getTime() < Date.now()) {
    db.prepare('DELETE FROM sessions WHERE token = ?').run(token);
    return null;
  }

  if (row.status === 'suspended') {
    return null;
  }

  return {
    id: row.id,
    name: row.name,
    email: row.email,
    role: row.role,
    plan: row.plan,
    status: row.status,
    created_at: row.created_at,
  };
}
