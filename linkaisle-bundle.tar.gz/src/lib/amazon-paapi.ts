import crypto from 'node:crypto';

export interface ParsedAmazonProduct {
  isAmazon: boolean;
  asin: string | null;
  host: string;
  countryCode: string;
  currency: string;
  partnerTag: string | null;
  canonicalUrl: string | null;
  reviewsUrl: string | null;
}

const MARKETPLACE_MAP: Record<string, { country: string; currency: string; region: string; apiHost: string }> = {
  'www.amazon.com': { country: 'US', currency: 'USD', region: 'us-east-1', apiHost: 'webservices.amazon.com' },
  'amazon.com': { country: 'US', currency: 'USD', region: 'us-east-1', apiHost: 'webservices.amazon.com' },
  'www.amazon.co.uk': { country: 'UK', currency: 'GBP', region: 'eu-west-1', apiHost: 'webservices.amazon.co.uk' },
  'amazon.co.uk': { country: 'UK', currency: 'GBP', region: 'eu-west-1', apiHost: 'webservices.amazon.co.uk' },
  'www.amazon.ca': { country: 'CA', currency: 'CAD', region: 'us-east-1', apiHost: 'webservices.amazon.ca' },
  'amazon.ca': { country: 'CA', currency: 'CAD', region: 'us-east-1', apiHost: 'webservices.amazon.ca' },
  'www.amazon.ae': { country: 'AE', currency: 'AED', region: 'eu-west-1', apiHost: 'webservices.amazon.ae' },
  'amazon.ae': { country: 'AE', currency: 'AED', region: 'eu-west-1', apiHost: 'webservices.amazon.ae' },
  'www.amazon.sa': { country: 'SA', currency: 'SAR', region: 'eu-west-1', apiHost: 'webservices.amazon.sa' },
  'amazon.sa': { country: 'SA', currency: 'SAR', region: 'eu-west-1', apiHost: 'webservices.amazon.sa' },
  'www.amazon.com.au': { country: 'AU', currency: 'AUD', region: 'us-west-2', apiHost: 'webservices.amazon.com.au' },
  'amazon.com.au': { country: 'AU', currency: 'AUD', region: 'us-west-2', apiHost: 'webservices.amazon.com.au' },
  'www.amazon.de': { country: 'EU', currency: 'EUR', region: 'eu-west-1', apiHost: 'webservices.amazon.de' },
  'www.amazon.in': { country: 'IN', currency: 'INR', region: 'eu-west-1', apiHost: 'webservices.amazon.in' },
};

export function parseAmazonUrl(rawUrl: string): ParsedAmazonProduct {
  try {
    const u = new URL(rawUrl.trim());
    const host = u.hostname.toLowerCase();
    const isAmazon = host.includes('amazon.') || host === 'amzn.to' || host === 'a.co';

    if (!isAmazon) {
      return {
        isAmazon: false,
        asin: null,
        host,
        countryCode: 'US',
        currency: 'USD',
        partnerTag: null,
        canonicalUrl: null,
        reviewsUrl: null,
      };
    }

    const mp = MARKETPLACE_MAP[host] || MARKETPLACE_MAP['www.amazon.com'];
    const normalizedHost = host.startsWith('www.') ? host : host.includes('amazon.') ? `www.${host}` : 'www.amazon.com';

    // Match standard 10-character Amazon ASIN patterns: /dp/ASIN, /gp/product/ASIN, /ASIN
    const pathMatch =
      u.pathname.match(/\/(?:dp|gp\/product|gp\/aw\/d|product-reviews)\/([A-Z0-9]{10})(?:[/?]|$)/i) ||
      u.pathname.match(/\/([B0-9][A-Z0-9]{9})(?:[/?]|$)/i);

    const asin = pathMatch ? pathMatch[1].toUpperCase() : null;
    const partnerTag = u.searchParams.get('tag') || null;

    return {
      isAmazon: true,
      asin,
      host: normalizedHost,
      countryCode: mp.country,
      currency: mp.currency,
      partnerTag,
      canonicalUrl: asin ? `https://${normalizedHost}/dp/${asin}` : null,
      reviewsUrl: asin ? `https://${normalizedHost}/product-reviews/${asin}` : null,
    };
  } catch {
    return {
      isAmazon: false,
      asin: null,
      host: '',
      countryCode: 'US',
      currency: 'USD',
      partnerTag: null,
      canonicalUrl: null,
      reviewsUrl: null,
    };
  }
}

export function isAmazonPaApiConfigured(): boolean {
  return Boolean(
    (process.env.AMAZON_ACCESS_KEY || '').trim().length > 8 &&
      (process.env.AMAZON_SECRET_KEY || '').trim().length > 8 &&
      (process.env.AMAZON_PARTNER_TAG || '').trim().length > 2
  );
}

function hmac(key: crypto.BinaryLike, data: string) {
  return crypto.createHmac('sha256', key).update(data, 'utf8').digest();
}

function sha256Hex(data: string) {
  return crypto.createHash('sha256').update(data, 'utf8').digest('hex');
}

export interface OfficialAmazonProductData {
  asin: string;
  title: string;
  priceDisplay: string;
  originalPrice: string;
  imageUrl: string;
  availability: string;
  salesRank: string;
  features: string[];
  detailPageUrl: string;
}

/**
 * Official Amazon Product Advertising API (PA-API 5.0) GetItems Client (AWS SigV4).
 * 100% compliant with Amazon Associates Operating Agreement — zero scraping, zero CAPTCHA bypass.
 * Activates automatically when AMAZON_ACCESS_KEY, AMAZON_SECRET_KEY, and AMAZON_PARTNER_TAG are set.
 */
export async function fetchOfficialAmazonProduct(
  asin: string,
  host = 'www.amazon.com'
): Promise<{ data: OfficialAmazonProductData | null; error?: string }> {
  const accessKey = (process.env.AMAZON_ACCESS_KEY || '').trim();
  const secretKey = (process.env.AMAZON_SECRET_KEY || '').trim();
  const partnerTag = (process.env.AMAZON_PARTNER_TAG || '').trim();

  if (!accessKey || !secretKey || !partnerTag) {
    return {
      data: null,
      error:
        'Amazon PA-API keys (AMAZON_ACCESS_KEY, AMAZON_SECRET_KEY, AMAZON_PARTNER_TAG) are not configured yet.',
    };
  }

  const mp = MARKETPLACE_MAP[host] || MARKETPLACE_MAP['www.amazon.com'];
  const apiHost = mp.apiHost;
  const region = mp.region;
  const service = 'ProductAdvertisingAPI';
  const target = 'com.amazon.paapi5.v1.ProductAdvertisingAPIv1.GetItems';
  const path = '/paapi5/getitems';

  const payloadObj = {
    ItemIds: [asin],
    PartnerTag: partnerTag,
    PartnerType: 'Associates',
    Marketplace: host,
    Resources: [
      'ItemInfo.Title',
      'ItemInfo.Features',
      'Images.Primary.Large',
      'Offers.Listings.Price',
      'Offers.Listings.SavingBasis',
      'Offers.Listings.Availability.Message',
      'BrowseNodeInfo.WebsiteSalesRank',
    ],
  };

  const payload = JSON.stringify(payloadObj);
  const now = new Date();
  const amzDate = now.toISOString().replace(/[:-]|\.\d{3}/g, '');
  const dateStamp = amzDate.slice(0, 8);

  const canonicalHeaders =
    `content-encoding:amz-1.0\n` +
    `content-type:application/json; charset=utf-8\n` +
    `host:${apiHost}\n` +
    `x-amz-date:${amzDate}\n` +
    `x-amz-target:${target}\n`;
  const signedHeaders = 'content-encoding;content-type;host;x-amz-date;x-amz-target';

  const canonicalRequest = [
    'POST',
    path,
    '',
    canonicalHeaders,
    signedHeaders,
    sha256Hex(payload),
  ].join('\n');

  const credentialScope = `${dateStamp}/${region}/${service}/aws4_request`;
  const stringToSign = [
    'AWS4-HMAC-SHA256',
    amzDate,
    credentialScope,
    sha256Hex(canonicalRequest),
  ].join('\n');

  const kDate = hmac(`AWS4${secretKey}`, dateStamp);
  const kRegion = hmac(kDate, region);
  const kService = hmac(kRegion, service);
  const kSigning = hmac(kService, 'aws4_request');
  const signature = crypto.createHmac('sha256', kSigning).update(stringToSign, 'utf8').digest('hex');

  const authHeader = `AWS4-HMAC-SHA256 Credential=${accessKey}/${credentialScope}, SignedHeaders=${signedHeaders}, Signature=${signature}`;

  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    const res = await fetch(`https://${apiHost}${path}`, {
      method: 'POST',
      signal: controller.signal,
      headers: {
        'content-encoding': 'amz-1.0',
        'content-type': 'application/json; charset=utf-8',
        host: apiHost,
        'x-amz-date': amzDate,
        'x-amz-target': target,
        Authorization: authHeader,
      },
      body: payload,
    });
    clearTimeout(timer);

    const json = (await res.json().catch(() => ({}))) as {
      ItemsResult?: {
        Items?: Array<{
          ASIN?: string;
          DetailPageURL?: string;
          ItemInfo?: {
            Title?: { DisplayValue?: string };
            Features?: { DisplayValues?: string[] };
          };
          Images?: { Primary?: { Large?: { URL?: string } } };
          Offers?: {
            Listings?: Array<{
              Price?: { DisplayAmount?: string };
              SavingBasis?: { DisplayAmount?: string };
              Availability?: { Message?: string };
            }>;
          };
          BrowseNodeInfo?: {
            WebsiteSalesRank?: { ContextFreeName?: string; SalesRank?: number };
          };
        }>;
      };
      Errors?: Array<{ Message?: string }>;
    };

    if (!res.ok) {
      return { data: null, error: json.Errors?.[0]?.Message || `Amazon PA-API HTTP ${res.status}` };
    }

    const item = json.ItemsResult?.Items?.[0];
    if (!item) {
      return { data: null, error: 'ASIN not returned by Amazon PA-API.' };
    }

    const listing = item.Offers?.Listings?.[0];
    const rankObj = item.BrowseNodeInfo?.WebsiteSalesRank;
    const salesRank = rankObj?.SalesRank
      ? `#${rankObj.SalesRank.toLocaleString()} in ${rankObj.ContextFreeName || 'Category'}`
      : '';

    return {
      data: {
        asin: item.ASIN || asin,
        title: item.ItemInfo?.Title?.DisplayValue || '',
        priceDisplay: listing?.Price?.DisplayAmount || '',
        originalPrice: listing?.SavingBasis?.DisplayAmount || '',
        imageUrl: item.Images?.Primary?.Large?.URL || '',
        availability: listing?.Availability?.Message || 'In Stock on Amazon',
        salesRank,
        features: (item.ItemInfo?.Features?.DisplayValues || []).slice(0, 5),
        detailPageUrl: item.DetailPageURL || `https://${host}/dp/${asin}?tag=${partnerTag}`,
      },
    };
  } catch (err) {
    return { data: null, error: String(err) };
  }
}
