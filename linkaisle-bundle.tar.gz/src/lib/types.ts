export type UserRole = 'user' | 'admin';
export type UserPlan = 'free' | 'starter' | 'pro';
export type UserStatus = 'active' | 'suspended';
export type StoreTemplateId = 'kitchen' | 'tech' | 'beauty' | 'pets' | 'minimal';
export type PublishStatus = 'draft' | 'published';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  plan: UserPlan;
  status: UserStatus;
  created_at: string;
}

export interface Store {
  id: string;
  user_id: string;
  slug: string;
  name: string;
  tagline: string;
  description: string;
  template: StoreTemplateId;
  primary_color: string;
  accent_color: string;
  logo_url: string;
  hero_title: string;
  hero_subtitle: string;
  hero_cta: string;
  disclosure_text: string;
  contact_email: string;
  social_tiktok: string;
  social_instagram: string;
  social_youtube: string;
  social_facebook: string;
  target_country: string;
  currency: string;
  is_published: number;
  is_suspended: number;
  created_at: string;
  updated_at: string;
}

export interface Product {
  id: string;
  store_id: string;
  title: string;
  slug: string;
  category: string;
  price_display: string;
  original_price: string;
  image_url: string;
  short_description: string;
  description: string;
  benefits: string[];
  available_countries: string[];
  affiliate_url: string;
  merchant_name: string;
  badge: string;
  asin?: string;
  amazon_marketplace?: string;
  sales_rank?: string;
  availability_status?: string;
  rating: number;
  review_count: number;
  last_checked_at: string;
  price_status: 'verified' | 'needs_review' | 'unreachable' | 'unverified';
  last_price_note: string;
  quality_score: number;
  is_featured: number;
  status: PublishStatus;
  impressions: number;
  clicks: number;
  created_at: string;
  updated_at: string;
}

export interface CountryOption {
  code: string;
  name: string;
  short: string;
  currency: string;
}

export const COUNTRY_OPTIONS: CountryOption[] = [
  { code: 'GLOBAL', name: 'Worldwide (Global)', short: 'Global', currency: 'USD' },
  { code: 'US', name: 'United States', short: 'USA', currency: 'USD' },
  { code: 'UK', name: 'United Kingdom', short: 'UK', currency: 'GBP' },
  { code: 'CA', name: 'Canada', short: 'Canada', currency: 'CAD' },
  { code: 'PK', name: 'Pakistan', short: 'Pakistan', currency: 'PKR' },
  { code: 'AE', name: 'United Arab Emirates', short: 'UAE', currency: 'AED' },
  { code: 'SA', name: 'Saudi Arabia', short: 'KSA', currency: 'SAR' },
  { code: 'AU', name: 'Australia', short: 'Australia', currency: 'AUD' },
  { code: 'EU', name: 'Europe (EU)', short: 'Europe', currency: 'EUR' },
  { code: 'IN', name: 'India', short: 'India', currency: 'INR' },
];

export function formatCountryLabel(code: string): string {
  const found = COUNTRY_OPTIONS.find((c) => c.code === code);
  return found ? found.short : code;
}

export interface BlogPost {
  id: string;
  store_id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  cover_image: string;
  category: string;
  seo_title: string;
  seo_description: string;
  featured_product_ids: string[];
  status: PublishStatus;
  views: number;
  created_at: string;
  updated_at: string;
}

export interface AcademyLesson {
  id: string;
  module_number: number;
  order_index: number;
  slug: string;
  title: string;
  summary: string;
  content: string;
  title_ur: string;
  summary_ur: string;
  content_ur: string;
  duration_minutes: number;
  level: 'Beginner' | 'Intermediate' | 'Pro';
  is_published: number;
  created_at: string;
}

export interface UpgradeRequest {
  id: string;
  user_id: string;
  user_name?: string;
  user_email?: string;
  current_plan?: UserPlan;
  requested_plan: 'starter' | 'pro';
  billing_cycle: 'monthly' | 'yearly';
  amount_usd: number;
  payment_method: string;
  transaction_ref: string;
  notes: string;
  status: 'pending' | 'approved' | 'rejected';
  admin_note: string;
  created_at: string;
  reviewed_at: string;
}

export interface PartnerTool {
  id: string;
  name: string;
  category: string;
  tagline: string;
  description: string;
  affiliate_url: string;
  commission_note: string;
  badge: string;
  clicks: number;
  is_published: number;
  created_at: string;
}

export interface MonetizationConfig {
  ads_enabled: boolean;
  ad_network_label: string;
  ad_sponsor_title: string;
  ad_sponsor_desc: string;
  ad_sponsor_cta_text: string;
  ad_sponsor_cta_url: string;
  payment_instructions: string;
}

export interface PlanLimits {
  free: { maxStores: number; maxProducts: number; maxPosts: number; label: string; price: number };
  starter: { maxStores: number; maxProducts: number; maxPosts: number; label: string; price: number };
  pro: { maxStores: number; maxProducts: number; maxPosts: number; label: string; price: number };
}

export const DEFAULT_PLAN_LIMITS: PlanLimits = {
  free: { maxStores: 1, maxProducts: 10, maxPosts: 5, label: 'Free', price: 0 },
  starter: { maxStores: 3, maxProducts: 100, maxPosts: 50, label: 'Starter', price: 9 },
  pro: { maxStores: 10, maxProducts: 9999, maxPosts: 9999, label: 'Pro', price: 19 },
};

export interface TemplateConfig {
  id: StoreTemplateId;
  name: string;
  niche: string;
  description: string;
  defaultPrimary: string;
  defaultAccent: string;
  previewBg: string;
  badgeText: string;
}

export const STORE_TEMPLATES: TemplateConfig[] = [
  {
    id: 'kitchen',
    name: 'Editorial Home & Kitchen',
    niche: 'Home & Kitchen',
    description: 'Warm linen and terracotta editorial showcase crafted for home essentials and daily upgrades.',
    defaultPrimary: '#c2410c',
    defaultAccent: '#15803d',
    previewBg: 'from-[#fffdf9] via-orange-50 to-amber-50',
    badgeText: 'Warm Editorial',
  },
  {
    id: 'tech',
    name: 'Clean Tech Studio',
    niche: 'Tech & Electronics',
    description: 'Pure white Apple-inspired hardware storefront with crisp silver surfaces, electric blue buttons, and spec highlights.',
    defaultPrimary: '#0066cc',
    defaultAccent: '#0f172a',
    previewBg: 'from-white via-sky-50 to-slate-100',
    badgeText: 'Clean Tech',
  },
  {
    id: 'beauty',
    name: 'Atelier Luxury Boutique',
    niche: 'Beauty & Wellness',
    description: 'Airy ivory and blush editorial boutique with refined serif typography and portrait lookbook cards.',
    defaultPrimary: '#be185d',
    defaultAccent: '#b45309',
    previewBg: 'from-white via-rose-50 to-pink-50',
    badgeText: 'Soft Luxury',
  },
  {
    id: 'pets',
    name: 'Happy Market',
    niche: 'Pets & Lifestyle',
    description: 'Bright mint-white storefront with playful rounded cards, warm coral badges, and easy category browsing.',
    defaultPrimary: '#0d9488',
    defaultAccent: '#ea580c',
    previewBg: 'from-white via-teal-50 to-amber-50',
    badgeText: 'Playful Bright',
  },
  {
    id: 'minimal',
    name: 'Swiss Gallery',
    niche: 'Universal / Multi-Niche',
    description: 'Ultra-crisp gallery white grid with bold carbon typography and forest emerald conversion accents.',
    defaultPrimary: '#111315',
    defaultAccent: '#047857',
    previewBg: 'from-white via-stone-50 to-emerald-50/60',
    badgeText: 'Swiss Gallery',
  },
];
