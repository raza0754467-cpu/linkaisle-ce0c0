export function isResendConfigured(): boolean {
  return (process.env.RESEND_API_KEY || '').trim().length > 10;
}

export async function sendEmail({
  to,
  subject,
  html,
}: {
  to: string;
  subject: string;
  html: string;
}): Promise<{ sent: boolean; id?: string; error?: string }> {
  const apiKey = (process.env.RESEND_API_KEY || '').trim();
  const from = (process.env.EMAIL_FROM || 'LinkAisle <onboarding@resend.dev>').trim();

  if (apiKey.length <= 10) {
    return { sent: false, error: 'RESEND_API_KEY not configured' };
  }

  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      signal: controller.signal,
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        from,
        to: [to],
        subject,
        html,
      }),
    });
    clearTimeout(timer);
    const json = (await res.json().catch(() => ({}))) as { id?: string; message?: string };
    if (!res.ok) {
      return { sent: false, error: json.message || `HTTP ${res.status}` };
    }
    return { sent: true, id: json.id };
  } catch (err) {
    return { sent: false, error: String(err) };
  }
}

export async function sendWelcomeEmail({
  to,
  name,
  storeName,
  storeUrl,
  studioUrl,
}: {
  to: string;
  name: string;
  storeName: string;
  storeUrl: string;
  studioUrl: string;
}) {
  return sendEmail({
    to,
    subject: `Welcome to LinkAisle — "${storeName}" is live!`,
    html: `
      <div style="font-family:Inter,Arial,sans-serif;max-width:540px;margin:0 auto;padding:28px;color:#111315;background:#FAFAF9;border-radius:16px;">
        <h2 style="margin:0 0 12px;font-size:22px;">Welcome to LinkAisle, ${name}!</h2>
        <p style="font-size:14px;line-height:1.6;color:#44403C;">
          Your free affiliate storefront <strong>${storeName}</strong> is ready to customize and share.
        </p>
        <p style="margin:22px 0;">
          <a href="${studioUrl}" style="display:inline-block;background:#047857;color:#fff;padding:12px 24px;border-radius:999px;text-decoration:none;font-weight:700;font-size:14px;margin-right:8px;">Open Creator Studio</a>
          <a href="${storeUrl}" style="display:inline-block;background:#111315;color:#fff;padding:12px 24px;border-radius:999px;text-decoration:none;font-weight:700;font-size:14px;">View Live Store</a>
        </p>
        <p style="font-size:12px;color:#78716C;line-height:1.5;">
          Next steps: Add your first affiliate products with AI Auto-Write, choose deliverable countries, and share your LinkAisle store URL.
        </p>
      </div>
    `,
  });
}

export async function sendPasswordResetEmail({
  to,
  name,
  resetUrl,
}: {
  to: string;
  name: string;
  resetUrl: string;
}) {
  return sendEmail({
    to,
    subject: 'Reset your LinkAisle password',
    html: `
      <div style="font-family:Inter,Arial,sans-serif;max-width:540px;margin:0 auto;padding:28px;color:#111315;background:#FAFAF9;border-radius:16px;">
        <h2 style="margin:0 0 12px;font-size:22px;">Reset Your LinkAisle Password</h2>
        <p style="font-size:14px;line-height:1.6;color:#44403C;">
          Hi ${name}, we received a request to reset your LinkAisle password. Click the button below within 1 hour:
        </p>
        <p style="margin:24px 0;">
          <a href="${resetUrl}" style="display:inline-block;background:#047857;color:#fff;padding:12px 24px;border-radius:999px;text-decoration:none;font-weight:700;font-size:14px;">Reset Password</a>
        </p>
        <p style="font-size:12px;color:#78716C;">
          If you didn't request this reset, you can safely ignore this email.
        </p>
      </div>
    `,
  });
}
