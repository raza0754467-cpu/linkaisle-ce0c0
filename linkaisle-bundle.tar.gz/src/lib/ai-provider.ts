/**
 * LinkAisle Multi-Provider Free AI Engine ($0 Budget, Automatic Failover)
 *
 * Failover priority:
 *   1. Google Gemini API (official @google/genai SDK — GEMINI_API_KEY)
 *   2. Groq Free API (ultra-fast Llama 3.3 70B — GROQ_API_KEY)
 *   3. OpenRouter Free Models (OPENROUTER_API_KEY)
 *   4. Built-in Local Smart Engine (0-limit offline fallback so the app NEVER breaks)
 */

import { GoogleGenAI } from '@google/genai';

export type AiProviderId = 'gemini' | 'groq' | 'openrouter' | 'local-engine';

export interface AiGenerationResult {
  text: string;
  provider: AiProviderId;
  providerLabel: string;
  usedCloudAi: boolean;
}

export interface AiCapabilityStatus {
  mode: 'cloud-ai-active' | 'local-free-engine';
  configured: boolean;
  activeProviders: { id: AiProviderId; name: string; active: boolean }[];
  providerName: string;
}

function cleanKey(val?: string): string {
  return (val || '').trim();
}

export function getAiArchitectureStatus(): AiCapabilityStatus {
  const hasGemini = cleanKey(process.env.GEMINI_API_KEY).length > 10;
  const hasGroq = cleanKey(process.env.GROQ_API_KEY).length > 10;
  const hasOpenRouter = cleanKey(process.env.OPENROUTER_API_KEY).length > 10;
  const configured = hasGemini || hasGroq || hasOpenRouter;

  const activeProviders: { id: AiProviderId; name: string; active: boolean }[] = [
    { id: 'gemini', name: 'Google Gemini (Free Tier)', active: hasGemini },
    { id: 'groq', name: 'Groq Cloud AI (Free Tier)', active: hasGroq },
    { id: 'openrouter', name: 'OpenRouter Free Models', active: hasOpenRouter },
    { id: 'local-engine', name: 'LinkAisle Built-In Engine (Always On)', active: true },
  ];

  const firstActive = activeProviders.find((p) => p.active && p.id !== 'local-engine');

  return {
    mode: configured ? 'cloud-ai-active' : 'local-free-engine',
    configured,
    activeProviders,
    providerName: firstActive
      ? `${firstActive.name} (+ Auto-Failover)`
      : 'Built-In Smart Engine (Add Gemini / Groq / OpenRouter Key to Upgrade)',
  };
}

async function callGemini(systemPrompt: string, userPrompt: string): Promise<string | null> {
  const apiKey = cleanKey(process.env.GEMINI_API_KEY);
  if (apiKey.length <= 10) return null;

  const client = new GoogleGenAI({ apiKey });
  const modelsToTry = ['gemini-3.5-flash-lite', 'gemini-4-hydrogen'];

  for (const model of modelsToTry) {
    try {
      const interaction = await client.interactions.create({
        model,
        system_instruction: systemPrompt,
        input: userPrompt,
        store: false,
      });
      const text = (interaction.output_text || '').trim();
      if (text) return text;
    } catch {
      // Try next model or fail over to next free provider
    }
  }
  return null;
}

async function callOpenAiCompatible(
  endpoint: string,
  apiKey: string,
  model: string,
  systemPrompt: string,
  userPrompt: string,
  extraHeaders?: Record<string, string>
): Promise<string | null> {
  if (apiKey.length <= 10) return null;
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 14000);
    const res = await fetch(endpoint, {
      method: 'POST',
      signal: controller.signal,
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
        ...(extraHeaders || {}),
      },
      body: JSON.stringify({
        model,
        temperature: 0.7,
        max_tokens: 1200,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt },
        ],
      }),
    });
    clearTimeout(timer);
    if (!res.ok) return null;
    const json = (await res.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    const content = json.choices?.[0]?.message?.content?.trim();
    return content || null;
  } catch {
    return null;
  }
}

export async function generateWithFreeAi({
  systemPrompt,
  userPrompt,
  fallback,
}: {
  systemPrompt: string;
  userPrompt: string;
  fallback: () => string;
}): Promise<AiGenerationResult> {
  // 1. Try Google Gemini Free Tier
  const geminiText = await callGemini(systemPrompt, userPrompt);
  if (geminiText) {
    return {
      text: geminiText,
      provider: 'gemini',
      providerLabel: 'Google Gemini AI',
      usedCloudAi: true,
    };
  }

  // 2. Fail over to Groq Free Tier (try current active fast models)
  const groqKey = cleanKey(process.env.GROQ_API_KEY);
  if (groqKey.length > 10) {
    for (const groqModel of ['qwen/qwen3.8-27b', 'openai/gpt-oss-120b', 'openai/gpt-oss-20b']) {
      const groqText = await callOpenAiCompatible(
        'https://api.groq.com/openai/v1/chat/completions',
        groqKey,
        groqModel,
        systemPrompt,
        userPrompt
      );
      if (groqText) {
        return {
          text: groqText,
          provider: 'groq',
          providerLabel: `Groq Free AI (${groqModel.split('/').pop()})`,
          usedCloudAi: true,
        };
      }
    }
  }

  // 3. Fail over to OpenRouter Free Auto-Router
  const openRouterKey = cleanKey(process.env.OPENROUTER_API_KEY);
  const openRouterText = await callOpenAiCompatible(
    'https://openrouter.ai/api/v1/chat/completions',
    openRouterKey,
    'openrouter/free',
    systemPrompt,
    userPrompt,
    {
      'HTTP-Referer': process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000',
      'X-Title': 'LinkAisle',
    }
  );
  if (openRouterText) {
    return {
      text: openRouterText,
      provider: 'openrouter',
      providerLabel: 'OpenRouter Free AI',
      usedCloudAi: true,
    };
  }

  // 4. Built-in zero-limit local smart fallback
  return {
    text: fallback(),
    provider: 'local-engine',
    providerLabel: 'LinkAisle Smart Engine',
    usedCloudAi: false,
  };
}

export function extractJsonObject<T>(raw: string): T | null {
  try {
    return JSON.parse(raw) as T;
  } catch {
    const match = raw.match(/\{[\s\S]*\}/);
    if (!match) return null;
    try {
      return JSON.parse(match[0]) as T;
    } catch {
      return null;
    }
  }
}
