'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import {
  ArrowRight,
  BookOpen,
  CheckCircle2,
  Clock,
  GraduationCap,
  Rocket,
} from 'lucide-react';
import { AcademyLesson } from '@/lib/types';
import ProfitCalculator from './ProfitCalculator';

const MODULE_TITLES: Record<number, string> = {
  1: 'Module 1: Affiliate Foundations & Program Approval',
  2: 'Module 2: Multi-Product Store Strategy & Copywriting',
  3: 'Module 3: Free Organic Traffic & SEO Blogging',
  4: 'Module 4: International Paid Ads, Compliance & Analytics',
};

export default function AcademyListClient({
  lessons,
  platformName,
  isLoggedIn,
}: {
  lessons: AcademyLesson[];
  platformName: string;
  isLoggedIn: boolean;
}) {
  const [completed, setCompleted] = useState<string[]>([]);

  useEffect(() => {
    try {
      const savedDone = JSON.parse(localStorage.getItem('affiliforge_lessons_done') || '[]');
      if (Array.isArray(savedDone)) setCompleted(savedDone);
    } catch {}
  }, []);

  const grouped = new Map<number, AcademyLesson[]>();
  for (const l of lessons) {
    const arr = grouped.get(l.module_number) || [];
    arr.push(l);
    grouped.set(l.module_number, arr);
  }

  const doneCount = lessons.filter((l) => completed.includes(l.id)).length;
  const pct = lessons.length > 0 ? Math.round((doneCount / lessons.length) * 100) : 0;

  return (
    <>
      <section className="border-b border-stone-200 bg-[#111315] py-14 text-white">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="inline-flex items-center gap-2 rounded-full bg-emerald-500/15 border border-emerald-400/30 px-3.5 py-1 text-xs font-semibold text-emerald-300">
            <GraduationCap className="h-4 w-4" />
            Free Step-by-Step Affiliate Curriculum
          </div>

          <h1 className="mt-5 font-display text-3xl font-extrabold sm:text-5xl">
            {platformName} Affiliate Academy
          </h1>
          <p className="mt-4 max-w-2xl text-stone-300 text-base sm:text-lg">
            Practical, no-hype lessons explaining how affiliate programs work, how to build a
            multi-product storefront, how to bring organic visitors at $0 ad spend, and how to
            measure real profit.
          </p>

          <div className="mt-7 flex flex-wrap items-center justify-between gap-6">
            <div className="flex flex-wrap gap-3">
              <Link
                href={isLoggedIn ? '/dashboard' : '/register'}
                className="inline-flex items-center gap-2 rounded-full bg-[#047857] px-6 py-3 text-sm font-bold text-white hover:bg-[#065f46] transition-colors"
              >
                <Rocket className="h-4 w-4" />
                Apply While Learning — Open Studio
              </Link>
              <Link
                href="/s/smart-home-finds"
                className="inline-flex items-center gap-2 rounded-full bg-white/10 border border-white/15 px-6 py-3 text-sm font-semibold text-white hover:bg-white/15 transition-colors"
              >
                View Live Example Store
              </Link>
            </div>

            <div className="min-w-[220px] rounded-2xl bg-white/10 border border-white/15 p-3.5">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-stone-300">Learning Progress</span>
                <span className="text-emerald-300">
                  {doneCount}/{lessons.length} ({pct}%)
                </span>
              </div>
              <div className="mt-2 h-2 rounded-full bg-stone-800 overflow-hidden">
                <div
                  className="h-full rounded-full bg-emerald-400 transition-all"
                  style={{ width: `${pct}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      <main className="mx-auto max-w-6xl px-4 py-12 sm:px-6 lg:px-8 space-y-12">
        {Array.from(grouped.entries()).map(([modNum, modLessons]) => (
          <div key={modNum}>
            <h2 className="font-display text-xl font-extrabold text-[#111315] mb-5 flex items-center gap-2.5">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#111315] text-sm font-bold text-white">
                {modNum}
              </span>
              {MODULE_TITLES[modNum] || `Module ${modNum}`}
            </h2>
            <div className="grid gap-5 md:grid-cols-2">
              {modLessons.map((lesson) => {
                const isDone = completed.includes(lesson.id);

                return (
                  <Link
                    key={lesson.id}
                    href={`/academy/${lesson.slug}`}
                    className="group flex flex-col justify-between rounded-2xl border border-stone-200 bg-white p-6 shadow-sm hover:border-[#047857]/40 hover:shadow-md transition-all"
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span
                            className={`rounded-full px-2.5 py-0.5 text-[11px] font-bold ${
                              lesson.level === 'Beginner'
                                ? 'bg-emerald-50 text-[#047857]'
                                : lesson.level === 'Intermediate'
                                  ? 'bg-stone-100 text-stone-800'
                                  : 'bg-amber-50 text-amber-800'
                            }`}
                          >
                            {lesson.level}
                          </span>
                          {isDone && (
                            <span className="inline-flex items-center gap-1 rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-800">
                              <CheckCircle2 className="h-3 w-3" /> Done
                            </span>
                          )}
                        </div>
                        <span className="flex items-center gap-1 text-xs text-stone-400">
                          <Clock className="h-3.5 w-3.5" />
                          {lesson.duration_minutes} min
                        </span>
                      </div>
                      <h3 className="mt-3 font-display text-lg font-bold text-[#111315] group-hover:text-[#047857] transition-colors">
                        {lesson.title}
                      </h3>
                      <p className="mt-2 text-sm text-stone-600 leading-relaxed">{lesson.summary}</p>
                    </div>
                    <div className="mt-5 flex items-center gap-1.5 text-xs font-bold text-[#047857]">
                      <BookOpen className="h-4 w-4" />
                      Read Lesson
                      <ArrowRight className="h-3.5 w-3.5 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </Link>
                );
              })}
            </div>
          </div>
        ))}

        <div className="pt-4">
          <ProfitCalculator />
        </div>
      </main>
    </>
  );
}
