'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import Link from 'next/link';
import { CheckCircle2, ExternalLink, Globe, Palette, ShoppingBag, X } from 'lucide-react';
import { BlogPost, Product, STORE_TEMPLATES, Store, StoreTemplateId, formatCountryLabel } from '@/lib/types';
import KitchenEditorialTheme from './themes/KitchenEditorialTheme';
import TechCyberTheme from './themes/TechCyberTheme';
import BeautyLuxeTheme from './themes/BeautyLuxeTheme';
import PetsPlayfulTheme from './themes/PetsPlayfulTheme';
import MinimalSwissTheme from './themes/MinimalSwissTheme';

const VALID_TEMPLATES: StoreTemplateId[] = ['kitchen', 'tech', 'beauty', 'pets', 'minimal'];

export default function StorefrontClient({
  store,
  products,
  posts,
  platformName,
  previewTemplate,
}: {
  store: Store;
  products: Product[];
  posts: BlogPost[];
  platformName: string;
  previewTemplate?: string | null;
}) {
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [countryFilter, setCountryFilter] = useState('ALL');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [trafficSrc, setTrafficSrc] = useState('');
  const trackedRef = useRef(false);

  const initialPreview =
    previewTemplate && VALID_TEMPLATES.includes(previewTemplate as StoreTemplateId)
      ? (previewTemplate as StoreTemplateId)
      : null;

  const [activePreview, setActivePreview] = useState<StoreTemplateId | null>(initialPreview);

  const effectiveStore: Store = useMemo(() => {
    if (!activePreview) return store;
    const tplCfg = STORE_TEMPLATES.find((t) => t.id === activePreview);
    return {
      ...store,
      template: activePreview,
      primary_color: tplCfg?.defaultPrimary || store.primary_color,
      accent_color: tplCfg?.defaultAccent || store.accent_color,
    };
  }, [store, activePreview]);

  const isDark = false;

  // Fire 100% REAL visit & product impression tracking once per page load (skipped in theme preview mode)
  useEffect(() => {
    if (trackedRef.current || activePreview) return;
    trackedRef.current = true;

    const params = new URLSearchParams(window.location.search);
    const utmSource = params.get('utm_source') || params.get('src') || '';
    if (utmSource) setTrafficSrc(utmSource);
    const referrer = document.referrer || '';

    fetch('/api/track', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        eventType: 'store_visit',
        storeId: store.id,
        referrer,
        utmSource,
      }),
    }).catch(() => {});

    if (products.length > 0) {
      fetch('/api/track', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          eventType: 'product_impression',
          storeId: store.id,
          productIds: products.map((p) => p.id),
          referrer,
          utmSource,
        }),
      }).catch(() => {});
    }
  }, [store.id, products, activePreview]);

  const goHref = (productId: string) =>
    trafficSrc ? `/api/go/${productId}?src=${encodeURIComponent(trafficSrc)}` : `/api/go/${productId}`;

  const categories = useMemo(() => {
    const set = new Set<string>();
    products.forEach((p) => {
      if (p.category) set.add(p.category);
    });
    return ['All', ...Array.from(set)];
  }, [products]);

  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const catMatch = category === 'All' || p.category === category;
      const countries = p.available_countries || ['US'];
      const countryMatch =
        countryFilter === 'ALL' ||
        countries.includes('GLOBAL') ||
        countries.includes(countryFilter);
      const q = search.trim().toLowerCase();
      const searchMatch =
        !q ||
        p.title.toLowerCase().includes(q) ||
        p.short_description.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.merchant_name.toLowerCase().includes(q);
      return catMatch && countryMatch && searchMatch;
    });
  }, [products, category, countryFilter, search]);

  const featuredProducts = useMemo(() => products.filter((p) => p.is_featured === 1), [products]);

  const handleOpenProductInNewTab = (product: Product | null) => {
    if (!product) {
      setSelectedProduct(null);
      return;
    }
    const qs = trafficSrc ? `?src=${encodeURIComponent(trafficSrc)}` : '';
    window.open(`/s/${store.slug}/p/${product.slug}${qs}`, '_blank', 'noopener,noreferrer');
  };

  const themeProps = {
    store: effectiveStore,
    products,
    filteredProducts,
    featuredProducts,
    posts,
    platformName,
    categories,
    category,
    setCategory,
    countryFilter,
    setCountryFilter,
    search,
    setSearch,
    setSelectedProduct: handleOpenProductInNewTab,
    goHref,
  };

  return (
    <>
      {/* SHOPIFY-STYLE LIVE THEME PREVIEW SWITCHER BAR (Shown when ?preview= is active) */}
      {activePreview && (
        <div className="sticky top-0 z-50 border-b border-indigo-500/40 bg-slate-950 px-4 py-2.5 text-white shadow-lg">
          <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-xs font-bold">
              <Palette className="h-4 w-4 text-indigo-400" />
              <span className="text-indigo-200">Shopify-Style Live Theme Preview:</span>
              <div className="flex flex-wrap gap-1.5 ml-1">
                {STORE_TEMPLATES.map((tpl) => (
                  <button
                    key={tpl.id}
                    type="button"
                    onClick={() => setActivePreview(tpl.id)}
                    className={`rounded-lg px-2.5 py-1 text-[11px] font-bold transition-colors ${
                      activePreview === tpl.id
                        ? 'bg-indigo-600 text-white'
                        : 'bg-white/10 text-slate-300 hover:bg-white/20'
                    }`}
                  >
                    {tpl.badgeText}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Link
                href={`/register?template=${activePreview}`}
                className="rounded-lg bg-emerald-500 px-3 py-1 text-xs font-bold text-slate-950 hover:bg-emerald-400"
              >
                Use This Theme Free
              </Link>
              <Link
                href="/templates"
                className="rounded-lg border border-white/20 px-3 py-1 text-xs font-semibold text-slate-200 hover:bg-white/10"
              >
                All Themes
              </Link>
            </div>
          </div>
        </div>
      )}

      {/* BESPOKE SHOPIFY-CLASS THEME DISPATCH */}
      {effectiveStore.template === 'tech' && <TechCyberTheme {...themeProps} />}
      {effectiveStore.template === 'beauty' && <BeautyLuxeTheme {...themeProps} />}
      {effectiveStore.template === 'pets' && <PetsPlayfulTheme {...themeProps} />}
      {effectiveStore.template === 'minimal' && <MinimalSwissTheme {...themeProps} />}
      {(effectiveStore.template === 'kitchen' || !VALID_TEMPLATES.includes(effectiveStore.template)) && (
        <KitchenEditorialTheme {...themeProps} />
      )}

      {/* UNIVERSAL QUICK-VIEW PRODUCT MODAL */}
      {selectedProduct && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
          onClick={() => setSelectedProduct(null)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className={`relative max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl border p-6 shadow-2xl ${
              isDark
                ? 'bg-slate-900 border-slate-700 text-white'
                : 'bg-white border-slate-200 text-slate-900'
            }`}
          >
            <button
              type="button"
              onClick={() => setSelectedProduct(null)}
              className="absolute right-4 top-4 rounded-lg p-1.5 opacity-60 hover:opacity-100"
            >
              <X className="h-5 w-5" />
            </button>

            <div className="grid gap-6 sm:grid-cols-2">
              <div className="overflow-hidden rounded-xl bg-slate-200/40">
                {selectedProduct.image_url ? (
                  <img
                    src={selectedProduct.image_url}
                    alt={selectedProduct.title}
                    className="h-64 w-full object-cover"
                  />
                ) : (
                  <div className="flex h-64 items-center justify-center opacity-30">
                    <ShoppingBag className="h-12 w-12" />
                  </div>
                )}
              </div>

              <div className="flex flex-col justify-between">
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider opacity-60">
                    {selectedProduct.category} · {selectedProduct.merchant_name}
                  </span>
                  <h3 className="mt-1.5 font-display text-xl font-extrabold">
                    {selectedProduct.title}
                  </h3>
                  <div className="mt-2 flex items-baseline gap-2">
                    <span
                      className="font-display text-2xl font-extrabold"
                      style={{ color: effectiveStore.primary_color }}
                    >
                      {selectedProduct.price_display}
                    </span>
                    {selectedProduct.original_price && (
                      <span className="text-sm line-through opacity-50">
                        {selectedProduct.original_price}
                      </span>
                    )}
                  </div>
                  <p className="mt-3 text-sm leading-relaxed opacity-80">
                    {selectedProduct.description || selectedProduct.short_description}
                  </p>

                  <div className="mt-3 flex flex-wrap items-center gap-1.5">
                    <span className="text-[11px] font-bold opacity-70 inline-flex items-center gap-1">
                      <Globe className="h-3.5 w-3.5" /> Available in:
                    </span>
                    {(selectedProduct.available_countries || ['US']).map((code) => (
                      <span
                        key={code}
                        className={`rounded-md border px-2 py-0.5 text-[11px] font-bold ${
                          isDark
                            ? 'border-white/15 bg-white/5 text-slate-200'
                            : 'border-slate-200 bg-slate-50 text-slate-700'
                        }`}
                      >
                        {formatCountryLabel(code)}
                      </span>
                    ))}
                  </div>

                  {selectedProduct.benefits?.length > 0 && (
                    <ul className="mt-4 space-y-1.5">
                      {selectedProduct.benefits.map((b, i) => (
                        <li key={i} className="flex items-start gap-2 text-xs">
                          <CheckCircle2
                            className="h-4 w-4 shrink-0 mt-0.5"
                            style={{ color: effectiveStore.accent_color }}
                          />
                          <span>{b}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>

                <div className="mt-6 flex flex-col gap-2">
                  <a
                    href={goHref(selectedProduct.id)}
                    target="_blank"
                    rel="noopener noreferrer sponsored"
                    className="w-full inline-flex items-center justify-center gap-2 rounded-full py-3 text-sm font-bold text-white shadow-md hover:opacity-90"
                    style={{ backgroundColor: effectiveStore.primary_color }}
                  >
                    Buy via {selectedProduct.merchant_name || 'Merchant'}
                    <ExternalLink className="h-4 w-4" />
                  </a>
                  <Link
                    href={`/s/${store.slug}/p/${selectedProduct.slug}`}
                    className="w-full inline-flex items-center justify-center rounded-full border border-stone-200 bg-stone-50 py-2.5 text-xs font-bold text-stone-800 hover:bg-stone-100"
                  >
                    Open Full Product Listing Page →
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
