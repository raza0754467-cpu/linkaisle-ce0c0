'use client';

import { useState } from 'react';
import {
  Check,
  Copy,
  Link2,
  Megaphone,
  Share2,
  Sparkles,
  Video,
  AlertTriangle,
} from 'lucide-react';
import { Product, Store } from '@/lib/types';

const CHANNELS = [
  { id: 'tiktok', label: 'TikTok Bio / Video' },
  { id: 'instagram', label: 'Instagram Reels' },
  { id: 'facebook', label: 'Facebook Ads / Page' },
  { id: 'youtube', label: 'YouTube Shorts' },
  { id: 'pinterest', label: 'Pinterest Pin' },
  { id: 'whatsapp', label: 'WhatsApp / Status' },
];

export default function MarketingKitTab({
  store,
  products,
}: {
  store: Store;
  products: Product[];
}) {
  const [selectedId, setSelectedId] = useState<string>('collection');
  const lang = 'en' as const;
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [generatingAi, setGeneratingAi] = useState(false);
  const [aiProviderLabel, setAiProviderLabel] = useState<string | null>(null);
  const [aiOverride, setAiOverride] = useState<{
    videoScript: string;
    fbAdCopy: string;
    pinterestCopy: string;
  } | null>(null);

  const origin =
    typeof window !== 'undefined' ? window.location.origin : 'https://linkaisle.com';
  const baseStoreUrl = `${origin}/s/${store.slug}`;
  const selectedProduct = products.find((p) => p.id === selectedId) || null;

  async function handleGenerateAiScripts() {
    setGeneratingAi(true);
    try {
      const res = await fetch('/api/ai/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          task: 'viral_script',
          lang,
          store_name: store.name,
          store_url: baseStoreUrl,
          product: selectedProduct
            ? {
                title: selectedProduct.title,
                category: selectedProduct.category,
                price_display: selectedProduct.price_display,
                benefits: selectedProduct.benefits,
              }
            : null,
        }),
      });
      if (res.ok) {
        const json = await res.json();
        setAiOverride(json.data);
        setAiProviderLabel(json.providerLabel || 'AI Engine');
      }
    } finally {
      setGeneratingAi(false);
    }
  }

  function copyText(key: string, text: string) {
    navigator.clipboard?.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  }

  const topCount = Math.min(products.length || 5, 5);
  const topNames = products
    .slice(0, 3)
    .map((p) => p.title)
    .join(', ');

  // 1. Short-Form Video Script (TikTok / Reels / YouTube Shorts)
  const videoScript = selectedProduct
    ? `🎬 20-SECOND TIKTOK / REELS / SHORTS SCRIPT\n\n[0–3s HOOK]\n"Stop overpaying for clunky ${selectedProduct.category.toLowerCase()} gear — this ${selectedProduct.price_display || ''} find fixed my daily routine."\n\n[3–14s SHOWCASE]\n"Meet the ${selectedProduct.title}:\n${
        selectedProduct.benefits?.length
          ? selectedProduct.benefits
              .slice(0, 3)
              .map((b) => `• ${b}`)
              .join('\n')
          : `• ${selectedProduct.short_description || 'Practical everyday upgrade'}`
      }"\n\n[15–20s CALL TO ACTION]\n"I saved it inside my curated '${store.name}' collection — link in bio!"\n\n🔗 Tracked Link: ${baseStoreUrl}?src=tiktok\n#amazonfinds #usefulgadgets #${selectedProduct.category.toLowerCase().replace(/\s+/g, '')}`
    : `🎬 MULTI-PRODUCT COLLECTION VIDEO SCRIPT\n\n[0–3s HOOK]\n"Top ${topCount} practical upgrades that actually save time every single day — wait for #2!"\n\n[3–15s SHOWCASE]\n"Featured today: ${topNames || 'Smart Kitchen Scale, Rechargeable Frother, Pantry Organizers'}.\nInstead of hunting across dozens of tabs, I curated every tested deal in one clean list."\n\n[15–20s CALL TO ACTION]\n"Browse the full ${store.name} collection using the link in my bio!"\n\n🔗 Tracked Link: ${baseStoreUrl}?src=tiktok`;

  // 2. Facebook / Instagram Ad & Post Copy
  const fbAdCopy = selectedProduct
    ? `📣 FACEBOOK / INSTAGRAM AD & POST COPY\n\nHeadline: ${selectedProduct.title} (${selectedProduct.price_display || 'Curated Pick'})\n\nPrimary Text:\nLooking for a practical upgrade without the hype? ${selectedProduct.short_description || ''}\n\n${
        selectedProduct.benefits?.slice(0, 3).map((b) => `✔️ ${b}`).join('\n') || '✔️ Handpicked for daily value'
      }\n\n👉 Browse this deal + our full curated ${store.name} collection:\n${baseStoreUrl}?src=facebook\n\n(Affiliate disclosure: We may earn a commission on qualifying purchases at no extra cost to you.)`
    : `📣 MULTI-PRODUCT FACEBOOK CAMPAIGN COPY\n\nHeadline: Top ${topCount} Time-Saving Finds in One Curated List — ${store.name}\n\nPrimary Text:\nWhy browse random listings? We curated ${products.length || 6}+ practical upgrades (${topNames || 'Kitchen & Home essentials'}) on one clean page.\n\n👉 Explore the full collection: ${baseStoreUrl}?src=facebook\n\n(Note: Always confirm paid social ad rules in your affiliate program agreement before boosting.)`;

  // 3. Pinterest Pin SEO Copy
  const pinterestCopy = selectedProduct
    ? `📌 PINTEREST PIN TITLE:\n${selectedProduct.title} | ${selectedProduct.category} Must-Have (${selectedProduct.price_display || 'Deal'})\n\n📌 PIN DESCRIPTION:\n${selectedProduct.short_description || selectedProduct.description} Discover this and more handpicked ${selectedProduct.category.toLowerCase()} finds inside ${store.name}.\n\n🔗 Destination URL: ${baseStoreUrl}?src=pinterest`
    : `📌 PINTEREST PIN TITLE:\nTop ${topCount} Curated ${store.name} Finds Worth Saving\n\n📌 PIN DESCRIPTION:\n${store.tagline} Save this curated collection featuring ${topNames || 'our top handpicked finds'} and check current prices anytime.\n\n🔗 Destination URL: ${baseStoreUrl}?src=pinterest`;

  const finalVideoScript = aiOverride?.videoScript || videoScript;
  const finalFbAdCopy = aiOverride?.fbAdCopy || fbAdCopy;
  const finalPinterestCopy = aiOverride?.pinterestCopy || pinterestCopy;

  return (
    <div className="space-y-6">
      {/* HEADER CONTROLS */}
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-50 text-[#047857]">
              <Megaphone className="h-5 w-5" />
            </div>
            <div>
              <h2 className="font-display text-lg font-extrabold text-[#111315]">
                Creator Marketing Kit &amp; Viral Script Builder
              </h2>
              <p className="text-xs text-stone-500">
                Generate ready-to-post TikTok/Reels scripts, Facebook ad copy, and tracked campaign URLs in 1 click.
              </p>
            </div>
          </div>

          <div className="inline-flex items-center gap-2 rounded-full border border-emerald-200 bg-emerald-50 px-3.5 py-1.5 text-xs font-bold text-[#047857]">
            <Sparkles className="h-3.5 w-3.5" />
            AI-Powered Social &amp; Ad Copy
          </div>
        </div>

        <div className="mt-5 flex flex-wrap items-end justify-between gap-4">
          <div className="flex-1 min-w-[240px]">
            <label className="block text-xs font-bold text-stone-700 mb-1.5">
              Generate Promotion Scripts For:
            </label>
            <select
              value={selectedId}
              onChange={(e) => {
                setSelectedId(e.target.value);
                setAiOverride(null);
              }}
              className="w-full sm:max-w-lg rounded-xl border border-stone-300 bg-white px-4 py-2.5 text-sm font-medium focus:border-[#047857] focus:outline-none"
            >
              <option value="collection">
                Entire Multi-Product Store Collection ({products.length} products)
              </option>
              {products.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.title} ({p.price_display || p.category})
                </option>
              ))}
            </select>
          </div>
          <div className="flex items-center gap-2.5">
            {aiProviderLabel && (
              <span className="rounded-full bg-emerald-50 border border-emerald-200 px-3 py-1 text-[11px] font-bold text-[#047857]">
                Written by {aiProviderLabel}
              </span>
            )}
            <button
              type="button"
              disabled={generatingAi}
              onClick={handleGenerateAiScripts}
              className="inline-flex items-center gap-2 rounded-xl bg-[#111315] px-4 py-2.5 text-xs font-bold text-white shadow-sm hover:bg-[#047857] transition-colors disabled:opacity-60"
            >
              <Sparkles className={`h-4 w-4 ${generatingAi ? 'animate-spin' : ''}`} />
              {generatingAi ? 'Generating AI Copy...' : 'Generate Fresh AI Scripts'}
            </button>
          </div>
        </div>
      </div>

      {/* TRACKED CHANNEL LINKS */}
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex items-center gap-2 mb-3">
          <Link2 className="h-4 w-4 text-indigo-600" />
          <h3 className="font-display text-base font-bold text-slate-900">
            Channel-Tracked Store Links (Auto-Tracked in Real Analytics)
          </h3>
        </div>
        <p className="text-xs text-slate-500 mb-4">
          Use a different tagged link on each social app so your Analytics dashboard shows exactly which channel drives real visits & clicks.
        </p>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {CHANNELS.map((ch) => {
            const url = `${baseStoreUrl}?src=${ch.id}`;
            const isCopied = copiedKey === `ch-${ch.id}`;
            return (
              <div
                key={ch.id}
                className="flex items-center justify-between gap-2 rounded-xl border border-slate-200 bg-slate-50 p-3"
              >
                <div className="min-w-0">
                  <p className="text-xs font-bold text-slate-800">{ch.label}</p>
                  <p className="truncate font-mono text-[11px] text-slate-500">?src={ch.id}</p>
                </div>
                <button
                  type="button"
                  onClick={() => copyText(`ch-${ch.id}`, url)}
                  className="inline-flex items-center gap-1 rounded-lg bg-white border border-slate-200 px-2.5 py-1.5 text-xs font-bold text-slate-700 hover:border-indigo-300 hover:text-indigo-600 shrink-0"
                >
                  {isCopied ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                  {isCopied ? 'Copied' : 'Copy'}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* SCRIPT CARDS */}
      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Video className="h-4 w-4 text-rose-500" />
                <h3 className="font-display text-sm font-bold text-slate-900">
                  TikTok / Reels / Shorts Video Script
                </h3>
              </div>
              <button
                type="button"
                onClick={() => copyText('video', finalVideoScript)}
                className="inline-flex items-center gap-1 rounded-lg bg-emerald-50 border border-emerald-200 px-3 py-1.5 text-xs font-bold text-[#047857] hover:bg-emerald-100"
              >
                {copiedKey === 'video' ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                {copiedKey === 'video' ? 'Copied!' : 'Copy Script'}
              </button>
            </div>
            <pre className="whitespace-pre-wrap rounded-xl bg-[#FAFAF9] border border-stone-200 p-4 text-xs leading-relaxed text-stone-800 font-sans">
              {finalVideoScript}
            </pre>
          </div>
        </div>

        <div className="rounded-2xl border border-stone-200 bg-white p-6 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Share2 className="h-4 w-4 text-[#047857]" />
                <h3 className="font-display text-sm font-bold text-[#111315]">
                  Facebook / Instagram Post &amp; Ad Copy
                </h3>
              </div>
              <button
                type="button"
                onClick={() => copyText('fb', finalFbAdCopy)}
                className="inline-flex items-center gap-1 rounded-lg bg-emerald-50 border border-emerald-200 px-3 py-1.5 text-xs font-bold text-[#047857] hover:bg-emerald-100"
              >
                {copiedKey === 'fb' ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                {copiedKey === 'fb' ? 'Copied!' : 'Copy Ad'}
              </button>
            </div>
            <pre className="whitespace-pre-wrap rounded-xl bg-[#FAFAF9] border border-stone-200 p-4 text-xs leading-relaxed text-stone-800 font-sans">
              {finalFbAdCopy}
            </pre>
          </div>
        </div>
      </div>

      {/* PINTEREST + COMPLIANCE NOTE */}
      <div className="rounded-2xl border border-stone-200 bg-white p-6 shadow-sm">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-amber-500" />
            <h3 className="font-display text-sm font-bold text-[#111315]">
              Pinterest Visual Search Pin Copy
            </h3>
          </div>
          <button
            type="button"
            onClick={() => copyText('pin', finalPinterestCopy)}
            className="inline-flex items-center gap-1 rounded-lg bg-emerald-50 border border-emerald-200 px-3 py-1.5 text-xs font-bold text-[#047857] hover:bg-emerald-100"
          >
            {copiedKey === 'pin' ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
            {copiedKey === 'pin' ? 'Copied!' : 'Copy Pin'}
          </button>
        </div>
        <pre className="whitespace-pre-wrap rounded-xl bg-[#FAFAF9] border border-stone-200 p-4 text-xs leading-relaxed text-stone-800 font-sans">
          {finalPinterestCopy}
        </pre>
        <div className="mt-4 flex items-start gap-2 rounded-xl bg-amber-50 border border-amber-200 p-3 text-xs text-amber-900">
          <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5 text-amber-600" />
          <p>
            <strong>Compliance Reminder:</strong> Always check each affiliate program&apos;s current rules
            (Amazon Associates, Impact brands, etc.) regarding paid ads, disclosures, and link sharing before launching paid campaigns.
          </p>
        </div>
      </div>
    </div>
  );
}
