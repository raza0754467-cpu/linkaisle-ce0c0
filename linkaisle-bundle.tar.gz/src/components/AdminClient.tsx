'use client';

import { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  BarChart3,
  BookOpen,
  CheckCircle2,
  CreditCard,
  DollarSign,
  Edit3,
  ExternalLink,
  Globe,
  LayoutDashboard,
  LogOut,
  Megaphone,
  MousePointerClick,
  Plus,
  RefreshCw,
  Save,
  Settings,
  ShieldAlert,
  ShieldCheck,
  Store as StoreIcon,
  Trash2,
  Users,
  Wrench,
  X,
  XCircle,
} from 'lucide-react';
import {
  AcademyLesson,
  MonetizationConfig,
  PartnerTool,
  PlanLimits,
  UpgradeRequest,
  User,
} from '@/lib/types';

type AdminTab = 'overview' | 'billing' | 'monetization' | 'users' | 'stores' | 'academy' | 'settings';

interface AdminUserRow {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'admin';
  plan: 'free' | 'starter' | 'pro';
  status: 'active' | 'suspended';
  created_at: string;
  store_count: number;
  product_count: number;
}

interface AdminStoreRow {
  id: string;
  name: string;
  slug: string;
  template: string;
  is_published: number;
  is_suspended: number;
  owner_name: string;
  owner_email: string;
  owner_plan: string;
  product_count: number;
  visits: number;
  impressions: number;
  clicks: number;
}

interface AdminOverviewData {
  analytics: {
    counts: Record<string, number>;
    traffic: {
      platformVisits: number;
      allStoreVisits: number;
      allImpressions: number;
      allClicks: number;
      uniqueVisitors: number;
    };
    topStores: AdminStoreRow[];
    referrers: { source: string; count: number }[];
  };
  settings: {
    platform_name: string;
    platform_tagline: string;
    plan_limits: PlanLimits;
    allow_registrations: boolean;
    monetization: MonetizationConfig;
  };
  users: AdminUserRow[];
  lessons: AcademyLesson[];
  billing: {
    requests: UpgradeRequest[];
    approvedRevenueUsd: number;
    pendingCount: number;
    approvedCount: number;
    paidUsersCount: number;
  };
  partnerTools: PartnerTool[];
  totalToolClicks: number;
}

export default function AdminClient({ currentUser }: { currentUser: User }) {
  const router = useRouter();
  const [tab, setTab] = useState<AdminTab>('overview');
  const [data, setData] = useState<AdminOverviewData | null>(null);
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState<{ type: 'success' | 'error'; msg: string } | null>(null);

  const [settingsForm, setSettingsForm] = useState<AdminOverviewData['settings'] | null>(null);

  // Academy Lesson Modal
  const [showLessonModal, setShowLessonModal] = useState(false);
  const [lessonForm, setLessonForm] = useState({
    module_number: 1,
    title: '',
    summary: '',
    content: '## Key Concept\nExplain the practical step clearly.\n\n- Action item 1\n- Action item 2',
    title_ur: '',
    summary_ur: '',
    content_ur: '',
    duration_minutes: 6,
    level: 'Beginner' as 'Beginner' | 'Intermediate' | 'Pro',
  });

  // Partner Tool Modal
  const [showToolModal, setShowToolModal] = useState(false);
  const [editingTool, setEditingTool] = useState<PartnerTool | null>(null);
  const [toolForm, setToolForm] = useState({
    name: '',
    category: 'Affiliate Networks',
    tagline: '',
    description: '',
    affiliate_url: '',
    commission_note: '',
    badge: '',
  });

  const notify = (type: 'success' | 'error', msg: string) => {
    setToast({ type, msg });
    setTimeout(() => setToast(null), 3500);
  };

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/overview');
      if (res.ok) {
        const json = (await res.json()) as AdminOverviewData;
        setData(json);
        setSettingsForm(json.settings);
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  async function updateUser(userId: string, patch: Record<string, string>) {
    const res = await fetch('/api/admin/users', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, ...patch }),
    });
    const d = await res.json();
    if (!res.ok) {
      notify('error', d.error || 'Failed to update user');
      return;
    }
    notify('success', 'User updated');
    loadData();
  }

  async function toggleStoreSuspension(storeId: string, currentlySuspended: boolean) {
    const res = await fetch('/api/admin/stores', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ storeId, is_suspended: !currentlySuspended }),
    });
    if (res.ok) {
      notify('success', currentlySuspended ? 'Store reactivated' : 'Store suspended');
      loadData();
    }
  }

  async function handleBillingAction(requestId: string, action: 'approve' | 'reject') {
    const adminNote =
      action === 'approve'
        ? 'Payment verified — plan upgraded!'
        : prompt('Optional rejection note for the user:') || 'Could not verify transaction reference.';
    const res = await fetch('/api/admin/billing', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ requestId, action, admin_note: adminNote }),
    });
    const d = await res.json();
    if (!res.ok) {
      notify('error', d.error || 'Action failed');
      return;
    }
    notify('success', action === 'approve' ? 'Request approved & user upgraded!' : 'Request rejected');
    loadData();
  }

  function openNewTool() {
    setEditingTool(null);
    setToolForm({
      name: '',
      category: 'Affiliate Networks',
      tagline: '',
      description: '',
      affiliate_url: '',
      commission_note: '',
      badge: 'Recommended',
    });
    setShowToolModal(true);
  }

  function openEditTool(t: PartnerTool) {
    setEditingTool(t);
    setToolForm({
      name: t.name,
      category: t.category,
      tagline: t.tagline,
      description: t.description,
      affiliate_url: t.affiliate_url,
      commission_note: t.commission_note,
      badge: t.badge,
    });
    setShowToolModal(true);
  }

  async function handleSaveTool(e: React.FormEvent) {
    e.preventDefault();
    const res = await fetch('/api/admin/tools', {
      method: editingTool ? 'PATCH' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(editingTool ? { id: editingTool.id, ...toolForm } : toolForm),
    });
    const d = await res.json();
    if (!res.ok) {
      notify('error', d.error || 'Failed to save partner tool');
      return;
    }
    setShowToolModal(false);
    notify('success', editingTool ? 'Partner tool updated!' : 'Partner tool added to /tools!');
    loadData();
  }

  async function handleDeleteTool(id: string) {
    if (!confirm('Remove this partner tool?')) return;
    const res = await fetch(`/api/admin/tools?id=${encodeURIComponent(id)}`, { method: 'DELETE' });
    if (res.ok) {
      notify('success', 'Tool removed');
      loadData();
    }
  }

  async function handleCreateLesson(e: React.FormEvent) {
    e.preventDefault();
    const res = await fetch('/api/admin/lessons', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(lessonForm),
    });
    const d = await res.json();
    if (!res.ok) {
      notify('error', d.error || 'Failed to create lesson');
      return;
    }
    setShowLessonModal(false);
    setLessonForm({
      module_number: 1,
      title: '',
      summary: '',
      content: '## Key Concept\nWrite clear step-by-step affiliate guidance here.',
      title_ur: '',
      summary_ur: '',
      content_ur: '',
      duration_minutes: 6,
      level: 'Beginner',
    });
    notify('success', 'Academy lesson published!');
    loadData();
  }

  async function deleteLesson(id: string) {
    if (!confirm('Delete this academy lesson?')) return;
    const res = await fetch(`/api/admin/lessons?id=${encodeURIComponent(id)}`, { method: 'DELETE' });
    if (res.ok) {
      notify('success', 'Lesson deleted');
      loadData();
    }
  }

  async function saveSettings(e: React.FormEvent) {
    e.preventDefault();
    if (!settingsForm) return;
    const res = await fetch('/api/admin/settings', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settingsForm),
    });
    if (res.ok) {
      notify('success', 'Platform settings & monetization config saved!');
      loadData();
    } else {
      notify('error', 'Failed to save settings');
    }
  }

  async function handleLogout() {
    await fetch('/api/auth/logout', { method: 'POST' });
    router.push('/');
    router.refresh();
  }

  return (
    <div className="min-h-screen bg-[#F4F4F2] flex flex-col lg:flex-row text-[#111315]">
      {toast && (
        <div
          className={`fixed bottom-5 right-5 z-50 rounded-2xl px-4 py-3 text-sm font-semibold text-white shadow-xl ${
            toast.type === 'success' ? 'bg-[#047857]' : 'bg-rose-600'
          }`}
        >
          {toast.msg}
        </div>
      )}

      {/* CLEAN LIGHT EXECUTIVE ADMIN SIDEBAR */}
      <aside className="w-full lg:w-64 shrink-0 bg-white text-stone-800 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-stone-200">
        <div>
          <div className="p-5 border-b border-stone-200">
            <div className="flex items-center gap-2 text-[#047857]">
              <ShieldCheck className="h-5 w-5" />
              <span className="font-display text-base font-extrabold text-[#111315]">
                Owner Control Room
              </span>
            </div>
            <p className="mt-1 text-[11px] text-stone-500">LinkAisle Executive Dashboard</p>
          </div>

          <nav className="p-3 space-y-1">
            {[
              { id: 'overview', label: 'Platform Analytics', icon: BarChart3 },
              {
                id: 'billing',
                label: `Billing & Revenue${data?.billing.pendingCount ? ` (${data.billing.pendingCount})` : ''}`,
                icon: CreditCard,
              },
              { id: 'monetization', label: 'Networks & Ad Slots', icon: Megaphone },
              { id: 'users', label: `Users & Plans (${data?.users.length ?? 0})`, icon: Users },
              {
                id: 'stores',
                label: `Stores (${data?.analytics.topStores.length ?? 0})`,
                icon: StoreIcon,
              },
              { id: 'academy', label: `Academy (${data?.lessons.length ?? 0})`, icon: BookOpen },
              { id: 'settings', label: 'Platform Settings', icon: Settings },
            ].map((item) => {
              const Icon = item.icon;
              const active = tab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setTab(item.id as AdminTab)}
                  className={`w-full flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-semibold transition-colors ${
                    active
                      ? 'bg-[#111315] text-white shadow-sm'
                      : 'text-stone-600 hover:bg-stone-100 hover:text-[#111315]'
                  }`}
                >
                  <Icon className={`h-4 w-4 shrink-0 ${active ? 'text-emerald-400' : 'text-stone-400'}`} />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}

            <div className="pt-4 mt-4 border-t border-stone-200 space-y-1">
              <Link
                href="/dashboard"
                className="flex items-center gap-3 rounded-xl px-3.5 py-2 text-xs font-semibold text-stone-600 hover:bg-stone-100 hover:text-[#111315]"
              >
                <LayoutDashboard className="h-4 w-4 text-[#047857]" />
                Creator Studio
              </Link>
              <Link
                href="/tools"
                className="flex items-center gap-3 rounded-xl px-3.5 py-2 text-xs font-semibold text-stone-600 hover:bg-stone-100 hover:text-[#111315]"
              >
                <Wrench className="h-4 w-4 text-stone-500" />
                Affiliate Networks Page
              </Link>
              <Link
                href="/"
                className="flex items-center gap-3 rounded-xl px-3.5 py-2 text-xs font-semibold text-stone-600 hover:bg-stone-100 hover:text-[#111315]"
              >
                <Globe className="h-4 w-4 text-stone-500" />
                Main Website
              </Link>
            </div>
          </nav>
        </div>

        <div className="p-4 border-t border-stone-200 bg-[#FAFAF9] flex items-center justify-between">
          <div className="min-w-0">
            <p className="truncate text-xs font-bold text-[#111315]">{currentUser.name}</p>
            <p className="truncate text-[11px] font-semibold text-[#047857]">{currentUser.email}</p>
          </div>
          <button
            type="button"
            onClick={handleLogout}
            className="rounded-lg p-2 text-stone-500 hover:bg-stone-200/70 hover:text-[#111315]"
          >
            <LogOut className="h-4 w-4" />
          </button>
        </div>
      </aside>

      {/* MAIN ADMIN AREA */}
      <main className="flex-1 min-w-0 p-5 sm:p-8 lg:p-10">
        <div className="mx-auto max-w-6xl space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h1 className="font-display text-2xl font-extrabold text-[#111315]">
                {data?.settings.platform_name || 'LinkAisle'} — Owner Control Center
              </h1>
              <p className="text-xs text-slate-500">
                100% real database metrics across traffic, subscriptions, partner tools, and tenant stores.
              </p>
            </div>
            <button
              type="button"
              onClick={loadData}
              className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50 shadow-sm"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
              Refresh Live Data
            </button>
          </div>

          {loading && !data ? (
            <div className="rounded-2xl border border-slate-200 bg-white p-12 text-center text-slate-500">
              Loading real platform analytics...
            </div>
          ) : data ? (
            <>
              {/* TAB 1: OVERVIEW */}
              {tab === 'overview' && (
                <div className="space-y-6">
                  <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
                    {[
                      {
                        label: 'Approved Revenue',
                        value: `$${data.billing.approvedRevenueUsd.toFixed(2)}`,
                        sub: `${data.billing.paidUsersCount} paid tier user(s)`,
                        icon: DollarSign,
                        tone: 'text-emerald-600 bg-emerald-50',
                      },
                      {
                        label: 'Platform Visits',
                        value: data.analytics.traffic.platformVisits,
                        sub: `${data.analytics.traffic.uniqueVisitors} unique visitors`,
                        icon: Globe,
                        tone: 'text-indigo-600 bg-indigo-50',
                      },
                      {
                        label: 'All-Stores Visits',
                        value: data.analytics.traffic.allStoreVisits,
                        sub: `${data.analytics.counts.live_stores} live stores`,
                        icon: StoreIcon,
                        tone: 'text-violet-600 bg-violet-50',
                      },
                      {
                        label: 'Product Impressions',
                        value: data.analytics.traffic.allImpressions,
                        sub: `${data.analytics.counts.total_products} products listed`,
                        icon: BarChart3,
                        tone: 'text-amber-600 bg-amber-50',
                      },
                      {
                        label: 'Affiliate + Tool Clicks',
                        value: data.analytics.traffic.allClicks + data.totalToolClicks,
                        sub: `${data.analytics.traffic.allClicks} store · ${data.totalToolClicks} tools`,
                        icon: MousePointerClick,
                        tone: 'text-cyan-600 bg-cyan-50',
                      },
                    ].map((card) => {
                      const Icon = card.icon;
                      return (
                        <div key={card.label} className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
                          <div className={`inline-flex h-9 w-9 items-center justify-center rounded-xl ${card.tone}`}>
                            <Icon className="h-4 w-4" />
                          </div>
                          <p className="mt-3 text-xs font-semibold text-slate-500">{card.label}</p>
                          <p className="mt-1 font-display text-2xl font-extrabold text-slate-900">
                            {card.value}
                          </p>
                          <p className="mt-1 text-[11px] text-slate-400">{card.sub}</p>
                        </div>
                      );
                    })}
                  </div>

                  <div className="grid gap-6 lg:grid-cols-3">
                    <div className="lg:col-span-2 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                      <h2 className="font-display text-base font-bold text-slate-900 mb-4">
                        Top Storefronts by Real Activity
                      </h2>
                      <div className="overflow-x-auto">
                        <table className="w-full text-left text-xs">
                          <thead className="border-b border-slate-200 text-slate-500 uppercase">
                            <tr>
                              <th className="pb-2.5">Store</th>
                              <th className="pb-2.5">Owner</th>
                              <th className="pb-2.5 text-right">Visits</th>
                              <th className="pb-2.5 text-right">Impressions</th>
                              <th className="pb-2.5 text-right">Clicks</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100">
                            {data.analytics.topStores.map((s) => (
                              <tr key={s.id}>
                                <td className="py-3 font-bold text-slate-900">
                                  <Link href={`/s/${s.slug}`} target="_blank" className="hover:text-indigo-600">
                                    {s.name}
                                  </Link>
                                </td>
                                <td className="py-3 text-slate-600">{s.owner_name}</td>
                                <td className="py-3 text-right font-mono">{s.visits}</td>
                                <td className="py-3 text-right font-mono">{s.impressions}</td>
                                <td className="py-3 text-right font-mono font-bold text-emerald-600">
                                  {s.clicks}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>

                    <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                      <h2 className="font-display text-base font-bold text-slate-900 mb-4">
                        Platform Referrer Sources
                      </h2>
                      {data.analytics.referrers.length === 0 ? (
                        <p className="text-xs text-slate-400">No visits recorded yet.</p>
                      ) : (
                        <div className="space-y-3">
                          {data.analytics.referrers.map((r) => (
                            <div key={r.source} className="flex items-center justify-between text-xs">
                              <span className="font-semibold text-slate-700">{r.source}</span>
                              <span className="rounded-full bg-indigo-50 px-2.5 py-0.5 font-mono font-bold text-indigo-700">
                                {r.count}
                              </span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: BILLING & REVENUE */}
              {tab === 'billing' && (
                <div className="space-y-6">
                  <div className="grid gap-4 sm:grid-cols-3">
                    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                      <p className="text-xs font-semibold text-slate-500">Approved Subscription Revenue</p>
                      <p className="mt-1 font-display text-3xl font-extrabold text-emerald-600">
                        ${data.billing.approvedRevenueUsd.toFixed(2)}
                      </p>
                      <p className="mt-1 text-[11px] text-slate-400">
                        {data.billing.approvedCount} approved order(s)
                      </p>
                    </div>
                    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                      <p className="text-xs font-semibold text-slate-500">Pending Payment Reviews</p>
                      <p className="mt-1 font-display text-3xl font-extrabold text-amber-600">
                        {data.billing.pendingCount}
                      </p>
                      <p className="mt-1 text-[11px] text-slate-400">Verify TXN Ref before approving</p>
                    </div>
                    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                      <p className="text-xs font-semibold text-slate-500">Active Starter / Pro Users</p>
                      <p className="mt-1 font-display text-3xl font-extrabold text-indigo-600">
                        {data.billing.paidUsersCount}
                      </p>
                      <p className="mt-1 text-[11px] text-slate-400">Across {data.users.length} total users</p>
                    </div>
                  </div>

                  <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                    <div className="border-b border-slate-200 px-5 py-4">
                      <h2 className="font-display text-base font-bold text-slate-900">
                        Creator Subscription Upgrade Requests
                      </h2>
                      <p className="text-xs text-slate-500">
                        Approve a request to automatically upgrade that user&apos;s plan limits in real time.
                      </p>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-sm">
                        <thead className="border-b border-slate-200 bg-slate-50 text-xs font-bold uppercase text-slate-500">
                          <tr>
                            <th className="px-4 py-3">User</th>
                            <th className="px-4 py-3">Requested Plan</th>
                            <th className="px-4 py-3">Payment / Reference</th>
                            <th className="px-4 py-3">Status</th>
                            <th className="px-4 py-3 text-right">Review</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {data.billing.requests.length === 0 ? (
                            <tr>
                              <td colSpan={5} className="px-4 py-12 text-center text-xs text-slate-400">
                                No upgrade requests submitted yet. Creators can submit requests from Studio → Billing & Plan.
                              </td>
                            </tr>
                          ) : (
                            data.billing.requests.map((r) => (
                              <tr key={r.id}>
                                <td className="px-4 py-3.5">
                                  <p className="font-bold text-slate-900">{r.user_name}</p>
                                  <p className="text-xs text-slate-500">{r.user_email}</p>
                                </td>
                                <td className="px-4 py-3.5 text-xs">
                                  <span className="font-bold uppercase text-indigo-700">
                                    {r.requested_plan}
                                  </span>{' '}
                                  ({r.billing_cycle}) — <strong>${r.amount_usd}</strong>
                                </td>
                                <td className="px-4 py-3.5 text-xs">
                                  <p className="font-semibold text-slate-800">{r.payment_method}</p>
                                  <p className="font-mono text-slate-500">Ref: {r.transaction_ref}</p>
                                  {r.notes && <p className="text-[11px] text-slate-400">{r.notes}</p>}
                                </td>
                                <td className="px-4 py-3.5">
                                  <span
                                    className={`rounded-full px-2.5 py-0.5 text-[11px] font-bold uppercase ${
                                      r.status === 'approved'
                                        ? 'bg-emerald-50 text-emerald-700'
                                        : r.status === 'rejected'
                                          ? 'bg-rose-50 text-rose-700'
                                          : 'bg-amber-50 text-amber-800'
                                    }`}
                                  >
                                    {r.status}
                                  </span>
                                </td>
                                <td className="px-4 py-3.5 text-right">
                                  {r.status === 'pending' ? (
                                    <div className="inline-flex gap-2">
                                      <button
                                        type="button"
                                        onClick={() => handleBillingAction(r.id, 'approve')}
                                        className="inline-flex items-center gap-1 rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-emerald-700"
                                      >
                                        <CheckCircle2 className="h-3.5 w-3.5" /> Approve
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() => handleBillingAction(r.id, 'reject')}
                                        className="inline-flex items-center gap-1 rounded-lg bg-rose-50 px-3 py-1.5 text-xs font-bold text-rose-700 hover:bg-rose-100"
                                      >
                                        <XCircle className="h-3.5 w-3.5" /> Reject
                                      </button>
                                    </div>
                                  ) : (
                                    <span className="text-xs text-slate-400">Processed</span>
                                  )}
                                </td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: PARTNER TOOLS & DISPLAY AD SLOTS */}
              {tab === 'monetization' && settingsForm && (
                <div className="space-y-6">
                  {/* PARTNER AFFILIATE TOOLS */}
                  <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                    <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
                      <div>
                        <h2 className="font-display text-lg font-bold text-slate-900">
                          Owner&apos;s Recommended Affiliate Tools (/tools)
                        </h2>
                        <p className="text-xs text-stone-500">
                          Replace these URLs with your own affiliate referral links (Amazon Associates, Impact, Daraz Affiliate, Canva) — every click is tracked in real time.
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={openNewTool}
                        className="inline-flex items-center gap-1.5 rounded-xl bg-[#111315] px-4 py-2 text-xs font-bold text-white hover:bg-[#047857] transition-colors"
                      >
                        <Plus className="h-4 w-4" /> Add Partner Tool
                      </button>
                    </div>

                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead className="border-b border-slate-200 text-slate-500 uppercase">
                          <tr>
                            <th className="pb-2.5">Tool</th>
                            <th className="pb-2.5">Category</th>
                            <th className="pb-2.5">Affiliate URL</th>
                            <th className="pb-2.5 text-right">Real Clicks</th>
                            <th className="pb-2.5 text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {data.partnerTools.map((t) => (
                            <tr key={t.id}>
                              <td className="py-3">
                                <p className="font-bold text-slate-900">{t.name}</p>
                                <p className="text-[11px] text-slate-500">{t.commission_note}</p>
                              </td>
                              <td className="py-3 text-slate-600">{t.category}</td>
                              <td className="py-3 font-mono text-[11px] text-indigo-700 max-w-xs truncate">
                                {t.affiliate_url}
                              </td>
                              <td className="py-3 text-right font-mono font-bold text-emerald-600">
                                {t.clicks}
                              </td>
                              <td className="py-3 text-right">
                                <div className="inline-flex gap-1.5">
                                  <button
                                    type="button"
                                    onClick={() => openEditTool(t)}
                                    className="rounded-lg border border-slate-200 p-1.5 text-slate-600 hover:text-indigo-600"
                                  >
                                    <Edit3 className="h-3.5 w-3.5" />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleDeleteTool(t.id)}
                                    className="rounded-lg border border-slate-200 p-1.5 text-slate-600 hover:text-rose-600"
                                  >
                                    <Trash2 className="h-3.5 w-3.5" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* DISPLAY AD / SPONSOR SLOT & PAYMENT INSTRUCTIONS */}
                  <form
                    onSubmit={saveSettings}
                    className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-5"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-4">
                      <div>
                        <h2 className="font-display text-lg font-bold text-slate-900">
                          Display Ad / Sponsor Slots & Payment Instructions
                        </h2>
                        <p className="text-xs text-slate-500">
                          Keep OFF during early free launch, or toggle ON to display a clean sponsored banner inside Academy pages (ready for AdSense/Raptive once domain is approved).
                        </p>
                      </div>
                      <label className="inline-flex items-center gap-2 rounded-xl border border-amber-200 bg-amber-50 px-4 py-2 text-xs font-bold text-amber-900 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={settingsForm.monetization.ads_enabled}
                          onChange={(e) =>
                            setSettingsForm({
                              ...settingsForm,
                              monetization: {
                                ...settingsForm.monetization,
                                ads_enabled: e.target.checked,
                              },
                            })
                          }
                          className="h-4 w-4 accent-amber-600"
                        />
                        Enable Academy Sponsor / Ad Slot
                      </label>
                    </div>

                    <div className="grid gap-4 sm:grid-cols-2">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Ad / Sponsor Label
                        </label>
                        <input
                          type="text"
                          value={settingsForm.monetization.ad_network_label}
                          onChange={(e) =>
                            setSettingsForm({
                              ...settingsForm,
                              monetization: {
                                ...settingsForm.monetization,
                                ad_network_label: e.target.value,
                              },
                            })
                          }
                          className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Banner Headline
                        </label>
                        <input
                          type="text"
                          value={settingsForm.monetization.ad_sponsor_title}
                          onChange={(e) =>
                            setSettingsForm({
                              ...settingsForm,
                              monetization: {
                                ...settingsForm.monetization,
                                ad_sponsor_title: e.target.value,
                              },
                            })
                          }
                          className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                        />
                      </div>
                      <div className="sm:col-span-2">
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Banner Description
                        </label>
                        <input
                          type="text"
                          value={settingsForm.monetization.ad_sponsor_desc}
                          onChange={(e) =>
                            setSettingsForm({
                              ...settingsForm,
                              monetization: {
                                ...settingsForm.monetization,
                                ad_sponsor_desc: e.target.value,
                              },
                            })
                          }
                          className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          CTA Button Text
                        </label>
                        <input
                          type="text"
                          value={settingsForm.monetization.ad_sponsor_cta_text}
                          onChange={(e) =>
                            setSettingsForm({
                              ...settingsForm,
                              monetization: {
                                ...settingsForm.monetization,
                                ad_sponsor_cta_text: e.target.value,
                              },
                            })
                          }
                          className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          CTA Destination URL (/tools or https://...)
                        </label>
                        <input
                          type="text"
                          value={settingsForm.monetization.ad_sponsor_cta_url}
                          onChange={(e) =>
                            setSettingsForm({
                              ...settingsForm,
                              monetization: {
                                ...settingsForm.monetization,
                                ad_sponsor_cta_url: e.target.value,
                              },
                            })
                          }
                          className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm font-mono"
                        />
                      </div>
                      <div className="sm:col-span-2">
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Creator Subscription Payment Instructions (Shown in Studio → Billing & Plan)
                        </label>
                        <textarea
                          rows={3}
                          value={settingsForm.monetization.payment_instructions}
                          onChange={(e) =>
                            setSettingsForm({
                              ...settingsForm,
                              monetization: {
                                ...settingsForm.monetization,
                                payment_instructions: e.target.value,
                              },
                            })
                          }
                          className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                        />
                      </div>
                    </div>

                    <div className="flex justify-end">
                      <button
                        type="submit"
                        className="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-6 py-3 text-sm font-bold text-white hover:bg-slate-800"
                      >
                        <Save className="h-4 w-4" /> Save Monetization Settings
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* TAB 4: USERS & PLANS */}
              {tab === 'users' && (
                <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm">
                      <thead className="border-b border-slate-200 bg-slate-50 text-xs font-bold uppercase text-slate-500">
                        <tr>
                          <th className="px-4 py-3.5">User</th>
                          <th className="px-4 py-3.5">Plan Tier</th>
                          <th className="px-4 py-3.5">Stores / Products</th>
                          <th className="px-4 py-3.5">Status</th>
                          <th className="px-4 py-3.5 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {data.users.map((u) => (
                          <tr key={u.id}>
                            <td className="px-4 py-3.5">
                              <p className="font-bold text-slate-900">
                                {u.name}{' '}
                                {u.role === 'admin' && (
                                  <span className="ml-1 rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-bold text-amber-800">
                                    ADMIN
                                  </span>
                                )}
                              </p>
                              <p className="text-xs text-slate-500">{u.email}</p>
                            </td>
                            <td className="px-4 py-3.5">
                              <select
                                value={u.plan}
                                onChange={(e) => updateUser(u.id, { plan: e.target.value })}
                                className="rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-bold uppercase"
                              >
                                <option value="free">Free</option>
                                <option value="starter">Starter</option>
                                <option value="pro">Pro</option>
                              </select>
                            </td>
                            <td className="px-4 py-3.5 text-xs text-slate-600">
                              {u.store_count} store(s) · {u.product_count} products
                            </td>
                            <td className="px-4 py-3.5">
                              <span
                                className={`rounded-full px-2.5 py-0.5 text-[11px] font-bold ${
                                  u.status === 'active'
                                    ? 'bg-emerald-50 text-emerald-700'
                                    : 'bg-rose-100 text-rose-700'
                                }`}
                              >
                                {u.status}
                              </span>
                            </td>
                            <td className="px-4 py-3.5 text-right">
                              {u.id !== currentUser.id && (
                                <button
                                  type="button"
                                  onClick={() =>
                                    updateUser(u.id, {
                                      status: u.status === 'active' ? 'suspended' : 'active',
                                    })
                                  }
                                  className={`rounded-lg px-3 py-1.5 text-xs font-bold ${
                                    u.status === 'active'
                                      ? 'bg-rose-50 text-rose-700 hover:bg-rose-100'
                                      : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                                  }`}
                                >
                                  {u.status === 'active' ? 'Suspend' : 'Reactivate'}
                                </button>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* TAB 5: STORES MODERATION */}
              {tab === 'stores' && (
                <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm">
                      <thead className="border-b border-slate-200 bg-slate-50 text-xs font-bold uppercase text-slate-500">
                        <tr>
                          <th className="px-4 py-3.5">Storefront</th>
                          <th className="px-4 py-3.5">Owner</th>
                          <th className="px-4 py-3.5">Template</th>
                          <th className="px-4 py-3.5 text-right">Products</th>
                          <th className="px-4 py-3.5 text-right">Visits / Clicks</th>
                          <th className="px-4 py-3.5 text-right">Moderation</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {data.analytics.topStores.map((s) => (
                          <tr key={s.id}>
                            <td className="px-4 py-3.5">
                              <div className="flex items-center gap-2">
                                <p className="font-bold text-slate-900">{s.name}</p>
                                {s.is_suspended === 1 && (
                                  <span className="rounded-full bg-rose-100 px-2 py-0.5 text-[10px] font-bold text-rose-700">
                                    SUSPENDED
                                  </span>
                                )}
                              </div>
                              <p className="text-xs font-mono text-slate-500">/s/{s.slug}</p>
                            </td>
                            <td className="px-4 py-3.5 text-xs">
                              <p className="font-semibold text-slate-800">{s.owner_name}</p>
                              <p className="text-slate-500">{s.owner_email}</p>
                            </td>
                            <td className="px-4 py-3.5 text-xs uppercase font-semibold text-slate-600">
                              {s.template}
                            </td>
                            <td className="px-4 py-3.5 text-right font-mono text-xs">{s.product_count}</td>
                            <td className="px-4 py-3.5 text-right font-mono text-xs">
                              {s.visits} / <strong className="text-emerald-600">{s.clicks}</strong>
                            </td>
                            <td className="px-4 py-3.5 text-right">
                              <div className="inline-flex items-center gap-2">
                                <Link
                                  href={`/s/${s.slug}`}
                                  target="_blank"
                                  className="rounded-lg border border-slate-200 p-1.5 text-slate-600 hover:text-indigo-600"
                                >
                                  <ExternalLink className="h-4 w-4" />
                                </Link>
                                <button
                                  type="button"
                                  onClick={() => toggleStoreSuspension(s.id, s.is_suspended === 1)}
                                  className={`inline-flex items-center gap-1 rounded-lg px-3 py-1.5 text-xs font-bold ${
                                    s.is_suspended === 1
                                      ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                                      : 'bg-rose-50 text-rose-700 hover:bg-rose-100'
                                  }`}
                                >
                                  <ShieldAlert className="h-3.5 w-3.5" />
                                  {s.is_suspended === 1 ? 'Unsuspend' : 'Suspend'}
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* TAB 6: ACADEMY CMS */}
              {tab === 'academy' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h2 className="font-display text-lg font-bold text-slate-900">
                      Manage Affiliate Academy Lessons
                    </h2>
                    <button
                      type="button"
                      onClick={() => setShowLessonModal(true)}
                      className="inline-flex items-center gap-1.5 rounded-xl bg-[#111315] px-4 py-2.5 text-xs font-bold text-white hover:bg-[#047857] transition-colors"
                    >
                      <Plus className="h-4 w-4" /> Add New Lesson
                    </button>
                  </div>

                  <div className="grid gap-3">
                    {data.lessons.map((l) => (
                      <div
                        key={l.id}
                        className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-slate-200 bg-white p-4 shadow-sm"
                      >
                        <div>
                          <div className="flex items-center gap-2 text-xs">
                            <span className="rounded bg-indigo-50 px-2 py-0.5 font-bold text-indigo-700">
                              Module {l.module_number}
                            </span>
                            <span className="text-slate-400">
                              {l.level} · {l.duration_minutes} min
                            </span>
                          </div>
                          <p className="mt-1 font-display text-sm font-bold text-slate-900">{l.title}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Link
                            href={`/academy/${l.slug}`}
                            target="_blank"
                            className="rounded-lg border border-slate-200 p-2 text-slate-600 hover:text-indigo-600"
                          >
                            <ExternalLink className="h-4 w-4" />
                          </Link>
                          <button
                            type="button"
                            onClick={() => deleteLesson(l.id)}
                            className="rounded-lg border border-slate-200 p-2 text-slate-600 hover:text-rose-600"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 7: SETTINGS & PLAN LIMITS */}
              {tab === 'settings' && settingsForm && (
                <form
                  onSubmit={saveSettings}
                  className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-6"
                >
                  <div>
                    <h2 className="font-display text-lg font-bold text-slate-900">
                      Platform Identity & Plan Quotas
                    </h2>
                    <p className="text-xs text-slate-500">
                      Rename the platform anytime or adjust Free / Starter / Pro store and product limits.
                    </p>
                  </div>

                  <div className="grid gap-4 sm:grid-cols-2">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Platform Brand Name</label>
                      <input
                        type="text"
                        value={settingsForm.platform_name}
                        onChange={(e) =>
                          setSettingsForm({ ...settingsForm, platform_name: e.target.value })
                        }
                        className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Platform Tagline</label>
                      <input
                        type="text"
                        value={settingsForm.platform_tagline}
                        onChange={(e) =>
                          setSettingsForm({ ...settingsForm, platform_tagline: e.target.value })
                        }
                        className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm"
                      />
                    </div>
                  </div>

                  <label className="flex items-center gap-2 text-xs font-bold text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settingsForm.allow_registrations}
                      onChange={(e) =>
                        setSettingsForm({ ...settingsForm, allow_registrations: e.target.checked })
                      }
                      className="h-4 w-4 accent-indigo-600"
                    />
                    Allow New Public User Signups
                  </label>

                  <div className="grid gap-4 md:grid-cols-3">
                    {(['free', 'starter', 'pro'] as const).map((tierKey) => {
                      const tier = settingsForm.plan_limits[tierKey];
                      return (
                        <div key={tierKey} className="rounded-xl border border-slate-200 bg-slate-50 p-4 space-y-3">
                          <p className="font-display text-sm font-extrabold uppercase text-indigo-700">
                            {tier.label} Plan
                          </p>
                          <div>
                            <label className="block text-[11px] font-semibold text-slate-600">Monthly Price ($)</label>
                            <input
                              type="number"
                              min={0}
                              value={tier.price}
                              onChange={(e) =>
                                setSettingsForm({
                                  ...settingsForm,
                                  plan_limits: {
                                    ...settingsForm.plan_limits,
                                    [tierKey]: { ...tier, price: Number(e.target.value) },
                                  },
                                })
                              }
                              className="mt-1 w-full rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs"
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] font-semibold text-slate-600">Max Stores</label>
                            <input
                              type="number"
                              min={1}
                              value={tier.maxStores}
                              onChange={(e) =>
                                setSettingsForm({
                                  ...settingsForm,
                                  plan_limits: {
                                    ...settingsForm.plan_limits,
                                    [tierKey]: { ...tier, maxStores: Number(e.target.value) },
                                  },
                                })
                              }
                              className="mt-1 w-full rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs"
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] font-semibold text-slate-600">Max Products</label>
                            <input
                              type="number"
                              min={1}
                              value={tier.maxProducts}
                              onChange={(e) =>
                                setSettingsForm({
                                  ...settingsForm,
                                  plan_limits: {
                                    ...settingsForm.plan_limits,
                                    [tierKey]: { ...tier, maxProducts: Number(e.target.value) },
                                  },
                                })
                              }
                              className="mt-1 w-full rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs"
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  <div className="flex justify-end">
                    <button
                      type="submit"
                      className="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-6 py-3 text-sm font-bold text-white hover:bg-slate-800"
                    >
                      <Save className="h-4 w-4" /> Save Platform Settings
                    </button>
                  </div>
                </form>
              )}
            </>
          ) : null}
        </div>
      </main>

      {/* ADD / EDIT PARTNER TOOL MODAL */}
      {showToolModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
          <div className="w-full max-w-xl rounded-2xl bg-white p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display text-lg font-bold text-slate-900">
                {editingTool ? 'Edit Partner Affiliate Tool' : 'Add Partner Affiliate Tool'}
              </h3>
              <button type="button" onClick={() => setShowToolModal(false)}>
                <X className="h-5 w-5 text-slate-400" />
              </button>
            </div>
            <form onSubmit={handleSaveTool} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Tool Name *</label>
                  <input
                    type="text"
                    required
                    value={toolForm.name}
                    onChange={(e) => setToolForm({ ...toolForm, name: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Category</label>
                  <select
                    value={toolForm.category}
                    onChange={(e) => setToolForm({ ...toolForm, category: e.target.value })}
                    className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm"
                  >
                    <option value="Affiliate Networks">Affiliate Networks</option>
                    <option value="Domains & Hosting">Domains & Hosting</option>
                    <option value="Design & Video">Design & Video</option>
                    <option value="Analytics & SEO">Analytics & SEO</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Your Affiliate Referral URL (https://...) *
                </label>
                <input
                  type="url"
                  required
                  value={toolForm.affiliate_url}
                  onChange={(e) => setToolForm({ ...toolForm, affiliate_url: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm font-mono"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Badge</label>
                  <input
                    type="text"
                    value={toolForm.badge}
                    onChange={(e) => setToolForm({ ...toolForm, badge: e.target.value })}
                    placeholder="Top Network, Free Tier..."
                    className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Internal Commission Note
                  </label>
                  <input
                    type="text"
                    value={toolForm.commission_note}
                    onChange={(e) => setToolForm({ ...toolForm, commission_note: e.target.value })}
                    placeholder="e.g. 20% recurring referral"
                    className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Short Tagline</label>
                <input
                  type="text"
                  value={toolForm.tagline}
                  onChange={(e) => setToolForm({ ...toolForm, tagline: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Description</label>
                <textarea
                  rows={3}
                  value={toolForm.description}
                  onChange={(e) => setToolForm({ ...toolForm, description: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                />
              </div>
              <button
                type="submit"
                className="w-full rounded-xl bg-[#111315] py-3 text-sm font-bold text-white hover:bg-[#047857] transition-colors"
              >
                {editingTool ? 'Save Partner Tool' : 'Publish to /tools'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ADD LESSON MODAL */}
      {showLessonModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
          <div className="max-h-[90vh] w-full max-w-xl overflow-y-auto rounded-2xl bg-white p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display text-lg font-bold text-slate-900">Create Academy Lesson</h3>
              <button type="button" onClick={() => setShowLessonModal(false)}>
                <X className="h-5 w-5 text-slate-400" />
              </button>
            </div>
            <form onSubmit={handleCreateLesson} className="space-y-4">
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Module #</label>
                  <input
                    type="number"
                    min={1}
                    max={10}
                    value={lessonForm.module_number}
                    onChange={(e) => setLessonForm({ ...lessonForm, module_number: Number(e.target.value) })}
                    className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Level</label>
                  <select
                    value={lessonForm.level}
                    onChange={(e) =>
                      setLessonForm({
                        ...lessonForm,
                        level: e.target.value as 'Beginner' | 'Intermediate' | 'Pro',
                      })
                    }
                    className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm"
                  >
                    <option value="Beginner">Beginner</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Pro">Pro</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Duration (min)</label>
                  <input
                    type="number"
                    min={1}
                    max={60}
                    value={lessonForm.duration_minutes}
                    onChange={(e) =>
                      setLessonForm({ ...lessonForm, duration_minutes: Number(e.target.value) })
                    }
                    className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Lesson Title *</label>
                <input
                  type="text"
                  required
                  value={lessonForm.title}
                  onChange={(e) => setLessonForm({ ...lessonForm, title: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Short Summary</label>
                <input
                  type="text"
                  value={lessonForm.summary}
                  onChange={(e) => setLessonForm({ ...lessonForm, summary: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Lesson Content (Markdown)</label>
                <textarea
                  rows={5}
                  required
                  value={lessonForm.content}
                  onChange={(e) => setLessonForm({ ...lessonForm, content: e.target.value })}
                  className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm font-mono"
                />
              </div>
              <button
                type="submit"
                className="w-full rounded-xl bg-[#111315] py-3 text-sm font-bold text-white hover:bg-[#047857] transition-colors"
              >
                Publish Lesson to Academy
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
