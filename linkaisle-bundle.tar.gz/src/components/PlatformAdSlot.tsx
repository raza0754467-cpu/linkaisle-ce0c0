import Link from 'next/link';
import { ExternalLink, Megaphone } from 'lucide-react';
import { MonetizationConfig } from '@/lib/types';

export default function PlatformAdSlot({ monetization }: { monetization: MonetizationConfig }) {
  if (!monetization.ads_enabled) return null;

  const isExternal = /^https?:\/\//i.test(monetization.ad_sponsor_cta_url);

  return (
    <div className="my-6 rounded-2xl border border-amber-200/80 bg-gradient-to-r from-amber-50 via-white to-indigo-50/70 p-5 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="max-w-2xl">
          <div className="inline-flex items-center gap-1.5 rounded-full bg-amber-100 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-amber-800">
            <Megaphone className="h-3 w-3" />
            {monetization.ad_network_label || 'Sponsored'}
          </div>
          <h3 className="mt-2 font-display text-base font-extrabold text-slate-900">
            {monetization.ad_sponsor_title}
          </h3>
          <p className="mt-1 text-xs text-slate-600 leading-relaxed">
            {monetization.ad_sponsor_desc}
          </p>
        </div>

        {isExternal ? (
          <a
            href={monetization.ad_sponsor_cta_url}
            target="_blank"
            rel="noopener noreferrer sponsored"
            className="inline-flex items-center gap-1.5 rounded-xl bg-slate-900 px-4 py-2.5 text-xs font-bold text-white hover:bg-slate-800 shrink-0"
          >
            {monetization.ad_sponsor_cta_text || 'Learn More'}
            <ExternalLink className="h-3.5 w-3.5" />
          </a>
        ) : (
          <Link
            href={monetization.ad_sponsor_cta_url || '/tools'}
            className="inline-flex items-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2.5 text-xs font-bold text-white hover:bg-indigo-700 shrink-0"
          >
            {monetization.ad_sponsor_cta_text || 'Learn More'}
            <ExternalLink className="h-3.5 w-3.5" />
          </Link>
        )}
      </div>
    </div>
  );
}
