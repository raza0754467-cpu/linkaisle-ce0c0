'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Calendar,
  CalendarDays,
  Check,
  CheckCircle2,
  Copy,
  Download,
  Edit3,
  ExternalLink,
  Image as ImageIcon,
  Layers,
  Save,
  Sparkles,
  Trash2,
  Video,
  X,
} from 'lucide-react';
import { Product, SocialPlatform, SocialPost, Store } from '@/lib/types';

const PLATFORMS: { id: SocialPlatform; label: string; badgeClass: string }[] = [
  { id: 'instagram', label: 'Instagram', badgeClass: 'bg-pink-50 text-pink-700 border-pink-200' },
  { id: 'facebook', label: 'Facebook', badgeClass: 'bg-blue-50 text-blue-700 border-blue-200' },
  { id: 'tiktok', label: 'TikTok', badgeClass: 'bg-stone-100 text-[#111315] border-stone-300' },
  { id: 'pinterest', label: 'Pinterest', badgeClass: 'bg-rose-50 text-rose-700 border-rose-200' },
  { id: 'youtube_shorts', label: 'YouTube Shorts', badgeClass: 'bg-red-50 text-red-700 border-red-200' },
  { id: 'x', label: 'X', badgeClass: 'bg-neutral-100 text-neutral-900 border-neutral-300' },
  { id: 'threads', label: 'Threads', badgeClass: 'bg-emerald-50 text-[#047857] border-emerald-200' },
];

function getPlatformBadge(id: SocialPlatform) {
  return PLATFORMS.find((p) => p.id === id) || PLATFORMS[0];
}

export default function SocialCalendarTab({
  store,
  products,
  onNotify,
}: {
  store: Store;
  products: Product[];
  onNotify: (type: 'success' | 'error', msg: string) => void;
}) {
  const publishedProducts = useMemo(
    () => products.filter((p) => p.status === 'published'),
    [products]
  );

  const [selectedProductIds, setSelectedProductIds] = useState<string[]>([]);
  const [selectedPlatforms, setSelectedPlatforms] = useState<SocialPlatform[]>(
    PLATFORMS.map((p) => p.id)
  );
  const [posts, setPosts] = useState<SocialPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [generatingMode, setGeneratingMode] = useState<'daily' | '7day' | '30day' | null>(null);
  const [providerLabel, setProviderLabel] = useState('');

  const [filterPlatform, setFilterPlatform] = useState<'all' | SocialPlatform>('all');
  const [filterStatus, setFilterStatus] = useState<'all' | 'scheduled' | 'posted' | 'draft'>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Preview / Edit Modal State
  const [editingPost, setEditingPost] = useState<SocialPost | null>(null);
  const [savingEdit, setSavingEdit] = useState(false);

  const loadPosts = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/stores/${store.id}/social-posts`);
      if (res.ok) {
        const d = await res.json();
        setPosts(d.posts || []);
      }
    } finally {
      setLoading(false);
    }
  }, [store.id]);

  useEffect(() => {
    loadPosts();
  }, [loadPosts]);

  function toggleProduct(id: string) {
    setSelectedProductIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  }

  function togglePlatform(id: SocialPlatform) {
    setSelectedPlatforms((prev) => {
      if (prev.includes(id)) {
        return prev.length > 1 ? prev.filter((x) => x !== id) : prev;
      }
      return [...prev, id];
    });
  }

  async function handleGenerate(mode: 'daily' | '7day' | '30day') {
    if (publishedProducts.length === 0) {
      onNotify('error', 'Add and publish at least 1 product in the Products tab first.');
      return;
    }
    const replaceExisting =
      mode !== 'daily' &&
      posts.length > 0 &&
      confirm(
        `Replace your current ${posts.length} calendar post(s) with a fresh ${
          mode === '30day' ? '30-Day' : '7-Day'
        } content calendar? Click Cancel to keep existing posts and append new ones.`
      );

    setGeneratingMode(mode);
    try {
      const res = await fetch(`/api/stores/${store.id}/social-posts`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode,
          productIds: selectedProductIds,
          platforms: selectedPlatforms,
          replaceExisting,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        onNotify('error', data.error || 'Could not generate posts.');
        return;
      }
      setProviderLabel(data.providerLabel || 'LinkAisle AI');
      onNotify(
        'success',
        `Generated ${data.createdCount} AI social post(s) with ${data.providerLabel}!`
      );
      await loadPosts();
    } finally {
      setGeneratingMode(null);
    }
  }

  function formatPostForCopy(post: SocialPost): string {
    const plat = getPlatformBadge(post.platform).label;
    const lines = [
      `[${plat} · Day ${post.day_number} · ${post.scheduled_date}]`,
      `Product: ${post.product_title}`,
      '',
      post.caption,
      '',
      `CTA: ${post.cta}`,
      `Link: ${post.affiliate_link}`,
      '',
      post.hashtags,
    ];
    if (post.video_script) {
      lines.push('', '--- SHORT VIDEO SCRIPT ---', post.video_script);
    }
    if (post.creative_idea) {
      lines.push('', '--- CREATIVE / IMAGE IDEA ---', post.creative_idea);
    }
    return lines.join('\n');
  }

  function handleCopyPost(post: SocialPost) {
    navigator.clipboard?.writeText(formatPostForCopy(post));
    setCopiedId(post.id);
    setTimeout(() => setCopiedId(null), 2000);
    onNotify('success', 'Post copied to clipboard!');
  }

  function handleDownloadTxt(post: SocialPost) {
    const blob = new Blob([formatPostForCopy(post)], { type: 'text/plain;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `day-${post.day_number}-${post.platform}-post.txt`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function handleExportCalendarCsv() {
    if (posts.length === 0) return;
    const headers = [
      'day_number',
      'scheduled_date',
      'platform',
      'status',
      'product_title',
      'creative_idea',
      'caption',
      'hashtags',
      'cta',
      'affiliate_link',
      'video_script',
      'image_url',
    ];
    const esc = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`;
    const rows = posts.map((p) =>
      [
        p.day_number,
        p.scheduled_date,
        getPlatformBadge(p.platform).label,
        p.status,
        p.product_title,
        p.creative_idea,
        p.caption,
        p.hashtags,
        p.cta,
        p.affiliate_link,
        p.video_script,
        p.image_url,
      ]
        .map(esc)
        .join(',')
    );
    const csv = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${store.slug}-social-calendar.csv`;
    a.click();
    URL.revokeObjectURL(url);
    onNotify('success', `Downloaded ${posts.length}-post calendar CSV!`);
  }

  async function handleTogglePosted(post: SocialPost) {
    const nextStatus = post.status === 'posted' ? 'scheduled' : 'posted';
    const res = await fetch(`/api/stores/${store.id}/social-posts`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: post.id, status: nextStatus }),
    });
    if (res.ok) {
      setPosts((prev) => prev.map((p) => (p.id === post.id ? { ...p, status: nextStatus } : p)));
      onNotify('success', nextStatus === 'posted' ? 'Marked as Posted!' : 'Moved back to Scheduled');
    }
  }

  async function handleSaveEdit(e: React.FormEvent) {
    e.preventDefault();
    if (!editingPost) return;
    setSavingEdit(true);
    try {
      const res = await fetch(`/api/stores/${store.id}/social-posts`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editingPost),
      });
      const data = await res.json();
      if (!res.ok) {
        onNotify('error', data.error || 'Could not save post.');
        return;
      }
      setPosts((prev) => prev.map((p) => (p.id === editingPost.id ? data.post : p)));
      setEditingPost(null);
      onNotify('success', 'Social post saved permanently!');
    } finally {
      setSavingEdit(false);
    }
  }

  async function handleDeletePost(id: string) {
    if (!confirm('Delete this post from your content calendar?')) return;
    const res = await fetch(
      `/api/stores/${store.id}/social-posts?id=${encodeURIComponent(id)}`,
      { method: 'DELETE' }
    );
    if (res.ok) {
      setPosts((prev) => prev.filter((p) => p.id !== id));
      onNotify('success', 'Post removed from calendar');
    }
  }

  async function handleClearAll() {
    if (!confirm('Clear all saved posts from this store content calendar?')) return;
    const res = await fetch(`/api/stores/${store.id}/social-posts?clearAll=true`, {
      method: 'DELETE',
    });
    if (res.ok) {
      setPosts([]);
      onNotify('success', 'Calendar cleared');
    }
  }

  const visiblePosts = useMemo(() => {
    return posts.filter((p) => {
      const platOk = filterPlatform === 'all' || p.platform === filterPlatform;
      const statusOk = filterStatus === 'all' || p.status === filterStatus;
      return platOk && statusOk;
    });
  }, [posts, filterPlatform, filterStatus]);

  return (
    <div className="space-y-6">
      {/* GENERATOR CONTROL CARD */}
      <div className="rounded-2xl border border-stone-200 bg-white p-6 shadow-sm space-y-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-emerald-50 border border-emerald-200 text-[#047857]">
              <CalendarDays className="h-5 w-5" />
            </div>
            <div>
              <h2 className="font-display text-lg font-extrabold text-[#111315]">
                AI Daily Social Media Post Generator &amp; Content Calendar
              </h2>
              <p className="mt-0.5 text-xs text-stone-500">
                Select products and platforms below to generate daily posts or full 7-day &amp; 30-day promotional calendars with captions, hashtags, tracked affiliate links, creative ideas, and short video scripts.
              </p>
            </div>
          </div>

          {providerLabel && (
            <span className="rounded-full bg-emerald-50 border border-emerald-200 px-3 py-1 text-[11px] font-bold text-[#047857]">
              Powered by {providerLabel}
            </span>
          )}
        </div>

        {/* 1. SELECT AFFILIATE PRODUCTS */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs font-bold text-stone-700">
              1. Select Affiliate Products ({selectedProductIds.length === 0 ? `All ${publishedProducts.length} Live Products` : `${selectedProductIds.length} Selected`})
            </label>
            {selectedProductIds.length > 0 && (
              <button
                type="button"
                onClick={() => setSelectedProductIds([])}
                className="text-[11px] font-bold text-[#047857] hover:underline"
              >
                Use All Products
              </button>
            )}
          </div>
          {publishedProducts.length === 0 ? (
            <p className="rounded-xl border border-amber-200 bg-amber-50 px-3.5 py-2.5 text-xs text-amber-900">
              Publish at least 1 product in the <strong>Products</strong> tab first so AI can generate posts for it.
            </p>
          ) : (
            <div className="flex flex-wrap gap-2">
              {publishedProducts.map((p) => {
                const active = selectedProductIds.includes(p.id);
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => toggleProduct(p.id)}
                    className={`inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-semibold transition-colors ${
                      active
                        ? 'border-[#047857] bg-emerald-50 text-[#047857]'
                        : 'border-stone-200 bg-[#FAFAF9] text-stone-700 hover:border-stone-300'
                    }`}
                  >
                    {p.image_url && (
                      <img
                        src={p.image_url}
                        alt={p.title}
                        className="h-4 w-4 rounded-full object-cover"
                      />
                    )}
                    <span className="max-w-[180px] truncate">{p.title}</span>
                    {active && <Check className="h-3.5 w-3.5 shrink-0" />}
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* 2. SELECT PLATFORMS */}
        <div>
          <label className="block text-xs font-bold text-stone-700 mb-2">
            2. Target Social Media Platforms ({selectedPlatforms.length}/7)
          </label>
          <div className="flex flex-wrap gap-2">
            {PLATFORMS.map((pl) => {
              const active = selectedPlatforms.includes(pl.id);
              return (
                <button
                  key={pl.id}
                  type="button"
                  onClick={() => togglePlatform(pl.id)}
                  className={`rounded-full border px-3.5 py-1.5 text-xs font-bold transition-colors ${
                    active
                      ? 'border-[#111315] bg-[#111315] text-white'
                      : 'border-stone-200 bg-white text-stone-600 hover:border-stone-300'
                  }`}
                >
                  {pl.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* 3. ONE-CLICK GENERATE ACTIONS */}
        <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-stone-100">
          <button
            type="button"
            disabled={generatingMode !== null || publishedProducts.length === 0}
            onClick={() => handleGenerate('daily')}
            className="inline-flex items-center gap-2 rounded-xl bg-[#047857] px-5 py-2.5 text-xs font-bold text-white shadow-sm hover:bg-[#065f46] disabled:opacity-60 transition-colors"
          >
            <Sparkles className={`h-4 w-4 ${generatingMode === 'daily' ? 'animate-spin' : ''}`} />
            {generatingMode === 'daily' ? 'Generating Today...' : 'Generate Daily Post (1-Click)'}
          </button>

          <button
            type="button"
            disabled={generatingMode !== null || publishedProducts.length === 0}
            onClick={() => handleGenerate('7day')}
            className="inline-flex items-center gap-2 rounded-xl bg-[#111315] px-5 py-2.5 text-xs font-bold text-white shadow-sm hover:bg-[#047857] disabled:opacity-60 transition-colors"
          >
            <Calendar className={`h-4 w-4 ${generatingMode === '7day' ? 'animate-spin' : ''}`} />
            {generatingMode === '7day' ? 'Building 7-Day Plan...' : 'Generate 7-Day Calendar'}
          </button>

          <button
            type="button"
            disabled={generatingMode !== null || publishedProducts.length === 0}
            onClick={() => handleGenerate('30day')}
            className="inline-flex items-center gap-2 rounded-xl border border-stone-300 bg-white px-5 py-2.5 text-xs font-bold text-[#111315] hover:border-[#047857] hover:text-[#047857] disabled:opacity-60 transition-colors"
          >
            <Layers className={`h-4 w-4 ${generatingMode === '30day' ? 'animate-spin' : ''}`} />
            {generatingMode === '30day' ? 'Building 30-Day Plan...' : 'Generate 30-Day Calendar'}
          </button>

          {posts.length > 0 && (
            <div className="ml-auto flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handleExportCalendarCsv}
                className="inline-flex items-center gap-1.5 rounded-xl border border-stone-200 bg-[#FAFAF9] px-3.5 py-2 text-xs font-bold text-stone-700 hover:bg-stone-100"
              >
                <Download className="h-3.5 w-3.5" /> Export CSV ({posts.length})
              </button>
              <button
                type="button"
                onClick={handleClearAll}
                className="inline-flex items-center gap-1 rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-xs font-bold text-rose-700 hover:bg-rose-100"
              >
                <Trash2 className="h-3.5 w-3.5" /> Clear
              </button>
            </div>
          )}
        </div>

        {/* FUTURE OFFICIAL API AUTO-POSTING NOTE */}
        <div className="rounded-xl border border-stone-200 bg-[#FAFAF9] px-4 py-2.5 text-[11px] text-stone-600 flex flex-wrap items-center justify-between gap-2">
          <span>
            <strong className="text-[#111315]">Publishing Mode:</strong> Copy, download `.txt`, or export `.csv` to post directly on Instagram, Facebook, TikTok, Pinterest, YouTube Shorts, X, and Threads.
          </span>
          <span className="rounded-full bg-white border border-stone-200 px-2.5 py-0.5 text-[10px] font-bold text-stone-500">
            Official Social API Auto-Post Ready (Connect Later)
          </span>
        </div>
      </div>

      {/* SAVED CONTENT CALENDAR FILTERS & CARDS */}
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              type="button"
              onClick={() => setFilterPlatform('all')}
              className={`rounded-full px-3 py-1 text-xs font-bold ${
                filterPlatform === 'all'
                  ? 'bg-[#111315] text-white'
                  : 'bg-white border border-stone-200 text-stone-600'
              }`}
            >
              All ({posts.length})
            </button>
            {PLATFORMS.map((pl) => {
              const cnt = posts.filter((p) => p.platform === pl.id).length;
              if (cnt === 0) return null;
              return (
                <button
                  key={pl.id}
                  type="button"
                  onClick={() => setFilterPlatform(pl.id)}
                  className={`rounded-full px-3 py-1 text-xs font-bold ${
                    filterPlatform === pl.id
                      ? 'bg-[#047857] text-white'
                      : 'bg-white border border-stone-200 text-stone-600'
                  }`}
                >
                  {pl.label} ({cnt})
                </button>
              );
            })}
          </div>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value as 'all' | 'scheduled' | 'posted' | 'draft')}
            className="rounded-xl border border-stone-200 bg-white px-3 py-1.5 text-xs font-semibold text-stone-700"
          >
            <option value="all">All Statuses</option>
            <option value="scheduled">Scheduled</option>
            <option value="posted">Posted</option>
            <option value="draft">Draft</option>
          </select>
        </div>

        {loading ? (
          <div className="rounded-2xl border border-stone-200 bg-white p-12 text-center text-sm text-stone-500">
            Loading your saved content calendar...
          </div>
        ) : visiblePosts.length === 0 ? (
          <div className="rounded-2xl border border-stone-200 bg-white p-12 text-center">
            <CalendarDays className="mx-auto h-10 w-10 text-stone-300" />
            <h3 className="mt-3 font-display text-base font-bold text-[#111315]">
              No social posts in your calendar yet
            </h3>
            <p className="mt-1 text-xs text-stone-500 max-w-md mx-auto">
              Click <strong>Generate Daily Post</strong>, <strong>Generate 7-Day Calendar</strong>, or{' '}
              <strong>Generate 30-Day Calendar</strong> above to build your complete affiliate promotion schedule in seconds.
            </p>
          </div>
        ) : (
          <div className="grid gap-4 md:grid-cols-2">
            {visiblePosts.map((post) => {
              const badge = getPlatformBadge(post.platform);
              return (
                <article
                  key={post.id}
                  className="flex flex-col justify-between rounded-2xl border border-stone-200 bg-white p-5 shadow-sm hover:shadow-md transition-all"
                >
                  <div className="space-y-3">
                    {/* TOP META */}
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="rounded-lg bg-stone-100 px-2 py-0.5 font-mono text-[11px] font-bold text-[#111315]">
                          Day {post.day_number} · {post.scheduled_date}
                        </span>
                        <span
                          className={`rounded-full border px-2.5 py-0.5 text-[11px] font-bold ${badge.badgeClass}`}
                        >
                          {badge.label}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleTogglePosted(post)}
                        className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[10px] font-bold transition-colors ${
                          post.status === 'posted'
                            ? 'bg-emerald-100 text-[#047857]'
                            : 'bg-stone-100 text-stone-600 hover:bg-emerald-50 hover:text-[#047857]'
                        }`}
                      >
                        <CheckCircle2 className="h-3 w-3" />
                        {post.status === 'posted' ? 'Posted' : 'Scheduled'}
                      </button>
                    </div>

                    {/* PRODUCT IMAGE + CREATIVE IDEA */}
                    <div className="flex items-start gap-3 rounded-xl bg-[#FAFAF9] border border-stone-200/80 p-3">
                      {post.image_url ? (
                        <img
                          src={post.image_url}
                          alt={post.product_title}
                          className="h-14 w-14 shrink-0 rounded-xl object-cover border border-stone-200"
                        />
                      ) : (
                        <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl bg-stone-100 text-stone-400">
                          <ImageIcon className="h-5 w-5" />
                        </div>
                      )}
                      <div className="min-w-0">
                        <p className="truncate font-display text-xs font-bold text-[#111315]">
                          {post.product_title}
                        </p>
                        <p className="mt-1 text-[11px] leading-relaxed text-stone-600 line-clamp-3">
                          <strong className="text-[#047857]">Creative Idea:</strong> {post.creative_idea}
                        </p>
                      </div>
                    </div>

                    {/* SEO CAPTION */}
                    <div>
                      <p className="text-[10px] font-bold uppercase tracking-wider text-stone-400 mb-1">
                        SEO Caption
                      </p>
                      <p className="whitespace-pre-line text-xs leading-relaxed text-stone-800 line-clamp-5">
                        {post.caption}
                      </p>
                    </div>

                    {/* CTA + AFFILIATE LINK */}
                    <div className="rounded-xl bg-emerald-50/60 border border-emerald-200/70 p-2.5 text-xs space-y-1">
                      <p className="font-semibold text-emerald-950">
                        <strong>CTA:</strong> {post.cta}
                      </p>
                      <a
                        href={post.affiliate_link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 font-mono text-[11px] text-[#047857] hover:underline break-all"
                      >
                        {post.affiliate_link} <ExternalLink className="h-3 w-3 shrink-0" />
                      </a>
                    </div>

                    {/* HASHTAGS */}
                    <p className="text-[11px] font-medium text-stone-500 break-words">
                      {post.hashtags}
                    </p>

                    {/* SHORT VIDEO SCRIPT (WHEN APPLICABLE) */}
                    {post.video_script && (
                      <div className="rounded-xl border border-stone-200 bg-[#FAFAF9] p-3">
                        <p className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-[#111315] mb-1">
                          <Video className="h-3 w-3 text-[#047857]" /> Short Video Script
                        </p>
                        <p className="whitespace-pre-line text-[11px] leading-relaxed text-stone-700">
                          {post.video_script}
                        </p>
                      </div>
                    )}
                  </div>

                  {/* ACTIONS BAR */}
                  <div className="mt-4 pt-3 border-t border-stone-100 flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleCopyPost(post)}
                        className="inline-flex items-center gap-1 rounded-lg bg-[#111315] px-3 py-1.5 text-xs font-bold text-white hover:bg-[#047857] transition-colors"
                      >
                        {copiedId === post.id ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                        {copiedId === post.id ? 'Copied' : 'Copy Post'}
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditingPost({ ...post })}
                        className="inline-flex items-center gap-1 rounded-lg border border-stone-200 bg-white px-2.5 py-1.5 text-xs font-bold text-stone-700 hover:bg-stone-50"
                      >
                        <Edit3 className="h-3.5 w-3.5" /> Preview / Edit
                      </button>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleDownloadTxt(post)}
                        title="Download post as .txt"
                        className="rounded-lg border border-stone-200 p-1.5 text-stone-600 hover:bg-stone-100"
                      >
                        <Download className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeletePost(post.id)}
                        title="Delete post"
                        className="rounded-lg border border-stone-200 p-1.5 text-stone-600 hover:bg-rose-50 hover:text-rose-600"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </div>

      {/* PREVIEW & EDIT POST MODAL */}
      {editingPost && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
          <div className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-2xl bg-white p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-display text-lg font-extrabold text-[#111315]">
                  Edit Day {editingPost.day_number} Post — {getPlatformBadge(editingPost.platform).label}
                </h3>
                <p className="text-xs text-stone-500">{editingPost.product_title}</p>
              </div>
              <button type="button" onClick={() => setEditingPost(null)}>
                <X className="h-5 w-5 text-stone-400" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-4">
              <div className="grid gap-3 sm:grid-cols-3">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">Platform</label>
                  <select
                    value={editingPost.platform}
                    onChange={(e) =>
                      setEditingPost({ ...editingPost, platform: e.target.value as SocialPlatform })
                    }
                    className="w-full rounded-xl border border-stone-300 px-3 py-2 text-xs font-semibold"
                  >
                    {PLATFORMS.map((pl) => (
                      <option key={pl.id} value={pl.id}>
                        {pl.label}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">Scheduled Date</label>
                  <input
                    type="date"
                    value={editingPost.scheduled_date}
                    onChange={(e) => setEditingPost({ ...editingPost, scheduled_date: e.target.value })}
                    className="w-full rounded-xl border border-stone-300 px-3 py-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">Status</label>
                  <select
                    value={editingPost.status}
                    onChange={(e) =>
                      setEditingPost({
                        ...editingPost,
                        status: e.target.value as 'scheduled' | 'posted' | 'draft',
                      })
                    }
                    className="w-full rounded-xl border border-stone-300 px-3 py-2 text-xs font-semibold"
                  >
                    <option value="scheduled">Scheduled</option>
                    <option value="posted">Posted</option>
                    <option value="draft">Draft</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Creative / Image Idea
                </label>
                <textarea
                  rows={2}
                  value={editingPost.creative_idea}
                  onChange={(e) => setEditingPost({ ...editingPost, creative_idea: e.target.value })}
                  className="w-full rounded-xl border border-stone-300 px-3.5 py-2 text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  SEO-Friendly Caption
                </label>
                <textarea
                  rows={5}
                  value={editingPost.caption}
                  onChange={(e) => setEditingPost({ ...editingPost, caption: e.target.value })}
                  className="w-full rounded-xl border border-stone-300 px-3.5 py-2 text-xs"
                />
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">Call to Action</label>
                  <input
                    type="text"
                    value={editingPost.cta}
                    onChange={(e) => setEditingPost({ ...editingPost, cta: e.target.value })}
                    className="w-full rounded-xl border border-stone-300 px-3 py-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Affiliate Product Link
                  </label>
                  <input
                    type="url"
                    value={editingPost.affiliate_link}
                    onChange={(e) => setEditingPost({ ...editingPost, affiliate_link: e.target.value })}
                    className="w-full rounded-xl border border-stone-300 px-3 py-2 text-xs font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Hashtags</label>
                <input
                  type="text"
                  value={editingPost.hashtags}
                  onChange={(e) => setEditingPost({ ...editingPost, hashtags: e.target.value })}
                  className="w-full rounded-xl border border-stone-300 px-3.5 py-2 text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Short Video Script (TikTok / Reels / Shorts)
                </label>
                <textarea
                  rows={4}
                  value={editingPost.video_script}
                  onChange={(e) => setEditingPost({ ...editingPost, video_script: e.target.value })}
                  placeholder="Optional short-form video script (Hook, Demo, CTA)..."
                  className="w-full rounded-xl border border-stone-300 px-3.5 py-2 text-xs font-mono"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingPost(null)}
                  className="rounded-xl border border-stone-200 px-4 py-2.5 text-xs font-semibold text-stone-600"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingEdit}
                  className="inline-flex items-center gap-1.5 rounded-xl bg-[#111315] px-6 py-2.5 text-xs font-bold text-white hover:bg-[#047857] transition-colors disabled:opacity-60"
                >
                  <Save className="h-3.5 w-3.5" />
                  {savingEdit ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
