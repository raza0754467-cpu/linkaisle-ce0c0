'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  ShoppingBag,
  LayoutDashboard,
  ShieldCheck,
  LogOut,
  Menu,
  X,
} from 'lucide-react';
import { useState } from 'react';
import { User } from '@/lib/types';

export default function Navbar({
  user,
  platformName = 'LinkAisle',
}: {
  user: User | null;
  platformName?: string;
}) {
  const router = useRouter();
  const [mobileOpen, setMobileOpen] = useState(false);

  async function handleLogout() {
    await fetch('/api/auth/logout', { method: 'POST' });
    router.push('/');
    router.refresh();
  }

  return (
    <header className="sticky top-0 z-40 border-b border-stone-200/80 bg-[#FAFAF9]/90 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3.5 sm:px-6 lg:px-8">
        <Link href="/" className="flex items-center gap-2.5 group">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#047857] text-white shadow-sm group-hover:bg-[#065f46] transition-colors">
            <ShoppingBag className="h-4.5 w-4.5" />
          </div>
          <span className="font-display text-lg font-extrabold tracking-tight text-[#111315]">
            {platformName}
          </span>
        </Link>

        <nav className="hidden items-center gap-6 text-sm font-medium text-stone-600 lg:flex">
          <Link href="/#how-it-works" className="whitespace-nowrap hover:text-[#111315] transition-colors">
            How It Works
          </Link>
          <Link href="/#products" className="whitespace-nowrap hover:text-[#111315] transition-colors">
            Products
          </Link>
          <Link href="/templates" className="whitespace-nowrap hover:text-[#111315] transition-colors">
            Themes
          </Link>
          <Link href="/academy" className="whitespace-nowrap hover:text-[#111315] transition-colors">
            Academy
          </Link>
          <Link href="/tools" className="whitespace-nowrap hover:text-[#111315] transition-colors">
            Affiliate Networks
          </Link>
          <Link href="/#pricing" className="whitespace-nowrap hover:text-[#111315] transition-colors">
            Pricing
          </Link>
        </nav>

        <div className="hidden items-center gap-2.5 lg:flex shrink-0">
          {user ? (
            <>
              {user.role === 'admin' && (
                <Link
                  href="/admin"
                  className="whitespace-nowrap inline-flex items-center gap-1.5 rounded-full border border-amber-300 bg-amber-50 px-3.5 py-2 text-xs font-semibold text-amber-900 hover:bg-amber-100 transition-colors"
                >
                  <ShieldCheck className="h-4 w-4" />
                  Admin
                </Link>
              )}
              <Link
                href="/dashboard"
                className="whitespace-nowrap inline-flex items-center gap-1.5 rounded-full bg-[#111315] px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-[#047857] transition-colors"
              >
                <LayoutDashboard className="h-4 w-4" />
                My Studio
              </Link>
              <button
                onClick={handleLogout}
                title="Sign out"
                className="rounded-full border border-stone-200 bg-white p-2 text-stone-500 hover:bg-stone-100 hover:text-stone-900 transition-colors"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </>
          ) : (
            <>
              <Link
                href="/login"
                className="rounded-full px-4 py-2 text-sm font-semibold text-stone-700 hover:bg-stone-200/60 transition-colors"
              >
                Sign In
              </Link>
              <Link
                href="/register"
                className="rounded-full bg-[#111315] px-5 py-2 text-sm font-semibold text-white shadow-sm hover:bg-[#047857] transition-colors"
              >
                Start Free Store
              </Link>
            </>
          )}
        </div>

        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="rounded-lg p-2 text-stone-700 hover:bg-stone-200/60 lg:hidden"
          aria-label="Toggle Menu"
        >
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {mobileOpen && (
        <div className="border-t border-stone-200 bg-white px-4 py-4 space-y-2.5 lg:hidden">
          <Link href="/#how-it-works" onClick={() => setMobileOpen(false)} className="block py-1.5 text-sm font-medium text-stone-700">
            How It Works
          </Link>
          <Link href="/#products" onClick={() => setMobileOpen(false)} className="block py-1.5 text-sm font-medium text-stone-700">
            Featured Products
          </Link>
          <Link href="/templates" onClick={() => setMobileOpen(false)} className="block py-1.5 text-sm font-medium text-stone-700">
            Store Themes
          </Link>
          <Link href="/academy" onClick={() => setMobileOpen(false)} className="block py-1.5 text-sm font-medium text-stone-700">
            Affiliate Academy
          </Link>
          <Link href="/tools" onClick={() => setMobileOpen(false)} className="block py-1.5 text-sm font-medium text-stone-700">
            Affiliate Networks & Tools
          </Link>
          <Link href="/#pricing" onClick={() => setMobileOpen(false)} className="block py-1.5 text-sm font-medium text-stone-700">
            Pricing
          </Link>
          <div className="pt-3 border-t border-stone-100 flex flex-col gap-2">
            {user ? (
              <>
                <Link href="/dashboard" onClick={() => setMobileOpen(false)} className="rounded-full bg-[#111315] px-4 py-2.5 text-center text-sm font-semibold text-white">
                  Open My Studio
                </Link>
                {user.role === 'admin' && (
                  <Link href="/admin" onClick={() => setMobileOpen(false)} className="rounded-full bg-amber-50 border border-amber-200 px-4 py-2.5 text-center text-sm font-semibold text-amber-900">
                    Admin Panel
                  </Link>
                )}
                <button onClick={handleLogout} className="rounded-full border border-stone-200 px-4 py-2 text-sm font-medium text-stone-600">
                  Sign Out
                </button>
              </>
            ) : (
              <>
                <Link href="/login" onClick={() => setMobileOpen(false)} className="rounded-full border border-stone-200 px-4 py-2.5 text-center text-sm font-semibold text-stone-700">
                  Sign In
                </Link>
                <Link href="/register" onClick={() => setMobileOpen(false)} className="rounded-full bg-[#111315] px-4 py-2.5 text-center text-sm font-semibold text-white">
                  Start Free Store
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
