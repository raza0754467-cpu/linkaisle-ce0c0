'use client';

import { useEffect, useRef, useState } from 'react';
import { usePathname } from 'next/navigation';
import { Bot, Globe, MessageCircle, Send, Sparkles, X } from 'lucide-react';

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export default function AiAssistantWidget() {
  const pathname = usePathname() || '/';
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  const isStorePage = pathname.startsWith('/s/');
  const isStudioPage = pathname.startsWith('/dashboard') || pathname.startsWith('/admin');

  const assistantTitle = isStorePage
    ? 'Store AI Shopping Assistant'
    : isStudioPage
      ? 'LinkAisle Creator AI Copilot'
      : 'LinkAisle AI Support';

  const welcomeMessage = isStorePage
    ? 'Hi! Ask me anything about the products in this store — comparisons, shipping countries, or deals — in any language.'
    : isStudioPage
      ? 'Hi! Need help writing a product listing, picking a niche, checking affiliate links, or growing clicks? Ask me in any language.'
      : 'Hi! Welcome to LinkAisle. Ask me anything about launching your free store, affiliate networks, pricing, or deals — in any language.';

  const quickPrompts = isStorePage
    ? [
        'Which product here is the best value?',
        'Which countries do these products ship to?',
        'How does checkout work?',
      ]
    : isStudioPage
      ? [
          'Help me write a high-converting product pitch',
          'How do I add my Amazon affiliate tag?',
          'Best way to get free traffic to my store?',
        ]
      : [
          'How do I create a free store on LinkAisle?',
          'Do I need to buy a domain or hosting?',
          'How do affiliate commissions work?',
        ];

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, open, sending]);

  async function sendMessage(textOverride?: string) {
    const text = (textOverride ?? input).trim();
    if (!text || sending) return;

    const nextMessages: ChatMessage[] = [...messages, { role: 'user', content: text }];
    setMessages(nextMessages);
    if (!textOverride) setInput('');
    setSending(true);

    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: nextMessages,
          pathname,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setMessages((prev) => [
          ...prev,
          { role: 'assistant', content: data.error || 'Sorry, please try again in a moment.' },
        ]);
        return;
      }
      setMessages((prev) => [...prev, { role: 'assistant', content: data.reply }]);
    } catch {
      setMessages((prev) => [
        ...prev,
        { role: 'assistant', content: 'Connection issue. Please try sending your question again.' },
      ]);
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col items-end">
      {/* SLIDE-UP CHAT PANEL */}
      {open && (
        <div className="mb-3 flex h-[500px] max-h-[78vh] w-[360px] max-w-[calc(100vw-2rem)] flex-col overflow-hidden rounded-3xl border border-stone-200 bg-white shadow-2xl shadow-stone-900/15">
          {/* HEADER */}
          <div className="flex items-center justify-between border-b border-stone-200 bg-[#111315] px-4 py-3.5 text-white">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-2xl bg-[#047857] text-white shadow-sm">
                <Sparkles className="h-4 w-4" />
              </div>
              <div className="min-w-0">
                <p className="truncate font-display text-sm font-extrabold leading-tight">
                  {assistantTitle}
                </p>
                <p className="mt-0.5 flex items-center gap-1 text-[11px] text-emerald-300">
                  <Globe className="h-3 w-3 shrink-0" />
                  <span>24/7 Support · Ask in any language</span>
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setOpen(false)}
              aria-label="Close AI Assistant"
              className="rounded-xl p-1.5 text-stone-400 hover:bg-white/10 hover:text-white transition-colors"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {/* MESSAGES */}
          <div ref={scrollRef} className="flex-1 overflow-y-auto bg-[#FAFAF9] p-4 space-y-3">
            {/* Initial Greeting */}
            <div className="flex items-start gap-2.5">
              <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-[#047857]">
                <Bot className="h-4 w-4" />
              </div>
              <div className="rounded-2xl rounded-tl-sm border border-stone-200 bg-white px-3.5 py-2.5 text-xs leading-relaxed text-stone-700 shadow-sm">
                {welcomeMessage}
              </div>
            </div>

            {/* Starter Quick Prompts */}
            {messages.length === 0 && (
              <div className="flex flex-wrap gap-1.5 pl-9">
                {quickPrompts.map((q) => (
                  <button
                    key={q}
                    type="button"
                    onClick={() => sendMessage(q)}
                    className="rounded-full border border-emerald-200 bg-white px-3 py-1.5 text-[11px] font-semibold text-[#047857] hover:bg-emerald-50 transition-colors text-left"
                  >
                    {q}
                  </button>
                ))}
              </div>
            )}

            {/* Conversation History */}
            {messages.map((m, idx) => (
              <div
                key={idx}
                className={`flex items-start gap-2.5 ${m.role === 'user' ? 'justify-end' : ''}`}
              >
                {m.role === 'assistant' && (
                  <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-[#047857]">
                    <Bot className="h-4 w-4" />
                  </div>
                )}
                <div
                  className={`max-w-[82%] whitespace-pre-wrap rounded-2xl px-3.5 py-2.5 text-xs leading-relaxed shadow-sm ${
                    m.role === 'user'
                      ? 'rounded-tr-sm bg-[#111315] text-white'
                      : 'rounded-tl-sm border border-stone-200 bg-white text-stone-800'
                  }`}
                >
                  {m.content}
                </div>
              </div>
            ))}

            {sending && (
              <div className="flex items-start gap-2.5">
                <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-[#047857]">
                  <Bot className="h-4 w-4" />
                </div>
                <div className="rounded-2xl rounded-tl-sm border border-stone-200 bg-white px-3.5 py-2.5 text-xs text-stone-500">
                  Thinking...
                </div>
              </div>
            )}
          </div>

          {/* INPUT BAR */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              sendMessage();
            }}
            className="flex items-center gap-2 border-t border-stone-200 bg-white p-3"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask anything in any language..."
              className="flex-1 rounded-full border border-stone-300 bg-[#FAFAF9] px-4 py-2 text-xs text-[#111315] focus:border-[#047857] focus:bg-white focus:outline-none"
            />
            <button
              type="submit"
              disabled={sending || !input.trim()}
              aria-label="Send message"
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#047857] text-white hover:bg-[#065f46] disabled:opacity-50 transition-colors"
            >
              <Send className="h-4 w-4" />
            </button>
          </form>
        </div>
      )}

      {/* FLOATING AI ICON BUTTON */}
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-label="Open LinkAisle AI Assistant"
        className="group inline-flex items-center gap-2 rounded-full bg-[#111315] px-4 py-3 text-xs font-bold text-white shadow-xl shadow-stone-900/20 ring-2 ring-white hover:bg-[#047857] transition-all"
      >
        <span className="relative flex h-6 w-6 items-center justify-center rounded-full bg-[#047857] group-hover:bg-white group-hover:text-[#047857] transition-colors">
          {open ? <X className="h-3.5 w-3.5" /> : <MessageCircle className="h-3.5 w-3.5" />}
        </span>
        <span className="pr-1">{open ? 'Close AI' : 'Ask AI'}</span>
      </button>
    </div>
  );
}
