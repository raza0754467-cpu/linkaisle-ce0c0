'use client';

import Link from 'next/link';
import {
  ArrowRight,
  ExternalLink,
  Globe,
  Heart,
  Mail,
  Search,
  ShoppingBag,
  Sparkles,
} from 'lucide-react';
import { COUNTRY_OPTIONS, formatCountryLabel } from '@/lib/types';
import { StorefrontThemeProps } from './types';

export default function BeautyLuxeTheme({
  store,
  products,
  filteredProducts,
  featuredProducts,
  posts,
  platformName,
  categories,
  category,
  setCategory,
  countryFilter,
  setCountryFilter,
  search,
  setSearch,
  setSelectedProduct,
  goHref,
}: StorefrontThemeProps) {
  const lookbook = (featuredProducts.length ? featuredProducts : products).slice(0, 4);

  return (
    <div className="min-h-screen bg-[#fdf9fa] text-[#2a1f24]">
      {/* LUXURY CENTERED HEADER (SHOPIFY PRESTIGE STYLE) */}
      <header className="sticky top-0 z-30 border-b border-rose-200/70 bg-white/95 backdrop-blur-md">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <a href="#boutique" className="text-[11px] font-semibold uppercase tracking-[0.2em] text-rose-900/70 hover:text-rose-900">
              Collection
            </a>

            <Link href={`/s/${store.slug}`} className="flex items-center gap-2.5 text-center">
              {store.logo_url && (
                <img src={store.logo_url} alt={store.name} className="h-8 w-8 rounded-full object-cover border border-rose-200" />
              )}
              <span className="font-serif text-xl sm:text-2xl font-bold uppercase tracking-[0.18em] text-[#2a1f24]">
                {store.name}
              </span>
            </Link>

            <div className="flex items-center gap-4 text-[11px] font-semibold uppercase tracking-[0.2em] text-rose-900/70">
              {posts.length > 0 && (
                <a href="#edit" className="hidden sm:inline hover:text-rose-900">
                  The Edit
                </a>
              )}
              <span className="rounded-full bg-rose-50 border border-rose-200 px-2.5 py-0.5 text-[10px] tracking-normal text-rose-800">
                {formatCountryLabel(store.target_country || 'US')}
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* CENTERED LOOKBOOK HERO */}
      <section className="border-b border-rose-100 bg-gradient-to-b from-rose-50/80 via-[#fdf7f8] to-white py-16">
        <div className="mx-auto max-w-5xl px-4 text-center sm:px-6">
          <p className="text-[11px] font-semibold uppercase tracking-[0.28em] text-rose-700">
            Curated Boutique · {store.currency || 'USD'} Selection
          </p>
          <h1 className="mt-4 font-serif text-4xl font-normal tracking-tight text-[#2a1f24] sm:text-6xl leading-[1.12]">
            {store.hero_title || store.name}
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-sm sm:text-base leading-relaxed text-stone-600">
            {store.hero_subtitle || store.description}
          </p>
          <div className="mt-8 flex justify-center gap-3">
            <a
              href="#boutique"
              className="rounded-none px-8 py-3.5 text-xs font-bold uppercase tracking-[0.2em] text-white transition-opacity hover:opacity-90"
              style={{ backgroundColor: store.primary_color }}
            >
              {store.hero_cta || 'Explore The Edit'}
            </a>
          </div>

          {/* 4-CARD PORTRAIT LOOKBOOK STRIP */}
          {lookbook.length > 0 && (
            <div className="mt-12 grid grid-cols-2 gap-4 sm:grid-cols-4">
              {lookbook.map((item) => (
                <div
                  key={item.id}
                  onClick={() => setSelectedProduct(item)}
                  className="group cursor-pointer overflow-hidden bg-white border border-rose-100 shadow-sm"
                >
                  <div className="aspect-[3/4] overflow-hidden bg-rose-50/50">
                    {item.image_url ? (
                      <img
                        src={item.image_url}
                        alt={item.title}
                        className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-700"
                      />
                    ) : null}
                  </div>
                  <div className="p-3 text-center">
                    <p className="font-serif text-xs font-semibold text-stone-800 line-clamp-1">
                      {item.title}
                    </p>
                    <p className="mt-1 text-xs font-bold" style={{ color: store.primary_color }}>
                      {item.price_display}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CURATOR'S PHILOSOPHY QUOTE */}
      <section className="border-b border-rose-100 bg-white py-10">
        <div className="mx-auto max-w-3xl px-4 text-center">
          <Heart className="mx-auto h-5 w-5 text-rose-400" />
          <p className="mt-3 font-serif text-lg italic text-stone-700">
            &ldquo;{store.tagline || 'Thoughtfully selected everyday essentials — every piece is hand-picked for lasting quality and real daily joy.'}&rdquo;
          </p>
        </div>
      </section>

      <main className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8 space-y-16">
        {/* BOUTIQUE PORTRAIT GRID */}
        <section id="boutique">
          <div className="flex flex-col items-center justify-between gap-4 border-b border-rose-200/60 pb-5 md:flex-row">
            <div className="flex flex-wrap justify-center gap-3">
              {categories.map((cat) => {
                const active = category === cat;
                return (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setCategory(cat)}
                    className={`pb-1 text-xs uppercase tracking-[0.15em] transition-colors ${
                      active
                        ? 'border-b-2 font-bold text-[#2a1f24]'
                        : 'text-stone-500 hover:text-stone-900'
                    }`}
                    style={active ? { borderColor: store.primary_color } : undefined}
                  >
                    {cat}
                  </button>
                );
              })}
            </div>

            <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
              <select
                value={countryFilter}
                onChange={(e) => setCountryFilter(e.target.value)}
                aria-label="Filter by available country"
                className="flex-1 md:w-44 border border-rose-200 bg-white px-3 py-2 text-xs text-stone-700 focus:outline-none"
              >
                <option value="ALL">All Countries</option>
                {COUNTRY_OPTIONS.map((c) => (
                  <option key={c.code} value={c.code}>
                    Ships to: {c.name}
                  </option>
                ))}
              </select>
              <div className="relative flex-1 md:w-52">
                <Search className="pointer-events-none absolute left-3 top-2.5 h-3.5 w-3.5 text-stone-400" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search collection..."
                  className="w-full border border-rose-200 bg-white py-2 pl-8 pr-3 text-xs focus:outline-none"
                />
              </div>
            </div>
          </div>

          {filteredProducts.length === 0 ? (
            <div className="py-16 text-center text-sm text-stone-500">
              No curated pieces found for this country filter.
            </div>
          ) : (
            <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {filteredProducts.map((product) => (
                <article key={product.id} className="group flex flex-col bg-white border border-rose-100/90">
                  <div
                    onClick={() => setSelectedProduct(product)}
                    className="relative aspect-[4/5] cursor-pointer overflow-hidden bg-rose-50/40"
                  >
                    {product.image_url ? (
                      <img
                        src={product.image_url}
                        alt={product.title}
                        className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-700"
                      />
                    ) : (
                      <div className="flex h-full items-center justify-center text-rose-200">
                        <ShoppingBag className="h-12 w-12" />
                      </div>
                    )}
                    {product.badge && (
                      <span
                        className="absolute left-3 top-3 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.15em] text-white"
                        style={{ backgroundColor: store.primary_color }}
                      >
                        {product.badge}
                      </span>
                    )}
                  </div>

                  <div className="flex flex-1 flex-col justify-between p-6 text-center">
                    <div>
                      <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-rose-700/70">
                        {product.category} · {product.merchant_name}
                      </p>
                      <h3
                        onClick={() => setSelectedProduct(product)}
                        className="mt-2 cursor-pointer font-serif text-lg font-medium text-[#2a1f24] hover:underline"
                      >
                        {product.title}
                      </h3>
                      <p className="mt-2 text-xs leading-relaxed text-stone-500 line-clamp-2">
                        {product.short_description || product.description}
                      </p>

                      <div className="mt-3 flex flex-wrap justify-center items-center gap-1">
                        <Globe className="h-3 w-3 text-rose-300" />
                        {(product.available_countries || ['US']).map((code) => (
                          <span
                            key={code}
                            className="bg-rose-50 px-2 py-0.5 text-[10px] font-medium text-rose-900"
                          >
                            {formatCountryLabel(code)}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="mt-5 pt-4 border-t border-rose-100">
                      <div className="flex justify-center items-baseline gap-2 mb-4">
                        <span className="font-serif text-xl font-bold" style={{ color: store.primary_color }}>
                          {product.price_display}
                        </span>
                        {product.original_price && (
                          <span className="text-xs text-stone-400 line-through">
                            {product.original_price}
                          </span>
                        )}
                      </div>
                      <a
                        href={goHref(product.id)}
                        target="_blank"
                        rel="noopener noreferrer sponsored"
                        className="w-full inline-flex items-center justify-center gap-2 py-3 text-[11px] font-bold uppercase tracking-[0.18em] text-white hover:opacity-90"
                        style={{ backgroundColor: store.primary_color }}
                      >
                        Discover Deal <ExternalLink className="h-3.5 w-3.5" />
                      </a>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>

        {/* THE EDIT (EDITORIAL JOURNAL) */}
        {posts.length > 0 && (
          <section id="edit">
            <div className="text-center mb-8">
              <p className="text-[11px] font-semibold uppercase tracking-[0.25em] text-rose-700">
                Editorial Notes
              </p>
              <h2 className="mt-2 font-serif text-3xl text-[#2a1f24]">The Journal</h2>
            </div>
            <div className="grid gap-8 md:grid-cols-2">
              {posts.map((post) => (
                <Link
                  key={post.id}
                  href={`/s/${store.slug}/blog/${post.slug}`}
                  className="group bg-white border border-rose-100 overflow-hidden flex flex-col"
                >
                  {post.cover_image && (
                    <img src={post.cover_image} alt={post.title} className="h-56 w-full object-cover group-hover:scale-105 transition-transform duration-700" />
                  )}
                  <div className="p-6 text-center">
                    <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-rose-700">
                      {post.category}
                    </span>
                    <h3 className="mt-2 font-serif text-xl text-[#2a1f24] group-hover:underline">
                      {post.title}
                    </h3>
                    <p className="mt-2 text-xs text-stone-500">{post.excerpt}</p>
                    <span className="mt-4 inline-flex items-center gap-1 text-[11px] font-bold uppercase tracking-[0.18em]" style={{ color: store.primary_color }}>
                      Read Story <ArrowRight className="h-3.5 w-3.5" />
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}
      </main>

      <footer className="mt-16 bg-[#2a1820] text-rose-100/80">
        <div className="mx-auto max-w-6xl px-4 py-12 text-center space-y-4">
          <p className="font-serif text-xl uppercase tracking-[0.2em] text-white">{store.name}</p>
          <p className="mx-auto max-w-2xl text-xs leading-relaxed opacity-80">{store.disclosure_text}</p>
          {store.contact_email && (
            <p className="inline-flex items-center gap-1.5 text-xs">
              <Mail className="h-3.5 w-3.5" /> {store.contact_email}
            </p>
          )}
          <div className="pt-4 border-t border-white/10">
            <Link href="/" className="inline-flex items-center gap-1.5 text-xs text-rose-200 hover:text-white">
              <Sparkles className="h-3.5 w-3.5" /> Curated with {platformName}
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
