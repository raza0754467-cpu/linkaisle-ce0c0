'use client';

import Link from 'next/link';
import {
  ArrowUpRight,
  Globe,
  Mail,
  Search,
  ShoppingBag,
  Sparkles,
} from 'lucide-react';
import { COUNTRY_OPTIONS, formatCountryLabel } from '@/lib/types';
import { StorefrontThemeProps } from './types';

export default function MinimalSwissTheme({
  store,
  products,
  filteredProducts,
  posts,
  platformName,
  categories,
  category,
  setCategory,
  countryFilter,
  setCountryFilter,
  search,
  setSearch,
  setSelectedProduct,
  goHref,
}: StorefrontThemeProps) {
  return (
    <div className="min-h-screen bg-white text-zinc-950">
      {/* RAZOR-SHARP SWISS HEADER */}
      <header className="sticky top-0 z-30 border-b border-zinc-950 bg-white">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3.5 sm:px-6 lg:px-8">
          <Link href={`/s/${store.slug}`} className="flex items-center gap-3">
            {store.logo_url ? (
              <img src={store.logo_url} alt={store.name} className="h-8 w-8 object-cover border border-zinc-950" />
            ) : (
              <div
                className="flex h-8 w-8 items-center justify-center text-xs font-mono font-bold text-white"
                style={{ backgroundColor: store.primary_color }}
              >
                {store.name.slice(0, 2).toUpperCase()}
              </div>
            )}
            <span className="font-display text-base font-extrabold uppercase tracking-tight">
              {store.name}
            </span>
          </Link>

          <div className="flex items-center gap-6 font-mono text-xs uppercase">
            <a href="#index" className="hover:underline">
              Index [{products.length}]
            </a>
            {posts.length > 0 && (
              <a href="#notes" className="hidden sm:inline hover:underline">
                Notes [{posts.length}]
              </a>
            )}
            <span className="border border-zinc-950 px-2 py-0.5 text-[10px] font-bold">
              {formatCountryLabel(store.target_country || 'US')} · {store.currency || 'USD'}
            </span>
          </div>
        </div>
      </header>

      {/* ARCHITECTURAL SPLIT-GRID HERO */}
      <section className="border-b border-zinc-950">
        <div className="mx-auto grid max-w-7xl lg:grid-cols-12">
          <div className="lg:col-span-8 p-6 sm:p-12 lg:border-r border-zinc-950">
            <p className="font-mono text-xs uppercase tracking-widest text-zinc-500">
              Curated Object Directory — High-CTR Edition
            </p>
            <h1 className="mt-4 font-display text-4xl font-extrabold tracking-tight sm:text-6xl leading-[1.03]">
              {store.hero_title || store.name}
            </h1>
            <p className="mt-5 max-w-xl text-sm sm:text-base leading-relaxed text-zinc-600">
              {store.hero_subtitle || store.description}
            </p>
          </div>

          <div className="lg:col-span-4 flex flex-col justify-between bg-zinc-50 p-6 sm:p-8 border-t lg:border-t-0 border-zinc-950">
            <div className="space-y-3 font-mono text-xs">
              <div className="flex justify-between border-b border-zinc-300 pb-2">
                <span className="text-zinc-500">TOTAL OBJECTS</span>
                <span className="font-bold">{String(products.length).padStart(2, '0')}</span>
              </div>
              <div className="flex justify-between border-b border-zinc-300 pb-2">
                <span className="text-zinc-500">CATEGORIES</span>
                <span className="font-bold">{String(categories.length - 1).padStart(2, '0')}</span>
              </div>
              <div className="flex justify-between border-b border-zinc-300 pb-2">
                <span className="text-zinc-500">PRIMARY MARKET</span>
                <span className="font-bold">{formatCountryLabel(store.target_country || 'US')}</span>
              </div>
              <div className="flex justify-between pb-1">
                <span className="text-zinc-500">DIRECT LINKS</span>
                <span className="font-bold text-emerald-700">VERIFIED</span>
              </div>
            </div>

            <a
              href="#index"
              className="mt-6 w-full inline-flex items-center justify-between px-5 py-3.5 font-mono text-xs font-bold uppercase text-white transition-colors hover:opacity-90"
              style={{ backgroundColor: store.primary_color }}
            >
              <span>{store.hero_cta || 'Browse Index'}</span>
              <ArrowUpRight className="h-4 w-4" />
            </a>
          </div>
        </div>
      </section>

      {/* STICKY 1PX BORDERED TOOLBAR */}
      <div id="index" className="border-b border-zinc-950 bg-zinc-50">
        <div className="mx-auto flex max-w-7xl flex-col gap-3 px-4 py-3 sm:px-6 lg:flex-row lg:items-center lg:justify-between lg:px-8">
          <div className="flex flex-wrap gap-1.5">
            {categories.map((cat) => {
              const active = category === cat;
              return (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategory(cat)}
                  className={`border px-3 py-1 font-mono text-[11px] uppercase transition-colors ${
                    active
                      ? 'border-zinc-950 bg-zinc-950 text-white font-bold'
                      : 'border-zinc-300 bg-white text-zinc-700 hover:border-zinc-950'
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>

          <div className="flex flex-wrap gap-2">
            <select
              value={countryFilter}
              onChange={(e) => setCountryFilter(e.target.value)}
              aria-label="Filter by available country"
              className="border border-zinc-950 bg-white px-3 py-1.5 font-mono text-xs focus:outline-none"
            >
              <option value="ALL">COUNTRY: ALL</option>
              {COUNTRY_OPTIONS.map((c) => (
                <option key={c.code} value={c.code}>
                  COUNTRY: {c.short.toUpperCase()}
                </option>
              ))}
            </select>
            <div className="relative flex-1 sm:w-52">
              <Search className="pointer-events-none absolute left-2.5 top-2 h-3.5 w-3.5 text-zinc-400" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="SEARCH INDEX..."
                className="w-full border border-zinc-950 bg-white py-1.5 pl-8 pr-3 font-mono text-xs focus:outline-none"
              />
            </div>
          </div>
        </div>
      </div>

      {/* NUMBERED HIGH-CTR CATALOGUE GRID */}
      <main className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8 space-y-16">
        {filteredProducts.length === 0 ? (
          <div className="border border-zinc-300 p-12 text-center font-mono text-xs text-zinc-500">
            0 OBJECTS MATCH CURRENT FILTER.
          </div>
        ) : (
          <div className="grid border-l border-t border-zinc-950 sm:grid-cols-2 lg:grid-cols-4">
            {filteredProducts.map((product, index) => (
              <article
                key={product.id}
                className="group flex flex-col justify-between border-b border-r border-zinc-950 bg-white"
              >
                <div>
                  <div className="flex items-center justify-between border-b border-zinc-200 px-4 py-2 font-mono text-[10px] uppercase text-zinc-500">
                    <span>NO. {String(index + 1).padStart(2, '0')} · {product.category}</span>
                    <span className="font-bold text-zinc-900">{product.merchant_name}</span>
                  </div>

                  <div
                    onClick={() => setSelectedProduct(product)}
                    className="relative aspect-[4/3] cursor-pointer overflow-hidden bg-zinc-100 border-b border-zinc-200"
                  >
                    {product.image_url ? (
                      <img
                        src={product.image_url}
                        alt={product.title}
                        className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    ) : (
                      <div className="flex h-full items-center justify-center text-zinc-300">
                        <ShoppingBag className="h-10 w-10" />
                      </div>
                    )}
                    {product.badge && (
                      <span
                        className="absolute left-0 top-0 px-2.5 py-1 font-mono text-[10px] font-bold uppercase text-white"
                        style={{ backgroundColor: store.accent_color }}
                      >
                        {product.badge}
                      </span>
                    )}
                  </div>

                  <div className="p-5">
                    <h3
                      onClick={() => setSelectedProduct(product)}
                      className="cursor-pointer font-display text-base font-extrabold leading-snug hover:underline"
                    >
                      {product.title}
                    </h3>
                    <p className="mt-2 text-xs leading-relaxed text-zinc-600 line-clamp-2">
                      {product.short_description || product.description}
                    </p>

                    <div className="mt-3 flex flex-wrap items-center gap-1">
                      <Globe className="h-3 w-3 text-zinc-400" />
                      {(product.available_countries || ['US']).map((code) => (
                        <span
                          key={code}
                          className="border border-zinc-300 px-1.5 py-0.5 font-mono text-[9px] font-bold uppercase text-zinc-700"
                        >
                          {formatCountryLabel(code)}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="px-5 pb-5">
                  <div className="flex items-baseline justify-between border-t border-zinc-200 pt-3 mb-3">
                    <div className="flex items-baseline gap-2">
                      <span className="font-mono text-xl font-extrabold text-zinc-950">
                        {product.price_display}
                      </span>
                      {product.original_price && (
                        <span className="font-mono text-xs text-zinc-400 line-through">
                          {product.original_price}
                        </span>
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={() => setSelectedProduct(product)}
                      className="font-mono text-[10px] uppercase underline text-zinc-500 hover:text-zinc-950"
                    >
                      Specs
                    </button>
                  </div>

                  <a
                    href={goHref(product.id)}
                    target="_blank"
                    rel="noopener noreferrer sponsored"
                    className="w-full inline-flex items-center justify-between px-4 py-3 font-mono text-xs font-bold uppercase text-white transition-colors hover:bg-emerald-600"
                    style={{ backgroundColor: store.primary_color }}
                  >
                    <span>Buy via {product.merchant_name}</span>
                    <ArrowUpRight className="h-4 w-4" />
                  </a>
                </div>
              </article>
            ))}
          </div>
        )}

        {/* EDITORIAL INDEX LIST */}
        {posts.length > 0 && (
          <section id="notes">
            <h2 className="font-mono text-xs font-bold uppercase tracking-widest text-zinc-500 mb-4">
              Research Notes & Buyer Guides
            </h2>
            <div className="divide-y divide-zinc-950 border-y border-zinc-950">
              {posts.map((post, idx) => (
                <Link
                  key={post.id}
                  href={`/s/${store.slug}/blog/${post.slug}`}
                  className="group flex flex-wrap items-center justify-between gap-4 py-5 hover:bg-zinc-50 px-3 transition-colors"
                >
                  <div className="flex items-baseline gap-4">
                    <span className="font-mono text-xs text-zinc-400">
                      {String(idx + 1).padStart(2, '0')}
                    </span>
                    <div>
                      <h3 className="font-display text-lg font-extrabold group-hover:underline">
                        {post.title}
                      </h3>
                      <p className="mt-1 text-xs text-zinc-600">{post.excerpt}</p>
                    </div>
                  </div>
                  <span className="inline-flex items-center gap-1 font-mono text-xs font-bold uppercase">
                    Read <ArrowUpRight className="h-4 w-4" />
                  </span>
                </Link>
              ))}
            </div>
          </section>
        )}
      </main>

      <footer className="mt-16 border-t border-zinc-950 bg-zinc-950 text-zinc-400">
        <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8 space-y-4">
          <p className="font-display text-sm font-extrabold uppercase text-white">{store.name}</p>
          <p className="max-w-2xl text-xs leading-relaxed">{store.disclosure_text}</p>
          <div className="border-t border-zinc-800 pt-4 flex flex-wrap items-center justify-between gap-3 font-mono text-[11px]">
            <span>{store.contact_email || `© ${new Date().getFullYear()} ${store.name}`}</span>
            <Link href="/" className="inline-flex items-center gap-1.5 text-emerald-400 hover:underline">
              <Sparkles className="h-3.5 w-3.5" /> Powered by {platformName}
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
