'use client';

import Link from 'next/link';
import {
  ArrowRight,
  CheckCircle2,
  Cpu,
  ExternalLink,
  Globe,
  Mail,
  Search,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  Zap,
} from 'lucide-react';
import { COUNTRY_OPTIONS, formatCountryLabel } from '@/lib/types';
import { StorefrontThemeProps, calcSavingsPct } from './types';

export default function TechCyberTheme({
  store,
  products,
  filteredProducts,
  featuredProducts,
  posts,
  platformName,
  categories,
  category,
  setCategory,
  countryFilter,
  setCountryFilter,
  search,
  setSearch,
  setSelectedProduct,
  goHref,
}: StorefrontThemeProps) {
  const heroItem = featuredProducts[0] || products[0] || null;
  const bentoItems = (featuredProducts.length ? featuredProducts : products).slice(0, 3);

  return (
    <div className="min-h-screen bg-white text-[#0f172a]">
      {/* CRISP APPLE-STYLE TOP BAR */}
      <header className="sticky top-0 z-30 border-b border-slate-200/80 bg-white/90 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3.5 sm:px-6 lg:px-8">
          <Link href={`/s/${store.slug}`} className="flex items-center gap-3">
            {store.logo_url ? (
              <img
                src={store.logo_url}
                alt={store.name}
                className="h-9 w-9 rounded-xl object-cover border border-slate-200"
              />
            ) : (
              <div
                className="flex h-9 w-9 items-center justify-center rounded-xl text-white shadow-sm"
                style={{ backgroundColor: store.primary_color }}
              >
                <Cpu className="h-5 w-5" />
              </div>
            )}
            <div>
              <p className="font-display text-base font-extrabold tracking-tight text-slate-950">
                {store.name}
              </p>
              <p className="text-[11px] font-medium text-slate-500">
                {formatCountryLabel(store.target_country || 'US')} · {store.currency || 'USD'}
              </p>
            </div>
          </Link>

          <nav className="flex items-center gap-6 text-xs font-semibold text-slate-600">
            <a href="#featured" className="hidden sm:inline hover:text-slate-950">
              Highlights
            </a>
            <a href="#catalog" className="hover:text-slate-950">
              All Products ({products.length})
            </a>
            {posts.length > 0 && (
              <a href="#guides" className="hover:text-slate-950">
                Guides
              </a>
            )}
          </nav>
        </div>
      </header>

      {/* PURE WHITE APPLE-INSPIRED HARDWARE HERO */}
      <section className="relative overflow-hidden border-b border-slate-200/80 bg-gradient-to-b from-[#f5f8fc] via-white to-white">
        <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8 lg:py-20">
          <div className="grid items-center gap-12 lg:grid-cols-12">
            <div className="lg:col-span-7">
              <span
                className="inline-flex items-center gap-1.5 rounded-full px-3.5 py-1 text-xs font-bold text-white shadow-sm"
                style={{ backgroundColor: store.primary_color }}
              >
                <Zap className="h-3.5 w-3.5" />
                Curated Tech & Smart Gear
              </span>

              <h1 className="mt-5 font-display text-4xl font-extrabold tracking-tight text-slate-950 sm:text-6xl leading-[1.05]">
                {store.hero_title || store.name}
              </h1>
              <p className="mt-5 max-w-xl text-base sm:text-lg leading-relaxed text-slate-600">
                {store.hero_subtitle || store.description}
              </p>

              <div className="mt-8 flex flex-wrap items-center gap-3.5">
                <a
                  href="#catalog"
                  className="inline-flex items-center gap-2 rounded-full px-7 py-3.5 text-sm font-bold text-white shadow-md hover:opacity-90 transition-all"
                  style={{ backgroundColor: store.primary_color }}
                >
                  {store.hero_cta || 'Browse All Gear'}
                  <ArrowRight className="h-4 w-4" />
                </a>
                <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white px-4 py-3 text-xs font-semibold text-slate-700 shadow-sm">
                  <ShieldCheck className="h-4 w-4 text-emerald-600" />
                  Direct Merchant Links · {formatCountryLabel(store.target_country || 'US')}
                </span>
              </div>
            </div>

            {heroItem && (
              <div className="lg:col-span-5">
                <div className="rounded-3xl border border-slate-200 bg-[#f7f9fc] p-5 shadow-xl shadow-slate-900/5">
                  <div
                    onClick={() => setSelectedProduct(heroItem)}
                    className="relative cursor-pointer overflow-hidden rounded-2xl bg-white aspect-[16/10] border border-slate-200/70"
                  >
                    {heroItem.image_url ? (
                      <img
                        src={heroItem.image_url}
                        alt={heroItem.title}
                        className="h-full w-full object-cover hover:scale-105 transition-transform duration-500"
                      />
                    ) : null}
                    <span
                      className="absolute left-3 top-3 rounded-full px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-white shadow"
                      style={{ backgroundColor: store.primary_color }}
                    >
                      Top Pick
                    </span>
                  </div>
                  <div className="mt-4 px-1">
                    <p className="text-[11px] font-bold uppercase tracking-wider" style={{ color: store.primary_color }}>
                      {heroItem.category}
                    </p>
                    <h2 className="mt-1 font-display text-lg font-extrabold text-slate-950">
                      {heroItem.title}
                    </h2>
                    <div className="mt-3 flex items-center justify-between">
                      <span className="font-display text-2xl font-extrabold text-slate-950">
                        {heroItem.price_display}
                      </span>
                      <a
                        href={goHref(heroItem.id)}
                        target="_blank"
                        rel="noopener noreferrer sponsored"
                        className="inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-xs font-bold text-white hover:opacity-90"
                        style={{ backgroundColor: store.primary_color }}
                      >
                        Check Price <ExternalLink className="h-3.5 w-3.5" />
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      <main className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8 space-y-16">
        {/* LIGHT TITANIUM BENTO HIGHLIGHTS */}
        {bentoItems.length >= 2 && (
          <section id="featured">
            <div className="mb-6">
              <p className="text-xs font-bold uppercase tracking-widest" style={{ color: store.primary_color }}>
                Editor Spotlight
              </p>
              <h2 className="mt-1 font-display text-2xl font-extrabold text-slate-950">
                Featured Highlights
              </h2>
            </div>
            <div className="grid gap-5 lg:grid-cols-3">
              {bentoItems.map((item, idx) => (
                <div
                  key={item.id}
                  onClick={() => setSelectedProduct(item)}
                  className={`group cursor-pointer overflow-hidden rounded-3xl border border-slate-200 bg-[#f6f8fb] hover:border-sky-300 hover:shadow-lg transition-all flex flex-col justify-between ${
                    idx === 0 ? 'lg:col-span-2' : ''
                  }`}
                >
                  <div className="relative h-52 overflow-hidden bg-white">
                    {item.image_url && (
                      <img
                        src={item.image_url}
                        alt={item.title}
                        className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    )}
                    <span className="absolute right-3 top-3 rounded-full bg-white/95 px-3 py-1 font-display text-xs font-extrabold text-slate-950 shadow">
                      {item.price_display}
                    </span>
                  </div>
                  <div className="p-5 flex items-center justify-between gap-4">
                    <div className="min-w-0">
                      <p className="text-[11px] font-bold uppercase tracking-wider" style={{ color: store.primary_color }}>
                        {item.category}
                      </p>
                      <h3 className="mt-1 font-display text-base font-extrabold text-slate-950 truncate">
                        {item.title}
                      </h3>
                    </div>
                    <span className="shrink-0 rounded-full bg-white border border-slate-200 px-3 py-1.5 text-xs font-bold text-slate-800 group-hover:bg-slate-950 group-hover:text-white transition-colors">
                      View →
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* CLEAN FILTER BAR + 4-COLUMN DESKTOP PRODUCT GRID */}
        <section id="catalog">
          <div className="rounded-2xl border border-slate-200 bg-[#f6f8fb] p-4">
            <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
              <div className="flex flex-wrap gap-2">
                {categories.map((cat) => {
                  const active = category === cat;
                  return (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setCategory(cat)}
                      className={`rounded-full px-4 py-1.5 text-xs font-bold transition-all ${
                        active
                          ? 'text-white shadow-sm'
                          : 'bg-white border border-slate-200 text-slate-700 hover:border-slate-400'
                      }`}
                      style={active ? { backgroundColor: store.primary_color } : undefined}
                    >
                      {cat}
                    </button>
                  );
                })}
              </div>

              <div className="flex flex-wrap gap-2">
                <select
                  value={countryFilter}
                  onChange={(e) => setCountryFilter(e.target.value)}
                  aria-label="Filter by available country"
                  className="rounded-full border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-800 focus:outline-none"
                >
                  <option value="ALL">All Countries</option>
                  {COUNTRY_OPTIONS.map((c) => (
                    <option key={c.code} value={c.code}>
                      Available in: {c.name}
                    </option>
                  ))}
                </select>
                <div className="relative flex-1 sm:w-52">
                  <Search className="pointer-events-none absolute left-3.5 top-2.5 h-4 w-4 text-slate-400" />
                  <input
                    type="text"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Search catalog..."
                    className="w-full rounded-full border border-slate-300 bg-white py-2 pl-9 pr-4 text-xs text-slate-900 focus:outline-none"
                  />
                </div>
              </div>
            </div>
          </div>

          {filteredProducts.length === 0 ? (
            <div className="mt-8 rounded-2xl border border-slate-200 bg-[#f6f8fb] p-12 text-center">
              <ShoppingBag className="mx-auto h-10 w-10 text-slate-300" />
              <p className="mt-3 text-sm font-semibold text-slate-600">
                No products match your selected country or search.
              </p>
            </div>
          ) : (
            <div className="mt-7 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {filteredProducts.map((product) => {
                const savePct = calcSavingsPct(product.price_display, product.original_price);
                return (
                  <article
                    key={product.id}
                    className="group flex flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white hover:border-sky-300 hover:shadow-xl transition-all duration-300"
                  >
                    <div
                      onClick={() => setSelectedProduct(product)}
                      className="relative aspect-[4/3] cursor-pointer overflow-hidden bg-[#f4f6fa]"
                    >
                      {product.image_url ? (
                        <img
                          src={product.image_url}
                          alt={product.title}
                          className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                      ) : (
                        <div className="flex h-full items-center justify-center text-slate-300">
                          <Cpu className="h-10 w-10" />
                        </div>
                      )}
                      {savePct && (
                        <span className="absolute right-2.5 top-2.5 rounded-full bg-emerald-600 px-2 py-0.5 text-[10px] font-bold text-white">
                          -{savePct}%
                        </span>
                      )}
                      {product.badge && (
                        <span
                          className="absolute left-2.5 top-2.5 rounded-full px-2.5 py-0.5 text-[10px] font-bold text-white shadow-sm"
                          style={{ backgroundColor: store.primary_color }}
                        >
                          {product.badge}
                        </span>
                      )}
                    </div>

                    <div className="flex flex-1 flex-col justify-between p-4">
                      <div>
                        <div className="flex items-center justify-between text-[10px] font-bold uppercase text-slate-400">
                          <span style={{ color: store.primary_color }}>{product.category}</span>
                          <span>{product.merchant_name}</span>
                        </div>
                        <h3
                          onClick={() => setSelectedProduct(product)}
                          className="mt-1.5 cursor-pointer font-display text-sm font-extrabold text-slate-950 leading-snug line-clamp-2 group-hover:underline"
                        >
                          {product.title}
                        </h3>
                        <p className="mt-1.5 text-xs leading-relaxed text-slate-500 line-clamp-2">
                          {product.short_description || product.description}
                        </p>

                        {product.benefits?.length > 0 && (
                          <div className="mt-2.5 flex items-center gap-1.5 text-[11px] text-slate-600">
                            <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600 shrink-0" />
                            <span className="truncate">{product.benefits[0]}</span>
                          </div>
                        )}

                        <div className="mt-2.5 flex flex-wrap items-center gap-1">
                          <Globe className="h-3 w-3 text-slate-400" />
                          {(product.available_countries || ['US']).slice(0, 3).map((code) => (
                            <span
                              key={code}
                              className="rounded-md bg-slate-100 px-1.5 py-0.5 text-[10px] font-semibold text-slate-700"
                            >
                              {formatCountryLabel(code)}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="mt-4 border-t border-slate-100 pt-3">
                        <div className="flex items-center justify-between mb-2.5">
                          <div className="flex items-baseline gap-1.5">
                            <span className="font-display text-lg font-extrabold text-slate-950">
                              {product.price_display}
                            </span>
                            {product.original_price && (
                              <span className="text-[11px] text-slate-400 line-through">
                                {product.original_price}
                              </span>
                            )}
                          </div>
                          <button
                            type="button"
                            onClick={() => setSelectedProduct(product)}
                            className="text-[11px] font-bold text-slate-500 hover:text-slate-950"
                          >
                            Specs
                          </button>
                        </div>

                        <a
                          href={goHref(product.id)}
                          target="_blank"
                          rel="noopener noreferrer sponsored"
                          className="w-full inline-flex items-center justify-center gap-1.5 rounded-full py-2.5 text-xs font-bold text-white shadow-sm hover:opacity-90"
                          style={{ backgroundColor: store.primary_color }}
                        >
                          Check Price
                          <ExternalLink className="h-3.5 w-3.5" />
                        </a>
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </section>

        {/* GUIDES */}
        {posts.length > 0 && (
          <section id="guides">
            <h2 className="font-display text-2xl font-extrabold text-slate-950 mb-6">
              Buying Guides & Reviews
            </h2>
            <div className="grid gap-6 md:grid-cols-2">
              {posts.map((post) => (
                <Link
                  key={post.id}
                  href={`/s/${store.slug}/blog/${post.slug}`}
                  className="group overflow-hidden rounded-2xl border border-slate-200 bg-[#f6f8fb] hover:border-sky-300 transition-all flex flex-col"
                >
                  {post.cover_image && (
                    <img src={post.cover_image} alt={post.title} className="h-44 w-full object-cover" />
                  )}
                  <div className="p-6 flex-1 flex flex-col justify-between">
                    <div>
                      <span className="text-[11px] font-bold uppercase tracking-wider" style={{ color: store.primary_color }}>
                        {post.category}
                      </span>
                      <h3 className="mt-2 font-display text-lg font-bold text-slate-950 group-hover:underline">
                        {post.title}
                      </h3>
                      <p className="mt-2 text-xs text-slate-600">{post.excerpt}</p>
                    </div>
                    <span className="mt-4 inline-flex items-center gap-1.5 text-xs font-bold" style={{ color: store.primary_color }}>
                      Read Guide <ArrowRight className="h-3.5 w-3.5" />
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}
      </main>

      <footer className="mt-16 border-t border-slate-200 bg-[#f5f7fa] text-slate-600">
        <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8 space-y-5">
          <div className="grid gap-6 md:grid-cols-3">
            <div className="md:col-span-2">
              <p className="font-display text-base font-extrabold text-slate-950">{store.name}</p>
              <p className="mt-2 text-xs leading-relaxed text-slate-500">{store.disclosure_text}</p>
            </div>
            <div className="text-xs space-y-2">
              {store.contact_email && (
                <p className="flex items-center gap-2">
                  <Mail className="h-4 w-4 text-slate-400" /> {store.contact_email}
                </p>
              )}
            </div>
          </div>
          <div className="border-t border-slate-200 pt-5 flex flex-wrap justify-between gap-3 text-xs">
            <p className="text-slate-500">© {new Date().getFullYear()} {store.name}</p>
            <Link href="/" className="inline-flex items-center gap-1.5 font-semibold text-slate-800 hover:underline">
              <Sparkles className="h-3.5 w-3.5" style={{ color: store.primary_color }} /> Built with {platformName}
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
