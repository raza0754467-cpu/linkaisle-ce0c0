import { BlogPost, Product, Store } from '@/lib/types';

export interface StorefrontThemeProps {
  store: Store;
  products: Product[];
  filteredProducts: Product[];
  featuredProducts: Product[];
  posts: BlogPost[];
  platformName: string;
  categories: string[];
  category: string;
  setCategory: (val: string) => void;
  countryFilter: string;
  setCountryFilter: (val: string) => void;
  search: string;
  setSearch: (val: string) => void;
  setSelectedProduct: (product: Product | null) => void;
  goHref: (productId: string) => string;
}

export function calcSavingsPct(priceStr: string, origStr: string): number | null {
  const p = parseFloat(String(priceStr || '').replace(/[^0-9.]/g, ''));
  const o = parseFloat(String(origStr || '').replace(/[^0-9.]/g, ''));
  if (!p || !o || o <= p) return null;
  return Math.round(((o - p) / o) * 100);
}
