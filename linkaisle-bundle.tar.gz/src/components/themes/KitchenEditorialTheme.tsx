'use client';

import Link from 'next/link';
import {
  ArrowRight,
  Award,
  BookOpen,
  CheckCircle2,
  ExternalLink,
  Globe,
  Mail,
  Search,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  Tag,
  Truck,
} from 'lucide-react';
import { COUNTRY_OPTIONS, formatCountryLabel } from '@/lib/types';
import { StorefrontThemeProps, calcSavingsPct } from './types';

export default function KitchenEditorialTheme({
  store,
  products,
  filteredProducts,
  featuredProducts,
  posts,
  platformName,
  categories,
  category,
  setCategory,
  countryFilter,
  setCountryFilter,
  search,
  setSearch,
  setSelectedProduct,
  goHref,
}: StorefrontThemeProps) {
  const heroProducts = (featuredProducts.length ? featuredProducts : products).slice(0, 3);
  const spotlight = featuredProducts[0] || products[0] || null;

  return (
    <div className="min-h-screen bg-[#faf7f2] text-stone-900">
      {/* ANNOUNCEMENT RIBBON */}
      <div
        className="px-4 py-2 text-center text-[11px] font-semibold tracking-wide text-white"
        style={{ backgroundColor: store.primary_color }}
      >
        Curated {store.name} Collection · Verified Merchant Deals · Primary Market:{' '}
        {formatCountryLabel(store.target_country || 'US')} ({store.currency || 'USD'})
      </div>

      {/* EDITORIAL HEADER */}
      <header className="sticky top-0 z-30 border-b border-stone-200/80 bg-[#faf7f2]/95 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
          <Link href={`/s/${store.slug}`} className="flex items-center gap-3">
            {store.logo_url ? (
              <img
                src={store.logo_url}
                alt={store.name}
                className="h-10 w-10 rounded-xl object-cover border border-stone-200"
              />
            ) : (
              <div
                className="flex h-10 w-10 items-center justify-center rounded-xl text-white font-serif text-lg font-bold shadow-sm"
                style={{ backgroundColor: store.primary_color }}
              >
                {store.name.slice(0, 1).toUpperCase()}
              </div>
            )}
            <div>
              <p className="font-serif text-lg font-bold tracking-tight text-stone-900 leading-none">
                {store.name}
              </p>
              {store.tagline && (
                <p className="mt-1 text-[11px] text-stone-500 hidden sm:block">{store.tagline}</p>
              )}
            </div>
          </Link>

          <nav className="flex items-center gap-6 text-xs font-semibold uppercase tracking-wider text-stone-600">
            <a href="#featured" className="hidden sm:inline hover:text-stone-950">
              Spotlight
            </a>
            <a href="#catalog" className="hover:text-stone-950">
              Shop ({products.length})
            </a>
            {posts.length > 0 && (
              <a href="#journal" className="hover:text-stone-950">
                Journal
              </a>
            )}
            <a href="#disclosure" className="hidden md:inline hover:text-stone-950">
              Disclosure
            </a>
          </nav>
        </div>
      </header>

      {/* MAGAZINE SPLIT BENTO HERO */}
      <section className="border-b border-stone-200 bg-gradient-to-br from-[#fffdf9] via-[#f8f1e7] to-[#f1e7d9]">
        <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8 lg:py-16">
          <div className="grid items-center gap-10 lg:grid-cols-12">
            <div className="lg:col-span-6">
              <div className="inline-flex items-center gap-2 rounded-full border border-stone-300 bg-white/80 px-3.5 py-1 text-xs font-semibold text-stone-700">
                <Award className="h-3.5 w-3.5" style={{ color: store.primary_color }} />
                Editorially Curated · {formatCountryLabel(store.target_country || 'US')} Edition
              </div>
              <h1 className="mt-5 font-serif text-4xl font-bold tracking-tight text-stone-900 sm:text-5xl leading-[1.1]">
                {store.hero_title || store.name}
              </h1>
              <p className="mt-5 text-base leading-relaxed text-stone-600">
                {store.hero_subtitle || store.description}
              </p>

              <div className="mt-8 flex flex-wrap items-center gap-3">
                <a
                  href="#catalog"
                  className="inline-flex items-center gap-2 rounded-full px-7 py-3.5 text-sm font-bold text-white shadow-md hover:opacity-95 transition-all"
                  style={{ backgroundColor: store.primary_color }}
                >
                  {store.hero_cta || 'Shop Curated Finds'}
                  <ArrowRight className="h-4 w-4" />
                </a>
                {posts.length > 0 && (
                  <a
                    href="#journal"
                    className="inline-flex items-center gap-2 rounded-full border border-stone-300 bg-white px-6 py-3.5 text-sm font-semibold text-stone-800 hover:bg-stone-50"
                  >
                    <BookOpen className="h-4 w-4" />
                    Read Buying Guides
                  </a>
                )}
              </div>
            </div>

            {/* RIGHT: 3-ITEM EDITORIAL PRODUCT COLLAGE */}
            <div className="lg:col-span-6">
              {heroProducts.length > 0 ? (
                <div className="grid grid-cols-2 gap-3.5">
                  <div
                    onClick={() => setSelectedProduct(heroProducts[0])}
                    className="col-span-2 sm:col-span-1 sm:row-span-2 group relative cursor-pointer overflow-hidden rounded-3xl border border-stone-200 bg-white shadow-md min-h-[260px]"
                  >
                    {heroProducts[0].image_url ? (
                      <img
                        src={heroProducts[0].image_url}
                        alt={heroProducts[0].title}
                        className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    ) : (
                      <div className="flex h-full items-center justify-center bg-stone-100">
                        <ShoppingBag className="h-10 w-10 text-stone-400" />
                      </div>
                    )}
                    <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-4 text-white">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-amber-300">
                        #1 Editor Pick
                      </span>
                      <p className="text-sm font-bold leading-snug line-clamp-2">
                        {heroProducts[0].title}
                      </p>
                      <p className="mt-1 text-sm font-extrabold text-amber-200">
                        {heroProducts[0].price_display}
                      </p>
                    </div>
                  </div>

                  {heroProducts.slice(1, 3).map((hp) => (
                    <div
                      key={hp.id}
                      onClick={() => setSelectedProduct(hp)}
                      className="group relative cursor-pointer overflow-hidden rounded-2xl border border-stone-200 bg-white shadow-sm h-40"
                    >
                      {hp.image_url ? (
                        <img
                          src={hp.image_url}
                          alt={hp.title}
                          className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                      ) : (
                        <div className="flex h-full items-center justify-center bg-stone-100">
                          <ShoppingBag className="h-8 w-8 text-stone-400" />
                        </div>
                      )}
                      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/75 to-transparent p-3 text-white">
                        <p className="text-xs font-bold line-clamp-1">{hp.title}</p>
                        <p className="text-xs font-extrabold text-amber-200">{hp.price_display}</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : null}
            </div>
          </div>
        </div>
      </section>

      {/* 4-PILLAR TRUST BAR (SHOPIFY DAWN STYLE) */}
      <section className="border-b border-stone-200 bg-white">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-4 px-4 py-6 sm:px-6 lg:grid-cols-4 lg:px-8">
          {[
            { icon: Award, title: 'Handpicked Quality', sub: 'Practical, high-utility picks only' },
            { icon: ShieldCheck, title: 'Official Merchants', sub: 'Checkout directly on trusted stores' },
            { icon: Truck, title: 'Country Clarity', sub: 'Filter deals available in your region' },
            { icon: Sparkles, title: 'Transparent Links', sub: '100% disclosed affiliate links' },
          ].map((b) => {
            const Icon = b.icon;
            return (
              <div key={b.title} className="flex items-center gap-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-stone-100 text-stone-700">
                  <Icon className="h-4 w-4" style={{ color: store.primary_color }} />
                </div>
                <div>
                  <p className="text-xs font-bold text-stone-900">{b.title}</p>
                  <p className="text-[11px] text-stone-500">{b.sub}</p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      <main className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8 space-y-16">
        {/* DEAL OF THE WEEK SPOTLIGHT BANNER */}
        {spotlight && (
          <section
            id="featured"
            className="overflow-hidden rounded-3xl border border-stone-200 bg-white shadow-soft"
          >
            <div className="grid lg:grid-cols-12">
              <div className="lg:col-span-5 relative min-h-[280px] bg-stone-100">
                {spotlight.image_url ? (
                  <img
                    src={spotlight.image_url}
                    alt={spotlight.title}
                    className="h-full w-full object-cover"
                  />
                ) : null}
                <span
                  className="absolute left-4 top-4 rounded-full px-3.5 py-1 text-xs font-bold text-white shadow"
                  style={{ backgroundColor: store.accent_color }}
                >
                  Featured Deal of the Week
                </span>
              </div>
              <div className="lg:col-span-7 p-7 sm:p-10 flex flex-col justify-between">
                <div>
                  <p
                    className="text-xs font-bold uppercase tracking-widest"
                    style={{ color: store.primary_color }}
                  >
                    {spotlight.category} · Available via {spotlight.merchant_name}
                  </p>
                  <h2 className="mt-2 font-serif text-2xl font-bold text-stone-900 sm:text-3xl">
                    {spotlight.title}
                  </h2>
                  <p className="mt-3 text-sm leading-relaxed text-stone-600">
                    {spotlight.description || spotlight.short_description}
                  </p>

                  {spotlight.benefits?.length > 0 && (
                    <div className="mt-5 grid gap-2 sm:grid-cols-2">
                      {spotlight.benefits.slice(0, 4).map((b, i) => (
                        <div key={i} className="flex items-start gap-2 text-xs text-stone-700">
                          <CheckCircle2
                            className="h-4 w-4 shrink-0 mt-0.5"
                            style={{ color: store.accent_color }}
                          />
                          <span>{b}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-stone-100 pt-5">
                  <div className="flex items-baseline gap-2.5">
                    <span
                      className="font-display text-3xl font-extrabold"
                      style={{ color: store.primary_color }}
                    >
                      {spotlight.price_display}
                    </span>
                    {spotlight.original_price && (
                      <span className="text-sm text-stone-400 line-through">
                        {spotlight.original_price}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => setSelectedProduct(spotlight)}
                      className="rounded-full border border-stone-300 px-5 py-2.5 text-xs font-bold text-stone-700 hover:bg-stone-50"
                    >
                      Quick View
                    </button>
                    <a
                      href={goHref(spotlight.id)}
                      target="_blank"
                      rel="noopener noreferrer sponsored"
                      className="inline-flex items-center gap-2 rounded-full px-6 py-2.5 text-xs font-bold text-white shadow-md hover:opacity-90"
                      style={{ backgroundColor: store.primary_color }}
                    >
                      Check Deal on {spotlight.merchant_name}
                      <ExternalLink className="h-3.5 w-3.5" />
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* MAIN CATALOG */}
        <section id="catalog">
          <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
            <div>
              <p
                className="text-xs font-bold uppercase tracking-widest"
                style={{ color: store.primary_color }}
              >
                Browse The Collection
              </p>
              <h2 className="mt-1 font-serif text-3xl font-bold text-stone-900">
                All Curated Essentials
              </h2>
            </div>

            <div className="flex flex-wrap items-center gap-2.5">
              <div className="relative flex-1 sm:w-48">
                <Globe className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-stone-400" />
                <select
                  value={countryFilter}
                  onChange={(e) => setCountryFilter(e.target.value)}
                  aria-label="Filter by available country"
                  className="w-full rounded-full border border-stone-300 bg-white py-2.5 pl-9 pr-4 text-xs font-semibold text-stone-800 focus:outline-none"
                >
                  <option value="ALL">All Countries</option>
                  {COUNTRY_OPTIONS.map((c) => (
                    <option key={c.code} value={c.code}>
                      Available in: {c.name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="relative flex-1 sm:w-64">
                <Search className="pointer-events-none absolute left-3.5 top-3 h-4 w-4 text-stone-400" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search products..."
                  className="w-full rounded-full border border-stone-300 bg-white py-2.5 pl-10 pr-4 text-xs text-stone-900 focus:outline-none"
                />
              </div>
            </div>
          </div>

          <div className="mt-5 flex flex-wrap gap-2">
            {categories.map((cat) => {
              const active = category === cat;
              return (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategory(cat)}
                  className={`rounded-full px-4 py-1.5 text-xs font-bold transition-colors ${
                    active
                      ? 'text-white shadow-sm'
                      : 'border border-stone-200 bg-white text-stone-700 hover:bg-stone-100'
                  }`}
                  style={active ? { backgroundColor: store.primary_color } : undefined}
                >
                  {cat}
                </button>
              );
            })}
          </div>

          {filteredProducts.length === 0 ? (
            <div className="mt-8 rounded-3xl border border-stone-200 bg-white p-12 text-center">
              <ShoppingBag className="mx-auto h-10 w-10 text-stone-300" />
              <p className="mt-3 font-serif text-lg font-bold text-stone-800">
                No items match this country or filter
              </p>
              <button
                type="button"
                onClick={() => {
                  setCountryFilter('ALL');
                  setCategory('All');
                  setSearch('');
                }}
                className="mt-4 rounded-full bg-stone-900 px-5 py-2 text-xs font-bold text-white"
              >
                Reset Filters
              </button>
            </div>
          ) : (
            <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {filteredProducts.map((product) => {
                const savePct = calcSavingsPct(product.price_display, product.original_price);
                return (
                  <article
                    key={product.id}
                    className="group flex flex-col overflow-hidden rounded-3xl border border-stone-200 bg-white shadow-sm hover:shadow-xl transition-all duration-300"
                  >
                    <div
                      onClick={() => setSelectedProduct(product)}
                      className="relative aspect-[4/3] cursor-pointer overflow-hidden bg-stone-100"
                    >
                      {product.image_url ? (
                        <img
                          src={product.image_url}
                          alt={product.title}
                          className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                      ) : (
                        <div className="flex h-full items-center justify-center text-stone-300">
                          <ShoppingBag className="h-12 w-12" />
                        </div>
                      )}
                      <div className="absolute left-3 top-3 flex flex-wrap gap-1.5">
                        {product.badge && (
                          <span
                            className="rounded-full px-3 py-1 text-[10px] font-bold uppercase tracking-wide text-white shadow"
                            style={{ backgroundColor: store.accent_color }}
                          >
                            {product.badge}
                          </span>
                        )}
                        {savePct && (
                          <span className="rounded-full bg-stone-900/90 px-2.5 py-1 text-[10px] font-bold text-white">
                            Save {savePct}%
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex flex-1 flex-col justify-between p-5">
                      <div>
                        <div className="flex items-center justify-between text-[11px] text-stone-500">
                          <span className="inline-flex items-center gap-1 font-semibold">
                            <Tag className="h-3 w-3" /> {product.category}
                          </span>
                          <span>via {product.merchant_name}</span>
                        </div>
                        <h3
                          onClick={() => setSelectedProduct(product)}
                          className="mt-2 cursor-pointer font-serif text-lg font-bold text-stone-900 leading-snug group-hover:underline"
                        >
                          {product.title}
                        </h3>
                        <p className="mt-2 text-xs leading-relaxed text-stone-500 line-clamp-2">
                          {product.short_description || product.description}
                        </p>

                        <div className="mt-3 flex flex-wrap items-center gap-1">
                          <Globe className="h-3 w-3 text-stone-400" />
                          {(product.available_countries || ['US']).map((code) => (
                            <span
                              key={code}
                              className="rounded-full bg-stone-100 px-2 py-0.5 text-[10px] font-semibold text-stone-700"
                            >
                              {formatCountryLabel(code)}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="mt-5 border-t border-stone-100 pt-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-baseline gap-2">
                            <span
                              className="font-display text-xl font-extrabold"
                              style={{ color: store.primary_color }}
                            >
                              {product.price_display}
                            </span>
                            {product.original_price && (
                              <span className="text-xs text-stone-400 line-through">
                                {product.original_price}
                              </span>
                            )}
                          </div>
                          <button
                            type="button"
                            onClick={() => setSelectedProduct(product)}
                            className="text-xs font-semibold text-stone-500 underline hover:text-stone-900"
                          >
                            Details
                          </button>
                        </div>

                        <a
                          href={goHref(product.id)}
                          target="_blank"
                          rel="noopener noreferrer sponsored"
                          className="w-full inline-flex items-center justify-center gap-2 rounded-full py-3 text-xs font-bold text-white shadow-sm hover:opacity-90"
                          style={{ backgroundColor: store.primary_color }}
                        >
                          Shop on {product.merchant_name || 'Merchant'}
                          <ExternalLink className="h-3.5 w-3.5" />
                        </a>
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </section>

        {/* EDITORIAL BUYING JOURNAL */}
        {posts.length > 0 && (
          <section id="journal">
            <div className="mb-6">
              <p
                className="text-xs font-bold uppercase tracking-widest"
                style={{ color: store.primary_color }}
              >
                The Journal
              </p>
              <h2 className="mt-1 font-serif text-3xl font-bold text-stone-900">
                Buying Guides & Stories
              </h2>
            </div>
            <div className="grid gap-6 md:grid-cols-2">
              {posts.map((post) => (
                <Link
                  key={post.id}
                  href={`/s/${store.slug}/blog/${post.slug}`}
                  className="group overflow-hidden rounded-3xl border border-stone-200 bg-white shadow-sm hover:shadow-md transition-all flex flex-col"
                >
                  {post.cover_image && (
                    <div className="h-52 overflow-hidden bg-stone-100">
                      <img
                        src={post.cover_image}
                        alt={post.title}
                        className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    </div>
                  )}
                  <div className="p-6 flex-1 flex flex-col justify-between">
                    <div>
                      <span
                        className="text-[11px] font-bold uppercase tracking-wider"
                        style={{ color: store.primary_color }}
                      >
                        {post.category}
                      </span>
                      <h3 className="mt-2 font-serif text-xl font-bold text-stone-900 group-hover:underline">
                        {post.title}
                      </h3>
                      <p className="mt-2 text-xs leading-relaxed text-stone-600">{post.excerpt}</p>
                    </div>
                    <span
                      className="mt-4 inline-flex items-center gap-1.5 text-xs font-bold"
                      style={{ color: store.primary_color }}
                    >
                      Read Full Story <ArrowRight className="h-3.5 w-3.5" />
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}
      </main>

      {/* WARM EDITORIAL FOOTER */}
      <footer id="disclosure" className="mt-16 border-t border-stone-800 bg-stone-950 text-stone-300">
        <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8 space-y-6">
          <div className="grid gap-8 md:grid-cols-3">
            <div className="md:col-span-2">
              <p className="font-serif text-xl font-bold text-white">{store.name}</p>
              <p className="mt-2 text-xs leading-relaxed text-stone-400">{store.disclosure_text}</p>
            </div>
            <div className="space-y-2 text-xs">
              {store.contact_email && (
                <p className="flex items-center gap-2">
                  <Mail className="h-4 w-4" />
                  <a href={`mailto:${store.contact_email}`} className="hover:underline">
                    {store.contact_email}
                  </a>
                </p>
              )}
              <div className="flex flex-wrap gap-3 pt-2">
                {store.social_tiktok && <a href={store.social_tiktok} target="_blank" rel="noreferrer" className="underline">TikTok</a>}
                {store.social_instagram && <a href={store.social_instagram} target="_blank" rel="noreferrer" className="underline">Instagram</a>}
                {store.social_youtube && <a href={store.social_youtube} target="_blank" rel="noreferrer" className="underline">YouTube</a>}
                {store.social_facebook && <a href={store.social_facebook} target="_blank" rel="noreferrer" className="underline">Facebook</a>}
              </div>
            </div>
          </div>

          <div className="border-t border-white/10 pt-6 flex flex-wrap items-center justify-between gap-4 text-xs">
            <p className="text-stone-500">© {new Date().getFullYear()} {store.name}.</p>
            <Link
              href="/"
              className="inline-flex items-center gap-1.5 rounded-full bg-white/10 px-4 py-1.5 font-semibold text-white hover:bg-white/20"
            >
              <Sparkles className="h-3.5 w-3.5 text-amber-300" />
              Powered by {platformName}
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
