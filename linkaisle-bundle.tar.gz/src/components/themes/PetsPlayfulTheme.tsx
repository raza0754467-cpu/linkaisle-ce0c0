'use client';

import Link from 'next/link';
import {
  ArrowRight,
  CheckCircle2,
  ExternalLink,
  Globe,
  Mail,
  Search,
  ShoppingBag,
  Smile,
  Sparkles,
  Star,
} from 'lucide-react';
import { COUNTRY_OPTIONS, formatCountryLabel } from '@/lib/types';
import { StorefrontThemeProps, calcSavingsPct } from './types';

export default function PetsPlayfulTheme({
  store,
  products,
  filteredProducts,
  featuredProducts,
  posts,
  platformName,
  categories,
  category,
  setCategory,
  countryFilter,
  setCountryFilter,
  search,
  setSearch,
  setSelectedProduct,
  goHref,
}: StorefrontThemeProps) {
  const stackCards = (featuredProducts.length ? featuredProducts : products).slice(0, 2);

  return (
    <div className="min-h-screen bg-[#f4fbfa] text-slate-900">
      {/* VIBRANT TOP RIBBON */}
      <div
        className="px-4 py-2 text-center text-xs font-extrabold text-white"
        style={{ backgroundColor: store.primary_color }}
      >
        ✨ Handpicked Daily Favorites · Region: {formatCountryLabel(store.target_country || 'US')} ({store.currency || 'USD'}) ✨
      </div>

      {/* PLAYFUL PILL HEADER */}
      <header className="sticky top-0 z-30 border-b-2 border-teal-100 bg-white/95 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3.5 sm:px-6 lg:px-8">
          <Link href={`/s/${store.slug}`} className="flex items-center gap-3">
            {store.logo_url ? (
              <img src={store.logo_url} alt={store.name} className="h-10 w-10 rounded-2xl object-cover border-2 border-teal-200" />
            ) : (
              <div
                className="flex h-10 w-10 items-center justify-center rounded-2xl text-white font-display text-lg font-extrabold shadow-md"
                style={{ backgroundColor: store.primary_color }}
              >
                <Smile className="h-5 w-5" />
              </div>
            )}
            <div>
              <p className="font-display text-lg font-extrabold text-slate-900 leading-none">
                {store.name}
              </p>
              <p className="mt-0.5 text-[11px] font-semibold text-teal-700 hidden sm:block">
                {store.tagline}
              </p>
            </div>
          </Link>

          <nav className="flex items-center gap-2 sm:gap-3 text-xs font-bold">
            <a href="#shop" className="rounded-full bg-teal-50 px-4 py-2 text-teal-800 hover:bg-teal-100">
              Shop ({products.length})
            </a>
            {posts.length > 0 && (
              <a href="#tips" className="rounded-full bg-amber-50 px-4 py-2 text-amber-800 hover:bg-amber-100">
                Tips & Guides
              </a>
            )}
          </nav>
        </div>
      </header>

      {/* VIBRANT ASYMMETRIC BUBBLE HERO (SHOPIFY CRAVE STYLE) */}
      <section className="relative overflow-hidden bg-gradient-to-br from-teal-50 via-emerald-50/60 to-amber-50/70 border-b-2 border-teal-100">
        <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8 lg:py-16">
          <div className="grid items-center gap-10 lg:grid-cols-12">
            <div className="lg:col-span-6">
              <span
                className="inline-flex items-center gap-1.5 rounded-full px-4 py-1.5 text-xs font-extrabold text-white shadow"
                style={{ backgroundColor: store.accent_color }}
              >
                <Star className="h-3.5 w-3.5 fill-white" />
                Loved By Everyday Shoppers
              </span>
              <h1 className="mt-4 font-display text-4xl font-extrabold tracking-tight text-slate-900 sm:text-5xl leading-[1.08]">
                {store.hero_title || store.name}
              </h1>
              <p className="mt-4 text-base leading-relaxed text-slate-600">
                {store.hero_subtitle || store.description}
              </p>

              <div className="mt-7 flex flex-wrap items-center gap-3">
                <a
                  href="#shop"
                  className="inline-flex items-center gap-2 rounded-full px-7 py-3.5 text-sm font-extrabold text-white shadow-lg hover:scale-[1.02] transition-transform"
                  style={{ backgroundColor: store.primary_color }}
                >
                  {store.hero_cta || 'Explore Fun Finds'}
                  <ArrowRight className="h-4 w-4" />
                </a>
                <span className="rounded-full border-2 border-teal-200 bg-white px-4 py-3 text-xs font-bold text-teal-800">
                  🌍 Filter by Your Country Below
                </span>
              </div>
            </div>

            <div className="lg:col-span-6 grid grid-cols-2 gap-4">
              {stackCards.map((card, i) => (
                <div
                  key={card.id}
                  onClick={() => setSelectedProduct(card)}
                  className={`cursor-pointer overflow-hidden rounded-[2rem] border-2 border-white bg-white shadow-xl hover:-translate-y-1 transition-transform ${
                    i === 1 ? 'mt-6' : ''
                  }`}
                >
                  <div className="aspect-square overflow-hidden bg-teal-50">
                    {card.image_url ? (
                      <img src={card.image_url} alt={card.title} className="h-full w-full object-cover" />
                    ) : null}
                  </div>
                  <div className="p-4">
                    <span className="text-[10px] font-extrabold uppercase text-teal-600">
                      {card.category}
                    </span>
                    <p className="mt-1 font-display text-sm font-extrabold text-slate-900 line-clamp-1">
                      {card.title}
                    </p>
                    <p className="mt-1 font-display text-lg font-extrabold" style={{ color: store.primary_color }}>
                      {card.price_display}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <main className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8 space-y-14">
        {/* CATEGORY TILES */}
        <section>
          <div className="flex flex-wrap items-center justify-between gap-4 mb-5">
            <h2 className="font-display text-2xl font-extrabold text-slate-900">
              Shop By Category
            </h2>
            <div className="flex flex-wrap gap-2 w-full sm:w-auto">
              <select
                value={countryFilter}
                onChange={(e) => setCountryFilter(e.target.value)}
                aria-label="Filter by available country"
                className="flex-1 sm:w-48 rounded-full border-2 border-teal-200 bg-white px-4 py-2 text-xs font-bold text-slate-700 focus:outline-none"
              >
                <option value="ALL">All Countries</option>
                {COUNTRY_OPTIONS.map((c) => (
                  <option key={c.code} value={c.code}>
                    Available in: {c.name}
                  </option>
                ))}
              </select>
              <div className="relative flex-1 sm:w-56">
                <Search className="pointer-events-none absolute left-3.5 top-2.5 h-4 w-4 text-teal-500" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Find something awesome..."
                  className="w-full rounded-full border-2 border-teal-200 bg-white py-2 pl-10 pr-4 text-xs font-medium focus:outline-none"
                />
              </div>
            </div>
          </div>

          <div className="flex flex-wrap gap-2.5">
            {categories.map((cat) => {
              const active = category === cat;
              return (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategory(cat)}
                  className={`rounded-full px-5 py-2 text-xs font-extrabold transition-all ${
                    active
                      ? 'text-white shadow-md scale-105'
                      : 'border-2 border-teal-100 bg-white text-slate-700 hover:border-teal-300'
                  }`}
                  style={active ? { backgroundColor: store.primary_color } : undefined}
                >
                  {cat}
                </button>
              );
            })}
          </div>
        </section>

        {/* PLAYFUL ROUNDED-3XL PRODUCT CARDS */}
        <section id="shop">
          {filteredProducts.length === 0 ? (
            <div className="rounded-3xl border-2 border-dashed border-teal-200 bg-white p-12 text-center">
              <ShoppingBag className="mx-auto h-10 w-10 text-teal-300" />
              <p className="mt-3 font-display font-bold text-slate-700">
                No deals match this country or search yet!
              </p>
            </div>
          ) : (
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {filteredProducts.map((product) => {
                const savePct = calcSavingsPct(product.price_display, product.original_price);
                return (
                  <article
                    key={product.id}
                    className="group flex flex-col overflow-hidden rounded-[2rem] border-2 border-teal-100 bg-white shadow-sm hover:border-teal-300 hover:shadow-xl transition-all"
                  >
                    <div
                      onClick={() => setSelectedProduct(product)}
                      className="relative h-56 cursor-pointer overflow-hidden bg-teal-50/50"
                    >
                      {product.image_url ? (
                        <img
                          src={product.image_url}
                          alt={product.title}
                          className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      ) : null}
                      <div className="absolute left-3 top-3 flex gap-1.5">
                        {product.badge && (
                          <span
                            className="rounded-full px-3 py-1 text-[11px] font-extrabold text-white shadow"
                            style={{ backgroundColor: store.accent_color }}
                          >
                            {product.badge}
                          </span>
                        )}
                        {savePct && (
                          <span className="rounded-full bg-rose-500 px-2.5 py-1 text-[11px] font-extrabold text-white">
                            {savePct}% OFF
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex flex-1 flex-col justify-between p-5">
                      <div>
                        <span className="inline-block rounded-full bg-teal-50 px-3 py-0.5 text-[11px] font-extrabold text-teal-700">
                          {product.category}
                        </span>
                        <h3
                          onClick={() => setSelectedProduct(product)}
                          className="mt-2 cursor-pointer font-display text-lg font-extrabold text-slate-900 leading-snug group-hover:text-teal-700"
                        >
                          {product.title}
                        </h3>
                        <p className="mt-1.5 text-xs text-slate-600 line-clamp-2">
                          {product.short_description || product.description}
                        </p>

                        {product.benefits?.length > 0 && (
                          <ul className="mt-3 space-y-1">
                            {product.benefits.slice(0, 2).map((b, i) => (
                              <li key={i} className="flex items-center gap-1.5 text-xs text-slate-700">
                                <CheckCircle2 className="h-3.5 w-3.5 shrink-0" style={{ color: store.primary_color }} />
                                <span className="truncate">{b}</span>
                              </li>
                            ))}
                          </ul>
                        )}

                        <div className="mt-3 flex flex-wrap items-center gap-1">
                          <Globe className="h-3 w-3 text-teal-500" />
                          {(product.available_countries || ['US']).map((code) => (
                            <span
                              key={code}
                              className="rounded-full bg-amber-50 border border-amber-200 px-2 py-0.5 text-[10px] font-bold text-amber-900"
                            >
                              {formatCountryLabel(code)}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="mt-5 border-t-2 border-teal-50 pt-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-baseline gap-2">
                            <span
                              className="font-display text-2xl font-extrabold"
                              style={{ color: store.primary_color }}
                            >
                              {product.price_display}
                            </span>
                            {product.original_price && (
                              <span className="text-xs text-slate-400 line-through">
                                {product.original_price}
                              </span>
                            )}
                          </div>
                          <button
                            type="button"
                            onClick={() => setSelectedProduct(product)}
                            className="text-xs font-extrabold text-teal-700 hover:underline"
                          >
                            Quick View
                          </button>
                        </div>

                        <a
                          href={goHref(product.id)}
                          target="_blank"
                          rel="noopener noreferrer sponsored"
                          className="w-full inline-flex items-center justify-center gap-2 rounded-full py-3 text-xs font-extrabold text-white shadow-md hover:opacity-95"
                          style={{ backgroundColor: store.primary_color }}
                        >
                          Grab Deal on {product.merchant_name}
                          <ExternalLink className="h-3.5 w-3.5" />
                        </a>
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </section>

        {/* COMMUNITY TIPS */}
        {posts.length > 0 && (
          <section id="tips">
            <h2 className="font-display text-2xl font-extrabold text-slate-900 mb-6">
              Helpful Tips & Guides
            </h2>
            <div className="grid gap-6 md:grid-cols-2">
              {posts.map((post) => (
                <Link
                  key={post.id}
                  href={`/s/${store.slug}/blog/${post.slug}`}
                  className="group overflow-hidden rounded-[2rem] border-2 border-teal-100 bg-white shadow-sm hover:border-teal-300 flex flex-col"
                >
                  {post.cover_image && (
                    <img src={post.cover_image} alt={post.title} className="h-48 w-full object-cover" />
                  )}
                  <div className="p-6">
                    <span className="rounded-full bg-amber-100 px-3 py-0.5 text-[11px] font-extrabold text-amber-900">
                      {post.category}
                    </span>
                    <h3 className="mt-2 font-display text-lg font-extrabold text-slate-900 group-hover:text-teal-700">
                      {post.title}
                    </h3>
                    <p className="mt-2 text-xs text-slate-600">{post.excerpt}</p>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}
      </main>

      <footer className="mt-16 bg-teal-950 text-teal-100">
        <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8 space-y-5">
          <div className="grid gap-6 md:grid-cols-3">
            <div className="md:col-span-2">
              <p className="font-display text-xl font-extrabold text-white">{store.name}</p>
              <p className="mt-2 text-xs text-teal-200/80 leading-relaxed">{store.disclosure_text}</p>
            </div>
            <div className="text-xs">
              {store.contact_email && (
                <p className="flex items-center gap-2">
                  <Mail className="h-4 w-4 text-amber-300" /> {store.contact_email}
                </p>
              )}
            </div>
          </div>
          <div className="border-t border-white/10 pt-5 flex flex-wrap justify-between gap-3 text-xs">
            <p>© {new Date().getFullYear()} {store.name}</p>
            <Link href="/" className="inline-flex items-center gap-1.5 rounded-full bg-white/10 px-3.5 py-1 font-bold text-white">
              <Sparkles className="h-3.5 w-3.5 text-amber-300" /> Powered by {platformName}
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
