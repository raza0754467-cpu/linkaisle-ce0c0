'use client';

import { useMemo, useState } from 'react';
import Link from 'next/link';
import {
  ArrowRight,
  BookOpen,
  CheckCircle2,
  ExternalLink,
  Globe,
  LayoutDashboard,
  Rocket,
  Search,
  ShoppingBag,
  Store as StoreIcon,
  Wrench,
} from 'lucide-react';
import { COUNTRY_OPTIONS, formatCountryLabel } from '@/lib/types';

export interface HomepageProduct {
  id: string;
  slug: string;
  title: string;
  category: string;
  price_display: string;
  original_price: string;
  image_url: string;
  short_description: string;
  merchant_name: string;
  badge: string;
  available_countries: string[];
  store_name: string;
  store_slug: string;
}

export function SimpleWorkflowSection({ isLoggedIn }: { isLoggedIn: boolean }) {
  const steps = [
    {
      num: '01',
      icon: BookOpen,
      title: 'Learn How Affiliate Links Work',
      desc: 'Start with short, plain-language lessons explaining how affiliate commissions, tracking tags, and curated stores work.',
      cta: 'Open Academy',
      href: '/academy',
    },
    {
      num: '02',
      icon: Wrench,
      title: 'Get Your Free Affiliate Links',
      desc: 'Join free affiliate networks like Amazon Associates or Impact.com and copy your official product tracking links.',
      cta: 'Browse Affiliate Networks',
      href: '/tools',
    },
    {
      num: '03',
      icon: Rocket,
      title: 'Publish Your Free LinkAisle Store',
      desc: 'Sign up, choose a storefront theme, add products & deliverable countries — your store launches instantly on LinkAisle. No domain or hosting needed.',
      cta: isLoggedIn ? 'Open My Studio' : 'Create Free Store',
      href: isLoggedIn ? '/dashboard' : '/register',
    },
    {
      num: '04',
      icon: LayoutDashboard,
      title: 'Share & Track Your Store',
      desc: 'Share one store link across TikTok, Instagram Reels, YouTube, or Facebook using built-in AI scripts and monitor visits & clicks from your dashboard.',
      cta: 'See Example Store',
      href: '/s/smart-home-finds',
    },
  ];

  return (
    <section id="how-it-works" className="border-y border-stone-200 bg-white py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl">
          <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#047857]">
            Simple 4-Step Workflow
          </p>
          <h2 className="mt-2.5 font-display text-3xl font-extrabold tracking-tight text-[#111315] sm:text-4xl">
            From Zero to Your Own Store in 4 Steps
          </h2>
          <p className="mt-2.5 text-sm leading-relaxed text-stone-600">
            Every step connects directly to where you need to go — no domain purchase, no hosting setup, no coding.
          </p>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {steps.map((s) => {
            const Icon = s.icon;
            return (
              <div
                key={s.num}
                className="group flex flex-col justify-between rounded-2xl border border-stone-200 bg-[#FAFAF9] p-6 hover:border-[#047857]/40 hover:bg-white hover:shadow-soft transition-all"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50 text-[#047857] border border-emerald-100">
                      <Icon className="h-5 w-5" />
                    </div>
                    <span className="font-mono text-sm font-bold text-stone-400">
                      STEP {s.num}
                    </span>
                  </div>

                  <h3 className="mt-5 font-display text-lg font-bold text-[#111315] leading-snug">
                    {s.title}
                  </h3>
                  <p className="mt-2.5 text-sm leading-relaxed text-stone-600">{s.desc}</p>
                </div>

                <Link
                  href={s.href}
                  className="mt-6 inline-flex items-center justify-between rounded-xl border border-stone-200 bg-white px-4 py-2.5 text-xs font-bold text-[#111315] group-hover:border-[#047857] group-hover:bg-[#047857] group-hover:text-white transition-colors"
                >
                  <span>{s.cta}</span>
                  <ArrowRight className="h-3.5 w-3.5 shrink-0" />
                </Link>
              </div>
            );
          })}
        </div>

        <div className="mt-10 flex flex-wrap items-center justify-center gap-x-8 gap-y-2 text-xs font-medium text-stone-500">
          <span className="inline-flex items-center gap-1.5">
            <CheckCircle2 className="h-4 w-4 text-[#047857]" />
            Free to Start
          </span>
          <span className="inline-flex items-center gap-1.5">
            <CheckCircle2 className="h-4 w-4 text-[#047857]" />
            Free Store Link Included
          </span>
          <span className="inline-flex items-center gap-1.5">
            <CheckCircle2 className="h-4 w-4 text-[#047857]" />
            Multi-Country Product Filter
          </span>
        </div>
      </div>
    </section>
  );
}

export function FeaturedProductsSection({ products }: { products: HomepageProduct[] }) {
  const [category, setCategory] = useState('All');
  const [country, setCountry] = useState('ALL');
  const [query, setQuery] = useState('');

  const categories = useMemo(() => {
    const s = new Set<string>();
    products.forEach((p) => {
      if (p.category) s.add(p.category);
    });
    return ['All', ...Array.from(s)];
  }, [products]);

  const filtered = useMemo(() => {
    return products.filter((p) => {
      const catOk = category === 'All' || p.category === category;
      const countries = p.available_countries || ['US'];
      const countryOk = country === 'ALL' || countries.includes('GLOBAL') || countries.includes(country);
      const q = query.trim().toLowerCase();
      const qOk =
        !q ||
        p.title.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.merchant_name.toLowerCase().includes(q) ||
        p.store_name.toLowerCase().includes(q);
      return catOk && countryOk && qOk;
    });
  }, [products, category, country, query]);

  return (
    <section id="products" className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
      <div className="flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#047857]">
            Curated Picks
          </p>
          <h2 className="mt-2 font-display text-3xl font-extrabold tracking-tight text-[#111315] sm:text-4xl">
            Featured Products
          </h2>
          <p className="mt-2 max-w-xl text-sm text-stone-600">
            Browse curated finds from LinkAisle stores and filter by country to see what ships to your region.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <div className="relative flex-1 sm:w-48">
            <Globe className="pointer-events-none absolute left-3.5 top-2.5 h-4 w-4 text-stone-400" />
            <select
              value={country}
              onChange={(e) => setCountry(e.target.value)}
              aria-label="Filter products by country"
              className="w-full rounded-full border border-stone-300 bg-white py-2 pl-9 pr-4 text-xs font-semibold text-stone-800 focus:border-[#047857] focus:outline-none"
            >
              <option value="ALL">All Countries</option>
              {COUNTRY_OPTIONS.map((c) => (
                <option key={c.code} value={c.code}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
          <div className="relative flex-1 sm:w-56">
            <Search className="pointer-events-none absolute left-3.5 top-2.5 h-4 w-4 text-stone-400" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search products..."
              className="w-full rounded-full border border-stone-300 bg-white py-2 pl-9 pr-4 text-xs text-stone-900 focus:border-[#047857] focus:outline-none"
            />
          </div>
        </div>
      </div>

      {/* CATEGORY PILLS */}
      <div className="mt-6 flex flex-wrap gap-2">
        {categories.map((cat) => (
          <button
            key={cat}
            type="button"
            onClick={() => setCategory(cat)}
            className={`rounded-full px-4 py-1.5 text-xs font-bold transition-colors ${
              category === cat
                ? 'bg-[#111315] text-white'
                : 'border border-stone-200 bg-white text-stone-600 hover:border-stone-400 hover:text-stone-900'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="mt-8 rounded-2xl border border-stone-200 bg-white p-12 text-center text-sm text-stone-500">
          No products match this country or search filter.
        </div>
      ) : (
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {filtered.slice(0, 8).map((p) => (
            <article
              key={p.id}
              className="group flex flex-col overflow-hidden rounded-2xl border border-stone-200/90 bg-white shadow-sm hover:shadow-lg hover:border-stone-300 transition-all duration-300"
            >
              <div className="relative aspect-[4/3] overflow-hidden bg-stone-100">
                <Link
                  href={`/s/${p.store_slug}/p/${p.slug}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block h-full w-full"
                >
                  {p.image_url ? (
                    <img
                      src={p.image_url}
                      alt={p.title}
                      className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  ) : (
                    <div className="flex h-full items-center justify-center text-stone-300">
                      <ShoppingBag className="h-10 w-10" />
                    </div>
                  )}
                </Link>
                {p.badge && (
                  <span className="absolute left-2.5 top-2.5 rounded-full bg-[#111315]/85 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-white backdrop-blur">
                    {p.badge}
                  </span>
                )}
                <Link
                  href={`/s/${p.store_slug}`}
                  className="absolute right-2.5 bottom-2.5 inline-flex items-center gap-1 rounded-full bg-white/95 px-2.5 py-0.5 text-[10px] font-bold text-stone-800 shadow hover:bg-[#047857] hover:text-white transition-colors"
                >
                  <StoreIcon className="h-3 w-3" />
                  {p.store_name}
                </Link>
              </div>

              <div className="flex flex-1 flex-col justify-between p-4">
                <div>
                  <div className="flex items-center justify-between text-[10px] font-semibold text-stone-500">
                    <span className="text-[#047857]">{p.category}</span>
                    <span>{p.merchant_name}</span>
                  </div>
                  <Link
                    href={`/s/${p.store_slug}/p/${p.slug}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-1.5 block font-display text-sm font-bold text-[#111315] leading-snug line-clamp-2 hover:text-[#047857] transition-colors"
                  >
                    {p.title}
                  </Link>
                  <p className="mt-1.5 text-xs leading-relaxed text-stone-500 line-clamp-2">
                    {p.short_description}
                  </p>

                  <div className="mt-2.5 flex flex-wrap items-center gap-1">
                    <Globe className="h-3 w-3 text-stone-400" />
                    {(p.available_countries || ['US']).slice(0, 3).map((code) => (
                      <span
                        key={code}
                        className="rounded-md bg-stone-100 px-1.5 py-0.5 text-[10px] font-semibold text-stone-700"
                      >
                        {formatCountryLabel(code)}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="mt-4 flex items-center justify-between border-t border-stone-100 pt-3">
                  <div className="flex items-baseline gap-1.5">
                    <span className="font-display text-lg font-extrabold text-[#111315]">
                      {p.price_display}
                    </span>
                    {p.original_price && (
                      <span className="text-[11px] text-stone-400 line-through">{p.original_price}</span>
                    )}
                  </div>
                  <a
                    href={`/api/go/${p.id}`}
                    target="_blank"
                    rel="noopener noreferrer sponsored"
                    className="inline-flex items-center gap-1 rounded-full bg-[#047857] px-3.5 py-1.5 text-xs font-bold text-white hover:bg-[#065f46] transition-colors"
                  >
                    View Deal
                    <ExternalLink className="h-3 w-3" />
                  </a>
                </div>
              </div>
            </article>
          ))}
        </div>
      )}
    </section>
  );
}
