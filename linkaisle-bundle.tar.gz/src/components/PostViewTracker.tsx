'use client';

import { useEffect, useRef } from 'react';

export default function PostViewTracker({
  storeId,
  postId,
}: {
  storeId: string;
  postId: string;
}) {
  const sent = useRef(false);

  useEffect(() => {
    if (sent.current) return;
    sent.current = true;

    const params = new URLSearchParams(window.location.search);
    fetch('/api/track', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        eventType: 'post_view',
        storeId,
        postId,
        referrer: document.referrer || '',
        utmSource: params.get('utm_source') || params.get('src') || '',
      }),
    }).catch(() => {});
  }, [storeId, postId]);

  return null;
}
