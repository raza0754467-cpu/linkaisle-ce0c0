'use client';

import { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  BarChart3,
  BookOpen,
  Check,
  Copy,
  CopyPlus,
  CreditCard,
  Download,
  Edit3,
  ExternalLink,
  Eye,
  FileSpreadsheet,
  FileText,
  Globe,
  LayoutDashboard,
  LogOut,
  Megaphone,
  MousePointerClick,
  Palette,
  Plus,
  RefreshCw,
  Save,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  Trash2,
  TrendingUp,
  Upload,
  Wrench,
  X,
} from 'lucide-react';
import { BlogPost, COUNTRY_OPTIONS, Product, STORE_TEMPLATES, Store, User, formatCountryLabel } from '@/lib/types';
import MarketingKitTab from './MarketingKitTab';
import BillingTab from './BillingTab';

type Tab = 'overview' | 'builder' | 'products' | 'blog' | 'marketing' | 'analytics' | 'billing';

interface StoreAnalyticsResponse {
  summary: {
    storeVisits: number;
    uniqueVisitors: number;
    productImpressions: number;
    productClicks: number;
    postViews: number;
    ctr: number;
  };
  dailyTrend: { day: string; label: string; visits: number; impressions: number; clicks: number }[];
  referrers: { source: string; count: number }[];
  countries?: { country: string; count: number }[];
  topProducts: {
    id: string;
    title: string;
    category: string;
    price_display: string;
    merchant_name: string;
    impressions: number;
    clicks: number;
    status: string;
  }[];
  recentEvents: {
    id: number;
    event_type: string;
    referrer_source: string;
    created_at: string;
    product_title: string | null;
  }[];
}

interface PlanLimit {
  maxStores: number;
  maxProducts: number;
  maxPosts: number;
  label: string;
  price: number;
}

export default function DashboardClient({
  user,
  initialStores,
  planLimit,
  platformName,
}: {
  user: User;
  initialStores: Store[];
  planLimit: PlanLimit;
  platformName: string;
}) {
  const router = useRouter();
  const [stores, setStores] = useState<Store[]>(initialStores);
  const [activeStoreId, setActiveStoreId] = useState<string>(initialStores[0]?.id || '');
  const [tab, setTab] = useState<Tab>('overview');
  const [toast, setToast] = useState<{ type: 'success' | 'error'; msg: string } | null>(null);

  const [products, setProducts] = useState<Product[]>([]);
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [analytics, setAnalytics] = useState<StoreAnalyticsResponse | null>(null);
  const [loadingData, setLoadingData] = useState(false);

  // Create Store Modal
  const [showNewStoreModal, setShowNewStoreModal] = useState(false);
  const [newStoreName, setNewStoreName] = useState('');
  const [newStoreSlug, setNewStoreSlug] = useState('');
  const [newStoreTemplate, setNewStoreTemplate] = useState('kitchen');

  // Store Builder Form State
  const [storeForm, setStoreForm] = useState<Partial<Store>>({});
  const [savingStore, setSavingStore] = useState(false);

  // Product Modal State
  const [showProductModal, setShowProductModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [productForm, setProductForm] = useState({
    title: '',
    category: 'Kitchen',
    price_display: '$29.99',
    original_price: '',
    image_url: '',
    short_description: '',
    description: '',
    benefits: '',
    available_countries: ['US'] as string[],
    affiliate_url: '',
    merchant_name: 'Amazon',
    badge: '',
    is_featured: false,
    status: 'published' as 'draft' | 'published',
  });
  const [productSearch, setProductSearch] = useState('');

  // Blog Modal State
  const [showPostModal, setShowPostModal] = useState(false);
  const [editingPost, setEditingPost] = useState<BlogPost | null>(null);
  const [postForm, setPostForm] = useState({
    title: '',
    category: 'Buyer Guides',
    excerpt: '',
    content: '',
    cover_image: '',
    seo_title: '',
    seo_description: '',
    featured_product_ids: [] as string[],
    status: 'published' as 'draft' | 'published',
  });

  const [copied, setCopied] = useState(false);
  const [uploading, setUploading] = useState(false);

  // Step 2: Bulk CSV Import & AI Price & Deal Reviser
  const [showCsvModal, setShowCsvModal] = useState(false);
  const [csvText, setCsvText] = useState('');
  const [importingCsv, setImportingCsv] = useState(false);
  const [revising, setRevising] = useState(false);
  const [aiWritingProduct, setAiWritingProduct] = useState(false);
  const [aiWritingPost, setAiWritingPost] = useState(false);
  const [reviserResults, setReviserResults] = useState<
    { productId: string; title: string; price_status: string; quality_score: number; note: string }[]
  >([]);
  const [reviserSummary, setReviserSummary] = useState<{ text: string; provider: string } | null>(null);

  const activeStore = stores.find((s) => s.id === activeStoreId) || stores[0] || null;

  const notify = (type: 'success' | 'error', msg: string) => {
    setToast({ type, msg });
    setTimeout(() => setToast(null), 4000);
  };

  const loadStoreData = useCallback(async (storeId: string) => {
    if (!storeId) return;
    setLoadingData(true);
    try {
      const [prodRes, postRes, anaRes] = await Promise.all([
        fetch(`/api/stores/${storeId}/products`),
        fetch(`/api/stores/${storeId}/posts`),
        fetch(`/api/stores/${storeId}/analytics`),
      ]);
      if (prodRes.ok) {
        const d = await prodRes.json();
        setProducts(d.products || []);
      }
      if (postRes.ok) {
        const d = await postRes.json();
        setPosts(d.posts || []);
      }
      if (anaRes.ok) {
        const d = await anaRes.json();
        setAnalytics(d);
      }
    } finally {
      setLoadingData(false);
    }
  }, []);

  useEffect(() => {
    if (activeStore) {
      setStoreForm({ ...activeStore });
      setReviserResults([]);
      loadStoreData(activeStore.id);
    }
  }, [activeStore?.id, loadStoreData]);

  async function handleImageUpload(file: File): Promise<string | null> {
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append('file', file);
      const res = await fetch('/api/upload', { method: 'POST', body: fd });
      const data = await res.json();
      if (!res.ok) {
        notify('error', data.error || 'Image upload failed');
        return null;
      }
      notify('success', 'Image uploaded!');
      return data.url;
    } catch {
      notify('error', 'Upload error');
      return null;
    } finally {
      setUploading(false);
    }
  }

  async function handleCreateStore(e: React.FormEvent) {
    e.preventDefault();
    const res = await fetch('/api/stores', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: newStoreName,
        slug: newStoreSlug || newStoreName,
        template: newStoreTemplate,
      }),
    });
    const data = await res.json();
    if (!res.ok) {
      notify('error', data.error || 'Failed to create store');
      return;
    }
    setStores((prev) => [data.store, ...prev]);
    setActiveStoreId(data.store.id);
    setShowNewStoreModal(false);
    setNewStoreName('');
    setNewStoreSlug('');
    notify('success', `Store "${data.store.name}" launched!`);
  }

  async function handleSaveStore(e: React.FormEvent) {
    e.preventDefault();
    if (!activeStore) return;
    setSavingStore(true);
    try {
      const res = await fetch(`/api/stores/${activeStore.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(storeForm),
      });
      const data = await res.json();
      if (!res.ok) {
        notify('error', data.error || 'Failed to save settings');
        return;
      }
      setStores((prev) => prev.map((s) => (s.id === activeStore.id ? data.store : s)));
      setStoreForm(data.store);
      notify('success', 'Store design & settings saved!');
    } finally {
      setSavingStore(false);
    }
  }

  async function handleDeleteActiveStore() {
    if (
      !activeStore ||
      !confirm(
        `Delete store "${activeStore.name}" and ALL its products & blog posts permanently? This cannot be undone.`
      )
    ) {
      return;
    }
    const res = await fetch(`/api/stores/${activeStore.id}`, { method: 'DELETE' });
    if (res.ok) {
      const remaining = stores.filter((s) => s.id !== activeStore.id);
      setStores(remaining);
      setActiveStoreId(remaining[0]?.id || '');
      notify('success', 'Storefront deleted');
    } else {
      notify('error', 'Failed to delete store');
    }
  }

  function openNewProduct() {
    setEditingProduct(null);
    setProductForm({
      title: '',
      category: 'Kitchen',
      price_display: '$29.99',
      original_price: '',
      image_url: '',
      short_description: '',
      description: '',
      benefits: '',
      available_countries: [activeStore?.target_country || 'US'],
      affiliate_url: '',
      merchant_name: 'Amazon',
      badge: '',
      is_featured: false,
      status: 'published',
    });
    setShowProductModal(true);
  }

  function openEditProduct(p: Product) {
    setEditingProduct(p);
    setProductForm({
      title: p.title,
      category: p.category,
      price_display: p.price_display,
      original_price: p.original_price,
      image_url: p.image_url,
      short_description: p.short_description,
      description: p.description,
      benefits: (p.benefits || []).join('\n'),
      available_countries: p.available_countries?.length ? p.available_countries : ['US'],
      affiliate_url: p.affiliate_url,
      merchant_name: p.merchant_name,
      badge: p.badge,
      is_featured: p.is_featured === 1,
      status: p.status,
    });
    setShowProductModal(true);
  }

  async function handleSaveProduct(e: React.FormEvent) {
    e.preventDefault();
    if (!activeStore) return;

    const url = editingProduct
      ? `/api/stores/${activeStore.id}/products/${editingProduct.id}`
      : `/api/stores/${activeStore.id}/products`;

    const res = await fetch(url, {
      method: editingProduct ? 'PATCH' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(productForm),
    });
    const data = await res.json();
    if (!res.ok) {
      notify('error', data.error || 'Could not save product');
      return;
    }

    if (editingProduct) {
      setProducts((prev) => prev.map((p) => (p.id === editingProduct.id ? data.product : p)));
      notify('success', 'Product updated!');
    } else {
      setProducts((prev) => [data.product, ...prev]);
      notify('success', 'Product added to store!');
    }
    setShowProductModal(false);
  }

  async function handleDeleteProduct(productId: string) {
    if (!activeStore || !confirm('Delete this product permanently?')) return;
    const res = await fetch(`/api/stores/${activeStore.id}/products/${productId}`, {
      method: 'DELETE',
    });
    if (res.ok) {
      setProducts((prev) => prev.filter((p) => p.id !== productId));
      notify('success', 'Product deleted');
    }
  }

  async function handleDuplicateProduct(p: Product) {
    if (!activeStore) return;
    const res = await fetch(`/api/stores/${activeStore.id}/products`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: `${p.title} (Copy)`,
        category: p.category,
        price_display: p.price_display,
        original_price: p.original_price,
        image_url: p.image_url,
        short_description: p.short_description,
        description: p.description,
        benefits: p.benefits || [],
        affiliate_url: p.affiliate_url,
        merchant_name: p.merchant_name,
        badge: p.badge,
        is_featured: false,
        status: 'draft',
      }),
    });
    const data = await res.json();
    if (!res.ok) {
      notify('error', data.error || 'Could not duplicate product');
      return;
    }
    setProducts((prev) => [data.product, ...prev]);
    notify('success', 'Product duplicated as draft!');
  }

  async function handleReviseProducts(productId?: string) {
    if (!activeStore) return;
    setRevising(true);
    try {
      const res = await fetch(`/api/stores/${activeStore.id}/products/revise`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(productId ? { productId } : { mode: 'all' }),
      });
      const data = await res.json();
      if (!res.ok) {
        notify('error', data.error || 'Reviser check failed');
        return;
      }
      setReviserResults(data.results || []);
      setReviserSummary(
        data.aiSummary
          ? { text: data.aiSummary, provider: data.aiProviderLabel || 'AI Engine' }
          : null
      );
      notify(
        'success',
        `AI Reviser (${data.aiProviderLabel || 'AI'}) audited ${data.revisedCount} product(s)!`
      );
      loadStoreData(activeStore.id);
    } finally {
      setRevising(false);
    }
  }

  async function handleAiWriteProduct() {
    if (!productForm.title.trim()) {
      notify('error', 'Enter a product title first so AI can write the copy.');
      return;
    }
    setAiWritingProduct(true);
    try {
      const res = await fetch('/api/ai/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          task: 'product_copy',
          title: productForm.title,
          category: productForm.category,
          merchant_name: productForm.merchant_name,
          price_display: productForm.price_display,
          available_countries: productForm.available_countries,
        }),
      });
      const json = await res.json();
      if (!res.ok) {
        notify('error', json.error || 'AI generation failed');
        return;
      }
      setProductForm((prev) => ({
        ...prev,
        short_description: json.data.short_description || prev.short_description,
        description: json.data.description || prev.description,
        benefits: Array.isArray(json.data.benefits) ? json.data.benefits.join('\n') : prev.benefits,
        badge: prev.badge || json.data.badge || 'Top Pick',
      }));
      notify('success', `Generated with ${json.providerLabel}!`);
    } finally {
      setAiWritingProduct(false);
    }
  }

  async function handleAiWritePost() {
    if (!postForm.title.trim()) {
      notify('error', 'Enter an article title first so AI can draft the guide.');
      return;
    }
    setAiWritingPost(true);
    try {
      const res = await fetch('/api/ai/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          task: 'seo_guide',
          title: postForm.title,
          category: postForm.category,
          store_name: activeStore?.name || 'LinkAisle Store',
          products: products.slice(0, 6).map((p) => ({
            title: p.title,
            price_display: p.price_display,
            merchant_name: p.merchant_name,
          })),
        }),
      });
      const json = await res.json();
      if (!res.ok) {
        notify('error', json.error || 'AI draft failed');
        return;
      }
      setPostForm((prev) => ({
        ...prev,
        excerpt: json.data.excerpt || prev.excerpt,
        content: json.data.content || prev.content,
        seo_title: json.data.seo_title || prev.seo_title,
        seo_description: json.data.seo_description || prev.seo_description,
      }));
      notify('success', `SEO guide drafted with ${json.providerLabel}!`);
    } finally {
      setAiWritingPost(false);
    }
  }

  async function handleToggleProductStatus(p: Product) {
    if (!activeStore) return;
    const nextStatus = p.status === 'published' ? 'draft' : 'published';
    const res = await fetch(`/api/stores/${activeStore.id}/products/${p.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: nextStatus }),
    });
    if (res.ok) {
      setProducts((prev) =>
        prev.map((item) => (item.id === p.id ? { ...item, status: nextStatus } : item))
      );
      notify('success', nextStatus === 'published' ? 'Product published live' : 'Moved to draft');
    }
  }

  async function handleBulkCsvImport(e: React.FormEvent) {
    e.preventDefault();
    if (!activeStore || !csvText.trim()) return;
    setImportingCsv(true);
    try {
      const res = await fetch(`/api/stores/${activeStore.id}/products/bulk`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ csv: csvText }),
      });
      const data = await res.json();
      if (!res.ok) {
        notify('error', data.error || 'Bulk import failed');
        return;
      }
      notify('success', `Imported ${data.imported} product(s)! (${data.skipped} skipped)`);
      setShowCsvModal(false);
      setCsvText('');
      loadStoreData(activeStore.id);
    } finally {
      setImportingCsv(false);
    }
  }

  function handleDownloadSampleCsv() {
    const sample = [
      'title,affiliate_url,category,price_display,original_price,merchant_name,badge,short_description,benefits,image_url,is_featured',
      '"Compact Mini Espresso Maker","https://www.amazon.com/dp/B000EXAMPLE?tag=yourid-20","Coffee & Tea","$39.99","$49.99","Amazon","Top Pick","Portable hand-powered espresso brewer for travel or office.","No electricity needed|Works with ground coffee|Easy rinse clean","https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=800&q=80","true"',
      '"Silicone Under-Sink Mat","https://www.amazon.com/dp/B001EXAMPLE?tag=yourid-20","Organization","$21.50","$28.00","Amazon","Useful","Waterproof raised-edge mat that protects kitchen cabinets from leaks.","Waterproof silicone|Holds up to 1 gallon of spills|Wipes clean in seconds","https://images.unsplash.com/photo-1556911220-bff31c812dba?auto=format&fit=crop&w=800&q=80","false"',
    ].join('\n');
    const blob = new Blob([sample], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'linkaisle-products-template.csv';
    a.click();
    URL.revokeObjectURL(url);
  }

  function handleExportCsv() {
    const headers = [
      'title',
      'affiliate_url',
      'category',
      'price_display',
      'original_price',
      'merchant_name',
      'badge',
      'short_description',
      'benefits',
      'image_url',
      'is_featured',
    ];
    const esc = (v: string) => `"${String(v || '').replace(/"/g, '""')}"`;
    const rows = products.map((p) =>
      [
        p.title,
        p.affiliate_url,
        p.category,
        p.price_display,
        p.original_price,
        p.merchant_name,
        p.badge,
        p.short_description,
        (p.benefits || []).join('|'),
        p.image_url,
        p.is_featured ? 'true' : 'false',
      ]
        .map(esc)
        .join(',')
    );
    const csv = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${activeStore?.slug || 'store'}-products.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function openNewPost() {
    setEditingPost(null);
    setPostForm({
      title: '',
      category: 'Buyer Guides',
      excerpt: '',
      content: '## Why This Matters\nWrite helpful, honest buying advice here.\n\n## Top Picks\n- Pick 1: Explain why it solves a real problem\n- Pick 2: Share practical tips before buying',
      cover_image: '',
      seo_title: '',
      seo_description: '',
      featured_product_ids: [],
      status: 'published',
    });
    setShowPostModal(true);
  }

  function openEditPost(post: BlogPost) {
    setEditingPost(post);
    setPostForm({
      title: post.title,
      category: post.category,
      excerpt: post.excerpt,
      content: post.content,
      cover_image: post.cover_image,
      seo_title: post.seo_title,
      seo_description: post.seo_description,
      featured_product_ids: post.featured_product_ids || [],
      status: post.status,
    });
    setShowPostModal(true);
  }

  async function handleSavePost(e: React.FormEvent) {
    e.preventDefault();
    if (!activeStore) return;
    const url = editingPost
      ? `/api/stores/${activeStore.id}/posts/${editingPost.id}`
      : `/api/stores/${activeStore.id}/posts`;

    const res = await fetch(url, {
      method: editingPost ? 'PATCH' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(postForm),
    });
    const data = await res.json();
    if (!res.ok) {
      notify('error', data.error || 'Could not save blog post');
      return;
    }
    if (editingPost) {
      setPosts((prev) => prev.map((p) => (p.id === editingPost.id ? data.post : p)));
      notify('success', 'SEO article updated!');
    } else {
      setPosts((prev) => [data.post, ...prev]);
      notify('success', 'SEO article published!');
    }
    setShowPostModal(false);
  }

  async function handleDeletePost(postId: string) {
    if (!activeStore || !confirm('Delete this article permanently?')) return;
    const res = await fetch(`/api/stores/${activeStore.id}/posts/${postId}`, { method: 'DELETE' });
    if (res.ok) {
      setPosts((prev) => prev.filter((p) => p.id !== postId));
      notify('success', 'Article deleted');
    }
  }

  async function handleLogout() {
    await fetch('/api/auth/logout', { method: 'POST' });
    router.push('/');
    router.refresh();
  }

  const storePublicUrl =
    activeStore && typeof window !== 'undefined'
      ? `${window.location.origin}/s/${activeStore.slug}`
      : activeStore
        ? `/s/${activeStore.slug}`
        : '';

  const filteredProducts = products.filter((p) => {
    const q = productSearch.trim().toLowerCase();
    return (
      !q ||
      p.title.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q) ||
      p.merchant_name.toLowerCase().includes(q)
    );
  });

  const maxDailyVal = Math.max(
    1,
    ...(analytics?.dailyTrend.map((d) => Math.max(d.visits, d.impressions, d.clicks)) || [1])
  );

  return (
    <div className="min-h-screen bg-[#F4F4F2] flex flex-col lg:flex-row text-[#111315]">
      {/* TOAST */}
      {toast && (
        <div
          className={`fixed bottom-5 right-5 z-50 rounded-2xl px-4 py-3 text-sm font-semibold text-white shadow-xl ${
            toast.type === 'success' ? 'bg-[#047857]' : 'bg-rose-600'
          }`}
        >
          {toast.msg}
        </div>
      )}

      {/* SHOPIFY-STYLE CLEAN LIGHT SIDEBAR */}
      <aside className="w-full lg:w-64 shrink-0 border-b lg:border-b-0 lg:border-r border-stone-200 bg-white text-stone-800 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between p-5 border-b border-stone-200/80">
            <Link href="/" className="flex items-center gap-2.5 text-[#111315]">
              <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-[#047857] text-white shadow-sm">
                <ShoppingBag className="h-4 w-4" />
              </div>
              <span className="font-display text-base font-extrabold tracking-tight">{platformName}</span>
            </Link>
            <span className="rounded-full bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 text-[10px] font-bold uppercase text-[#047857]">
              {user.plan}
            </span>
          </div>

          {/* STORE SWITCHER */}
          <div className="p-4 border-b border-stone-200/80 bg-[#FAFAF9]">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-stone-500">
                Active Store ({stores.length}/{planLimit.maxStores})
              </span>
              <button
                type="button"
                onClick={() => setShowNewStoreModal(true)}
                className="inline-flex items-center gap-1 rounded-full bg-white border border-stone-200 px-2.5 py-0.5 text-[11px] font-bold text-[#111315] hover:border-[#047857] hover:text-[#047857] transition-colors"
              >
                <Plus className="h-3 w-3" /> New
              </button>
            </div>
            {stores.length > 0 ? (
              <select
                value={activeStore?.id || ''}
                onChange={(e) => setActiveStoreId(e.target.value)}
                className="w-full rounded-xl border border-stone-300 bg-white px-3 py-2 text-xs font-bold text-[#111315] focus:border-[#047857] focus:outline-none"
              >
                {stores.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} (/s/{s.slug})
                  </option>
                ))}
              </select>
            ) : (
              <button
                type="button"
                onClick={() => setShowNewStoreModal(true)}
                className="w-full rounded-xl bg-[#047857] py-2 text-xs font-bold text-white"
              >
                + Create First Store
              </button>
            )}
          </div>

          {/* NAV TABS */}
          <nav className="p-3 space-y-1">
            {[
              { id: 'overview', label: 'Overview', icon: LayoutDashboard },
              { id: 'products', label: `Products (${products.length})`, icon: ShoppingBag },
              { id: 'builder', label: 'Store Design', icon: Palette },
              { id: 'blog', label: `Buying Guides (${posts.length})`, icon: FileText },
              { id: 'marketing', label: 'Promotion Scripts', icon: Megaphone },
              { id: 'analytics', label: 'Analytics', icon: BarChart3 },
              { id: 'billing', label: 'Plan & Billing', icon: CreditCard },
            ].map((item) => {
              const Icon = item.icon;
              const active = tab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setTab(item.id as Tab)}
                  className={`w-full flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-semibold transition-colors ${
                    active
                      ? 'bg-[#111315] text-white shadow-sm'
                      : 'text-stone-600 hover:bg-stone-100 hover:text-[#111315]'
                  }`}
                >
                  <Icon className={`h-4 w-4 ${active ? 'text-emerald-400' : 'text-stone-400'}`} />
                  {item.label}
                </button>
              );
            })}

            <div className="pt-4 mt-4 border-t border-stone-200 space-y-1">
              <Link
                href="/academy"
                className="flex items-center gap-3 rounded-xl px-3.5 py-2 text-xs font-semibold text-stone-600 hover:bg-stone-100 hover:text-[#111315]"
              >
                <BookOpen className="h-4 w-4 text-[#047857]" />
                Affiliate Academy
              </Link>
              <Link
                href="/tools"
                className="flex items-center gap-3 rounded-xl px-3.5 py-2 text-xs font-semibold text-stone-600 hover:bg-stone-100 hover:text-[#111315]"
              >
                <Wrench className="h-4 w-4 text-stone-500" />
                Affiliate Networks
              </Link>
              {user.role === 'admin' && (
                <Link
                  href="/admin"
                  className="flex items-center gap-3 rounded-xl px-3.5 py-2 text-xs font-bold text-amber-800 bg-amber-50 hover:bg-amber-100"
                >
                  <ShieldCheck className="h-4 w-4 text-amber-600" />
                  Owner Admin Panel
                </Link>
              )}
            </div>
          </nav>
        </div>

        <div className="p-4 border-t border-stone-200 bg-[#FAFAF9] flex items-center justify-between">
          <div className="min-w-0">
            <p className="truncate text-xs font-bold text-[#111315]">{user.name}</p>
            <p className="truncate text-[11px] text-stone-500">{user.email}</p>
          </div>
          <button
            type="button"
            onClick={handleLogout}
            title="Sign out"
            className="rounded-lg p-2 text-stone-500 hover:bg-stone-200/70 hover:text-[#111315]"
          >
            <LogOut className="h-4 w-4" />
          </button>
        </div>
      </aside>

      {/* MAIN CONTENT */}
      <main className="flex-1 min-w-0 p-5 sm:p-8 lg:p-10">
        {!activeStore ? (
          <div className="mx-auto max-w-lg rounded-2xl border border-stone-200 bg-white p-10 text-center shadow-sm">
            <Sparkles className="mx-auto h-10 w-10 text-[#047857]" />
            <h1 className="mt-4 font-display text-2xl font-extrabold text-[#111315]">
              Create Your First Affiliate Storefront
            </h1>
            <p className="mt-2 text-sm text-stone-600">
              Pick a niche template and publish your first multi-product collection in seconds.
            </p>
            <button
              type="button"
              onClick={() => setShowNewStoreModal(true)}
              className="mt-6 inline-flex items-center gap-2 rounded-xl bg-[#111315] px-6 py-3 text-sm font-bold text-white hover:bg-[#047857] transition-colors"
            >
              <Plus className="h-4 w-4" /> Launch Storefront
            </button>
          </div>
        ) : (
          <div className="mx-auto max-w-6xl space-y-6">
            {/* TOP BAR */}
            <div className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-stone-200 bg-white p-5 shadow-sm">
              <div>
                <div className="flex items-center gap-2.5">
                  <h1 className="font-display text-xl font-extrabold text-[#111315] sm:text-2xl">
                    {activeStore.name}
                  </h1>
                  <span
                    className={`rounded-full px-2.5 py-0.5 text-[11px] font-bold ${
                      activeStore.is_suspended
                        ? 'bg-rose-100 text-rose-700'
                        : activeStore.is_published
                          ? 'bg-emerald-50 border border-emerald-200 text-[#047857]'
                          : 'bg-stone-100 text-stone-600'
                    }`}
                  >
                    {activeStore.is_suspended
                      ? 'Suspended'
                      : activeStore.is_published
                        ? 'Published Live'
                        : 'Draft'}
                  </span>
                </div>
                <p className="mt-1 text-xs font-mono text-stone-500">
                  Public URL: /s/{activeStore.slug}
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2.5">
                <button
                  type="button"
                  onClick={() => loadStoreData(activeStore.id)}
                  className="inline-flex items-center gap-1.5 rounded-xl border border-stone-200 bg-white px-3.5 py-2 text-xs font-semibold text-stone-700 hover:bg-stone-50"
                >
                  <RefreshCw className={`h-3.5 w-3.5 ${loadingData ? 'animate-spin' : ''}`} />
                  Refresh Stats
                </button>
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard?.writeText(storePublicUrl);
                    setCopied(true);
                    setTimeout(() => setCopied(false), 2000);
                  }}
                  className="inline-flex items-center gap-1.5 rounded-xl border border-stone-200 bg-white px-3.5 py-2 text-xs font-semibold text-stone-700 hover:bg-stone-50"
                >
                  {copied ? <Check className="h-3.5 w-3.5 text-[#047857]" /> : <Copy className="h-3.5 w-3.5" />}
                  {copied ? 'Copied!' : 'Copy Store Link'}
                </button>
                <Link
                  href={`/s/${activeStore.slug}`}
                  target="_blank"
                  className="inline-flex items-center gap-1.5 rounded-xl bg-[#111315] px-4 py-2 text-xs font-bold text-white shadow-sm hover:bg-[#047857] transition-colors"
                >
                  <Globe className="h-3.5 w-3.5" />
                  Open Live Store
                  <ExternalLink className="h-3.5 w-3.5" />
                </Link>
              </div>
            </div>

            {/* TAB 1: OVERVIEW */}
            {tab === 'overview' && (
              <div className="space-y-6">
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
                  {[
                    {
                      label: 'Real Store Visits',
                      val: analytics?.summary.storeVisits ?? 0,
                      icon: Globe,
                      color: 'text-indigo-600 bg-indigo-50',
                    },
                    {
                      label: 'Unique Visitors',
                      val: analytics?.summary.uniqueVisitors ?? 0,
                      icon: Eye,
                      color: 'text-violet-600 bg-violet-50',
                    },
                    {
                      label: 'Product Impressions',
                      val: analytics?.summary.productImpressions ?? 0,
                      icon: TrendingUp,
                      color: 'text-amber-600 bg-amber-50',
                    },
                    {
                      label: 'Affiliate Clicks',
                      val: analytics?.summary.productClicks ?? 0,
                      icon: MousePointerClick,
                      color: 'text-emerald-600 bg-emerald-50',
                    },
                    {
                      label: 'Outbound CTR',
                      val: `${analytics?.summary.ctr ?? 0}%`,
                      icon: BarChart3,
                      color: 'text-cyan-600 bg-cyan-50',
                    },
                  ].map((kpi) => {
                    const Icon = kpi.icon;
                    return (
                      <div key={kpi.label} className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
                        <div className={`inline-flex h-9 w-9 items-center justify-center rounded-xl ${kpi.color}`}>
                          <Icon className="h-4 w-4" />
                        </div>
                        <p className="mt-3 text-xs font-medium text-slate-500">{kpi.label}</p>
                        <p className="mt-1 font-display text-2xl font-extrabold text-slate-900">
                          {kpi.val}
                        </p>
                      </div>
                    );
                  })}
                </div>

                <div className="grid gap-6 lg:grid-cols-2">
                  <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                    <h2 className="font-display text-base font-bold text-slate-900">
                      Quick Launch Actions
                    </h2>
                    <p className="mt-1 text-xs text-slate-500">
                      Add products, test your live store link, and watch real impressions & clicks update immediately.
                    </p>
                    <div className="mt-5 grid gap-3 sm:grid-cols-2">
                      <button
                        type="button"
                        onClick={() => {
                          setTab('products');
                          openNewProduct();
                        }}
                        className="flex items-center gap-3 rounded-xl border border-emerald-200 bg-emerald-50/70 p-4 text-left hover:bg-emerald-100/70 transition-colors"
                      >
                        <Plus className="h-5 w-5 text-[#047857] shrink-0" />
                        <div>
                          <p className="text-sm font-bold text-[#111315]">Add Affiliate Product</p>
                          <p className="text-xs text-stone-600">Upload photo + tracking link</p>
                        </div>
                      </button>
                      <button
                        type="button"
                        onClick={() => setTab('builder')}
                        className="flex items-center gap-3 rounded-xl border border-slate-200 bg-slate-50 p-4 text-left hover:bg-slate-100 transition-colors"
                      >
                        <Palette className="h-5 w-5 text-violet-600 shrink-0" />
                        <div>
                          <p className="text-sm font-bold text-slate-900">Customize Template</p>
                          <p className="text-xs text-slate-600">5 themes, colors & logo</p>
                        </div>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setTab('blog');
                          openNewPost();
                        }}
                        className="flex items-center gap-3 rounded-xl border border-slate-200 bg-slate-50 p-4 text-left hover:bg-slate-100 transition-colors"
                      >
                        <FileText className="h-5 w-5 text-amber-600 shrink-0" />
                        <div>
                          <p className="text-sm font-bold text-slate-900">Write SEO Guide</p>
                          <p className="text-xs text-slate-600">Embed store deals inside</p>
                        </div>
                      </button>
                      <button
                        type="button"
                        onClick={() => setTab('analytics')}
                        className="flex items-center gap-3 rounded-xl border border-slate-200 bg-slate-50 p-4 text-left hover:bg-slate-100 transition-colors"
                      >
                        <BarChart3 className="h-5 w-5 text-emerald-600 shrink-0" />
                        <div>
                          <p className="text-sm font-bold text-slate-900">Inspect Live Analytics</p>
                          <p className="text-xs text-slate-600">Real visits, CTR & sources</p>
                        </div>
                      </button>
                    </div>
                  </div>

                  <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                    <h2 className="font-display text-base font-bold text-slate-900">
                      Your Plan Quotas ({planLimit.label})
                    </h2>
                    <p className="mt-1 text-xs text-slate-500">
                      Active limits managed by platform configuration.
                    </p>
                    <div className="mt-5 space-y-4">
                      <div>
                        <div className="flex justify-between text-xs font-semibold mb-1">
                          <span>Stores Created</span>
                          <span>
                            {stores.length} / {planLimit.maxStores}
                          </span>
                        </div>
                        <div className="h-2 rounded-full bg-stone-100 overflow-hidden">
                          <div
                            className="h-full rounded-full bg-[#111315]"
                            style={{
                              width: `${Math.min(100, (stores.length / planLimit.maxStores) * 100)}%`,
                            }}
                          />
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-xs font-semibold mb-1">
                          <span>Products in Active Store</span>
                          <span>
                            {products.length} / {planLimit.maxProducts >= 9999 ? 'Unlimited' : planLimit.maxProducts}
                          </span>
                        </div>
                        <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                          <div
                            className="h-full rounded-full bg-emerald-500"
                            style={{
                              width: `${Math.min(100, (products.length / Math.max(1, planLimit.maxProducts)) * 100)}%`,
                            }}
                          />
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-xs font-semibold mb-1">
                          <span>SEO Blog Articles</span>
                          <span>
                            {posts.length} / {planLimit.maxPosts >= 9999 ? 'Unlimited' : planLimit.maxPosts}
                          </span>
                        </div>
                        <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                          <div
                            className="h-full rounded-full bg-amber-500"
                            style={{
                              width: `${Math.min(100, (posts.length / Math.max(1, planLimit.maxPosts)) * 100)}%`,
                            }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: STORE BUILDER */}
            {tab === 'builder' && (
              <form onSubmit={handleSaveStore} className="space-y-6">
                <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                  <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                    <div>
                      <h2 className="font-display text-lg font-bold text-slate-900 mb-1">
                        1. Choose Custom Shopify-Class Storefront Theme
                      </h2>
                      <p className="text-xs text-slate-500">
                        Each theme has its own bespoke hero layout, card architecture, and typography. Switch anytime with 0 data loss.
                      </p>
                    </div>
                    <Link
                      href={`/s/${activeStore.slug}?preview=${storeForm.template || activeStore.template}`}
                      target="_blank"
                      className="inline-flex items-center gap-1.5 rounded-xl border border-emerald-200 bg-emerald-50 px-3.5 py-2 text-xs font-bold text-[#047857] hover:bg-emerald-100"
                    >
                      <Eye className="h-3.5 w-3.5" />
                      Live Preview Theme
                    </Link>
                  </div>
                  <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
                    {STORE_TEMPLATES.map((tpl) => {
                      const active = storeForm.template === tpl.id;
                      return (
                        <button
                          type="button"
                          key={tpl.id}
                          onClick={() =>
                            setStoreForm((prev) => ({
                              ...prev,
                              template: tpl.id,
                              primary_color: tpl.defaultPrimary,
                              accent_color: tpl.defaultAccent,
                            }))
                          }
                          className={`overflow-hidden rounded-xl border text-left transition-all ${
                            active
                              ? 'border-[#047857] ring-2 ring-emerald-600/20'
                              : 'border-stone-200 hover:border-stone-300'
                          }`}
                        >
                          <div className={`h-16 bg-gradient-to-br ${tpl.previewBg} p-2.5 flex items-end justify-between`}>
                            <span className="rounded bg-white/90 px-2 py-0.5 text-[10px] font-bold text-slate-800">
                              {tpl.badgeText}
                            </span>
                            <span
                              className="h-4 w-4 rounded-full border-2 border-white shadow"
                              style={{ backgroundColor: tpl.defaultPrimary }}
                            />
                          </div>
                          <div className="p-2.5">
                            <p className="text-xs font-bold text-slate-900">{tpl.name}</p>
                            <p className="text-[11px] text-slate-500">{tpl.niche}</p>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-5">
                  <div className="flex flex-wrap items-center justify-between gap-4">
                    <h2 className="font-display text-lg font-bold text-slate-900">
                      2. Branding, Hero & Publishing
                    </h2>
                    <label className="inline-flex items-center gap-2 text-xs font-bold text-slate-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={Boolean(storeForm.is_published)}
                        onChange={(e) =>
                          setStoreForm((prev) => ({ ...prev, is_published: e.target.checked ? 1 : 0 }))
                        }
                        className="h-4 w-4 accent-indigo-600"
                      />
                      Publish Store Publicly
                    </label>
                  </div>

                  <div className="grid gap-4 sm:grid-cols-2">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Store Name</label>
                      <input
                        type="text"
                        required
                        value={storeForm.name || ''}
                        onChange={(e) => setStoreForm((p) => ({ ...p, name: e.target.value }))}
                        className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Public URL Slug (/s/...)
                      </label>
                      <input
                        type="text"
                        required
                        value={storeForm.slug || ''}
                        onChange={(e) => setStoreForm((p) => ({ ...p, slug: e.target.value }))}
                        className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Tagline</label>
                      <input
                        type="text"
                        value={storeForm.tagline || ''}
                        onChange={(e) => setStoreForm((p) => ({ ...p, tagline: e.target.value }))}
                        className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Store Logo (Upload or URL)
                      </label>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={storeForm.logo_url || ''}
                          onChange={(e) => setStoreForm((p) => ({ ...p, logo_url: e.target.value }))}
                          placeholder="/uploads/... or https://..."
                          className="flex-1 rounded-xl border border-slate-300 px-3 py-2 text-sm"
                        />
                        <label className="inline-flex cursor-pointer items-center gap-1.5 rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-xs font-semibold hover:bg-slate-100">
                          <Upload className="h-3.5 w-3.5" />
                          {uploading ? '...' : 'Upload'}
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={async (e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                const url = await handleImageUpload(file);
                                if (url) setStoreForm((p) => ({ ...p, logo_url: url }));
                              }
                            }}
                          />
                        </label>
                      </div>
                    </div>
                  </div>

                  <div className="grid gap-4 sm:grid-cols-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Primary Color</label>
                      <div className="flex items-center gap-2">
                        <input
                          type="color"
                          value={storeForm.primary_color || '#4f46e5'}
                          onChange={(e) => setStoreForm((p) => ({ ...p, primary_color: e.target.value }))}
                          className="h-10 w-12 cursor-pointer rounded border border-slate-300"
                        />
                        <input
                          type="text"
                          value={storeForm.primary_color || ''}
                          onChange={(e) => setStoreForm((p) => ({ ...p, primary_color: e.target.value }))}
                          className="flex-1 rounded-xl border border-slate-300 px-3 py-2 text-xs font-mono"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Accent Badge Color</label>
                      <div className="flex items-center gap-2">
                        <input
                          type="color"
                          value={storeForm.accent_color || '#10b981'}
                          onChange={(e) => setStoreForm((p) => ({ ...p, accent_color: e.target.value }))}
                          className="h-10 w-12 cursor-pointer rounded border border-slate-300"
                        />
                        <input
                          type="text"
                          value={storeForm.accent_color || ''}
                          onChange={(e) => setStoreForm((p) => ({ ...p, accent_color: e.target.value }))}
                          className="flex-1 rounded-xl border border-slate-300 px-3 py-2 text-xs font-mono"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Hero Button Label</label>
                      <input
                        type="text"
                        value={storeForm.hero_cta || ''}
                        onChange={(e) => setStoreForm((p) => ({ ...p, hero_cta: e.target.value }))}
                        className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                      />
                    </div>
                  </div>

                  <div className="grid gap-4 sm:grid-cols-2">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Hero Headline</label>
                      <input
                        type="text"
                        value={storeForm.hero_title || ''}
                        onChange={(e) => setStoreForm((p) => ({ ...p, hero_title: e.target.value }))}
                        className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Contact Email</label>
                      <input
                        type="email"
                        value={storeForm.contact_email || ''}
                        onChange={(e) => setStoreForm((p) => ({ ...p, contact_email: e.target.value }))}
                        className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Primary Target Market (Country)
                      </label>
                      <select
                        value={storeForm.target_country || 'US'}
                        onChange={(e) => {
                          const code = e.target.value;
                          const matched = COUNTRY_OPTIONS.find((c) => c.code === code);
                          setStoreForm((p) => ({
                            ...p,
                            target_country: code,
                            currency: matched?.currency || p.currency || 'USD',
                          }));
                        }}
                        className="w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm"
                      >
                        {COUNTRY_OPTIONS.map((c) => (
                          <option key={c.code} value={c.code}>
                            {c.name} ({c.currency})
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Store Display Currency
                      </label>
                      <select
                        value={storeForm.currency || 'USD'}
                        onChange={(e) => setStoreForm((p) => ({ ...p, currency: e.target.value }))}
                        className="w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm"
                      >
                        <option value="USD">USD ($)</option>
                        <option value="GBP">GBP (£)</option>
                        <option value="EUR">EUR (€)</option>
                        <option value="CAD">CAD (C$)</option>
                        <option value="PKR">PKR (Rs)</option>
                        <option value="AED">AED (د.إ)</option>
                        <option value="SAR">SAR (﷼)</option>
                        <option value="AUD">AUD (A$)</option>
                        <option value="INR">INR (₹)</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Hero Subtitle</label>
                    <textarea
                      rows={2}
                      value={storeForm.hero_subtitle || ''}
                      onChange={(e) => setStoreForm((p) => ({ ...p, hero_subtitle: e.target.value }))}
                      className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Affiliate Disclosure Text (Required for Compliance)
                    </label>
                    <textarea
                      rows={2}
                      value={storeForm.disclosure_text || ''}
                      onChange={(e) => setStoreForm((p) => ({ ...p, disclosure_text: e.target.value }))}
                      className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                    />
                  </div>

                  <div className="grid gap-3 sm:grid-cols-4">
                    <input
                      type="url"
                      placeholder="TikTok Profile URL"
                      value={storeForm.social_tiktok || ''}
                      onChange={(e) => setStoreForm((p) => ({ ...p, social_tiktok: e.target.value }))}
                      className="rounded-xl border border-slate-300 px-3 py-2 text-xs"
                    />
                    <input
                      type="url"
                      placeholder="Instagram URL"
                      value={storeForm.social_instagram || ''}
                      onChange={(e) => setStoreForm((p) => ({ ...p, social_instagram: e.target.value }))}
                      className="rounded-xl border border-slate-300 px-3 py-2 text-xs"
                    />
                    <input
                      type="url"
                      placeholder="YouTube URL"
                      value={storeForm.social_youtube || ''}
                      onChange={(e) => setStoreForm((p) => ({ ...p, social_youtube: e.target.value }))}
                      className="rounded-xl border border-slate-300 px-3 py-2 text-xs"
                    />
                    <input
                      type="url"
                      placeholder="Facebook Page URL"
                      value={storeForm.social_facebook || ''}
                      onChange={(e) => setStoreForm((p) => ({ ...p, social_facebook: e.target.value }))}
                      className="rounded-xl border border-slate-300 px-3 py-2 text-xs"
                    />
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={handleDeleteActiveStore}
                      className="inline-flex items-center gap-1.5 rounded-xl border border-rose-200 bg-rose-50 px-4 py-2.5 text-xs font-bold text-rose-700 hover:bg-rose-100"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                      Delete Storefront
                    </button>
                    <button
                      type="submit"
                      disabled={savingStore}
                      className="inline-flex items-center gap-2 rounded-xl bg-[#111315] px-6 py-3 text-sm font-bold text-white shadow-sm hover:bg-[#047857] transition-colors disabled:opacity-60"
                    >
                      <Save className="h-4 w-4" />
                      {savingStore ? 'Saving...' : 'Save & Update Live Store'}
                    </button>
                  </div>
                </div>
              </form>
            )}

            {/* TAB 3: PRODUCTS CMS + AI PRICE & DEAL REVISER */}
            {tab === 'products' && (
              <div className="space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <input
                    type="text"
                    placeholder="Filter products by title, category, merchant..."
                    value={productSearch}
                    onChange={(e) => setProductSearch(e.target.value)}
                    className="w-full sm:w-72 rounded-xl border border-stone-300 bg-white px-4 py-2.5 text-sm focus:border-[#047857] focus:outline-none"
                  />
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleReviseProducts()}
                      disabled={revising}
                      className="inline-flex items-center gap-1.5 rounded-xl border border-emerald-200 bg-emerald-50 px-3.5 py-2.5 text-xs font-bold text-[#047857] hover:bg-emerald-100 disabled:opacity-60"
                    >
                      <Sparkles className={`h-4 w-4 ${revising ? 'animate-spin' : ''}`} />
                      {revising ? 'Revising Prices & Links...' : 'AI Price & Link Reviser'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowCsvModal(true)}
                      className="inline-flex items-center gap-1.5 rounded-xl border border-stone-200 bg-white px-3.5 py-2.5 text-xs font-bold text-stone-700 hover:bg-stone-50"
                    >
                      <FileSpreadsheet className="h-4 w-4 text-stone-500" />
                      CSV Import
                    </button>
                    <button
                      type="button"
                      onClick={handleExportCsv}
                      className="inline-flex items-center gap-1.5 rounded-xl border border-stone-200 bg-white px-3.5 py-2.5 text-xs font-bold text-stone-700 hover:bg-stone-50"
                    >
                      <Download className="h-4 w-4 text-stone-500" />
                      Export
                    </button>
                    <button
                      type="button"
                      onClick={openNewProduct}
                      className="inline-flex items-center gap-2 rounded-xl bg-[#111315] px-4 py-2.5 text-xs font-bold text-white shadow-sm hover:bg-[#047857] transition-colors"
                    >
                      <Plus className="h-4 w-4" /> Add Product
                    </button>
                  </div>
                </div>

                {reviserResults.length > 0 && (
                  <div className="rounded-2xl border border-emerald-200 bg-white p-4 shadow-sm space-y-3">
                    <div className="flex items-center justify-between">
                      <p className="text-xs font-bold text-[#047857] flex items-center gap-1.5">
                        <Sparkles className="h-4 w-4" />
                        AI Price &amp; Listing Reviser Report ({reviserResults.length} audited)
                        {reviserSummary?.provider && (
                          <span className="ml-1 rounded-full bg-emerald-50 border border-emerald-200 px-2 py-0.5 text-[10px] font-bold text-[#047857]">
                            {reviserSummary.provider}
                          </span>
                        )}
                      </p>
                      <button
                        type="button"
                        onClick={() => {
                          setReviserResults([]);
                          setReviserSummary(null);
                        }}
                        className="text-xs text-stone-400 hover:text-stone-700"
                      >
                        Dismiss
                      </button>
                    </div>
                    {reviserSummary?.text && (
                      <div className="rounded-xl bg-emerald-50/70 border border-emerald-200/80 px-3.5 py-2.5 text-xs leading-relaxed text-emerald-950">
                        <strong className="font-bold">AI Advisor:</strong> {reviserSummary.text}
                      </div>
                    )}
                    <div className="grid gap-2 max-h-40 overflow-y-auto pr-1">
                      {reviserResults.map((r) => (
                        <div
                          key={r.productId}
                          className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-[#FAFAF9] border border-stone-200/70 px-3 py-2 text-xs"
                        >
                          <div className="min-w-0">
                            <span className="font-bold text-[#111315]">{r.title}</span>
                            <p className="text-[11px] text-stone-600">{r.note}</p>
                          </div>
                          <span className="rounded-full bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 font-mono text-[11px] font-bold text-[#047857]">
                            Score {r.quality_score}/100
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="overflow-hidden rounded-2xl border border-stone-200 bg-white shadow-sm">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm">
                      <thead className="border-b border-stone-200 bg-[#FAFAF9] text-[11px] font-bold uppercase tracking-wider text-stone-500">
                        <tr>
                          <th className="px-4 py-3.5">Product Listing</th>
                          <th className="px-4 py-3.5">Price &amp; Check</th>
                          <th className="px-4 py-3.5">Quality</th>
                          <th className="px-4 py-3.5">Status</th>
                          <th className="px-4 py-3.5 text-right">Views / Clicks</th>
                          <th className="px-4 py-3.5 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-stone-100">
                        {filteredProducts.length === 0 ? (
                          <tr>
                            <td colSpan={6} className="px-4 py-12 text-center text-stone-500">
                              No products yet. Click <strong>Add Product</strong> to list your first affiliate item!
                            </td>
                          </tr>
                        ) : (
                          filteredProducts.map((p) => (
                            <tr key={p.id} className="hover:bg-[#FAFAF9]">
                              <td className="px-4 py-3.5">
                                <div className="flex items-center gap-3">
                                  {p.image_url ? (
                                    <img
                                      src={p.image_url}
                                      alt={p.title}
                                      className="h-12 w-12 rounded-xl object-cover border border-stone-200 shrink-0"
                                    />
                                  ) : (
                                    <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-stone-100 text-stone-400 shrink-0">
                                      <ShoppingBag className="h-5 w-5" />
                                    </div>
                                  )}
                                  <div className="min-w-0">
                                    <Link
                                      href={`/s/${activeStore.slug}/p/${p.slug}`}
                                      target="_blank"
                                      className="font-bold text-[#111315] hover:text-[#047857] hover:underline truncate block max-w-xs"
                                    >
                                      {p.title}
                                    </Link>
                                    <p className="text-xs text-stone-500">
                                      {p.category} · {p.merchant_name} ·{' '}
                                      <span className="font-semibold text-[#047857]">
                                        {(p.available_countries || ['US'])
                                          .map((c) => formatCountryLabel(c))
                                          .join(', ')}
                                      </span>
                                    </p>
                                  </div>
                                </div>
                              </td>
                              <td className="px-4 py-3.5">
                                <p className="font-bold text-[#111315]">{p.price_display || '—'}</p>
                                <span
                                  title={p.last_price_note || 'Run AI Reviser to audit'}
                                  className={`mt-1 inline-block rounded-full px-2 py-0.5 text-[10px] font-bold ${
                                    p.price_status === 'verified'
                                      ? 'bg-emerald-50 text-emerald-700'
                                      : p.price_status === 'needs_review'
                                        ? 'bg-amber-50 text-amber-800'
                                        : p.price_status === 'unreachable'
                                          ? 'bg-rose-50 text-rose-700'
                                          : 'bg-stone-100 text-stone-500'
                                  }`}
                                >
                                  {p.price_status === 'verified'
                                    ? 'Verified'
                                    : p.price_status === 'needs_review'
                                      ? 'Check Price'
                                      : p.price_status === 'unreachable'
                                        ? 'Link Issue'
                                        : 'Not Audited'}
                                </span>
                              </td>
                              <td className="px-4 py-3.5">
                                <span className="rounded-lg bg-stone-100 px-2 py-1 font-mono text-xs font-bold text-stone-800">
                                  {p.quality_score || 85}/100
                                </span>
                              </td>
                              <td className="px-4 py-3.5">
                                <button
                                  type="button"
                                  onClick={() => handleToggleProductStatus(p)}
                                  title="Click to toggle Published / Draft"
                                  className={`rounded-full px-3 py-1 text-[11px] font-bold transition-colors ${
                                    p.status === 'published'
                                      ? 'bg-emerald-50 text-[#047857] border border-emerald-200 hover:bg-emerald-100'
                                      : 'bg-stone-100 text-stone-600 border border-stone-200 hover:bg-stone-200'
                                  }`}
                                >
                                  {p.status === 'published' ? 'Live' : 'Draft'}
                                </button>
                              </td>
                              <td className="px-4 py-3.5 text-right font-mono text-xs">
                                <span className="text-stone-500">{p.impressions}</span> /{' '}
                                <strong className="text-[#047857]">{p.clicks}</strong>
                              </td>
                              <td className="px-4 py-3.5 text-right">
                                <div className="inline-flex items-center gap-1">
                                  <Link
                                    href={`/s/${activeStore.slug}/p/${p.slug}`}
                                    target="_blank"
                                    className="rounded-lg border border-stone-200 p-1.5 text-stone-600 hover:bg-stone-100 hover:text-[#111315]"
                                    title="Open Full Listing Page"
                                  >
                                    <ExternalLink className="h-3.5 w-3.5" />
                                  </Link>
                                  <button
                                    type="button"
                                    onClick={() => handleReviseProducts(p.id)}
                                    className="rounded-lg border border-stone-200 p-1.5 text-[#047857] hover:bg-emerald-50"
                                    title="Run AI Price & Link Reviser on this product"
                                  >
                                    <Sparkles className="h-3.5 w-3.5" />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleDuplicateProduct(p)}
                                    className="rounded-lg border border-stone-200 p-1.5 text-stone-600 hover:bg-stone-100"
                                    title="Duplicate as Draft"
                                  >
                                    <CopyPlus className="h-3.5 w-3.5" />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => openEditProduct(p)}
                                    className="rounded-lg border border-stone-200 p-1.5 text-stone-600 hover:bg-stone-100 hover:text-[#111315]"
                                    title="Edit"
                                  >
                                    <Edit3 className="h-3.5 w-3.5" />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleDeleteProduct(p.id)}
                                    className="rounded-lg border border-stone-200 p-1.5 text-stone-600 hover:bg-rose-50 hover:text-rose-600"
                                    title="Delete"
                                  >
                                    <Trash2 className="h-3.5 w-3.5" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 4: BLOG & SEO */}
            {tab === 'blog' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="font-display text-lg font-bold text-slate-900">
                      Store Blog & SEO Buying Guides
                    </h2>
                    <p className="text-xs text-slate-500">
                      Publish helpful reviews and attach clickable affiliate products right inside each article.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={openNewPost}
                    className="inline-flex items-center gap-2 rounded-xl bg-[#111315] px-4 py-2.5 text-sm font-bold text-white shadow-sm hover:bg-[#047857] transition-colors"
                  >
                    <Plus className="h-4 w-4" /> New SEO Article
                  </button>
                </div>

                {posts.length === 0 ? (
                  <div className="rounded-2xl border border-slate-200 bg-white p-12 text-center text-slate-500">
                    No blog articles yet. Write your first SEO buying guide to bring organic search visitors!
                  </div>
                ) : (
                  <div className="grid gap-4 md:grid-cols-2">
                    {posts.map((post) => (
                      <div
                        key={post.id}
                        className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm flex flex-col justify-between"
                      >
                        <div>
                          <div className="flex items-center justify-between text-xs">
                            <span className="font-bold text-indigo-600">{post.category}</span>
                            <span
                              className={`rounded-full px-2.5 py-0.5 text-[11px] font-bold ${
                                post.status === 'published'
                                  ? 'bg-emerald-50 text-emerald-700'
                                  : 'bg-slate-100 text-slate-600'
                              }`}
                            >
                              {post.status}
                            </span>
                          </div>
                          <h3 className="mt-2 font-display text-base font-bold text-slate-900">
                            {post.title}
                          </h3>
                          <p className="mt-1.5 text-xs text-slate-600 line-clamp-2">{post.excerpt}</p>
                        </div>

                        <div className="mt-4 border-t border-slate-100 pt-3 flex items-center justify-between text-xs">
                          <span className="text-slate-500">
                            Real Views: <strong>{post.views}</strong> · Embedded Deals:{' '}
                            <strong>{post.featured_product_ids?.length || 0}</strong>
                          </span>
                          <div className="flex items-center gap-1.5">
                            <Link
                              href={`/s/${activeStore.slug}/blog/${post.slug}`}
                              target="_blank"
                              className="rounded-lg border border-slate-200 p-1.5 text-slate-600 hover:text-indigo-600"
                              title="View Live"
                            >
                              <ExternalLink className="h-3.5 w-3.5" />
                            </Link>
                            <button
                              type="button"
                              onClick={() => openEditPost(post)}
                              className="rounded-lg border border-slate-200 p-1.5 text-slate-600 hover:text-indigo-600"
                            >
                              <Edit3 className="h-3.5 w-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeletePost(post.id)}
                              className="rounded-lg border border-slate-200 p-1.5 text-slate-600 hover:text-rose-600"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB 4.5: MARKETING KIT & SCRIPTS */}
            {tab === 'marketing' && (
              <MarketingKitTab store={activeStore} products={products} />
            )}

            {/* TAB 6: BILLING & PLAN */}
            {tab === 'billing' && <BillingTab onNotify={notify} />}

            {/* TAB 5: REAL ANALYTICS STUDIO */}
            {tab === 'analytics' && analytics && (
              <div className="space-y-6">
                <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-6">
                    <div>
                      <h2 className="font-display text-lg font-bold text-slate-900">
                        14-Day Real Traffic, Impressions & Clicks
                      </h2>
                      <p className="text-xs text-slate-500">
                        Every bar reflects real database events. Open your live store and click deals to watch this update live!
                      </p>
                    </div>
                    <div className="flex items-center gap-4 text-xs font-semibold">
                      <span className="flex items-center gap-1.5">
                        <span className="h-2.5 w-2.5 rounded-full bg-indigo-500" /> Visits
                      </span>
                      <span className="flex items-center gap-1.5">
                        <span className="h-2.5 w-2.5 rounded-full bg-amber-400" /> Impressions
                      </span>
                      <span className="flex items-center gap-1.5">
                        <span className="h-2.5 w-2.5 rounded-full bg-emerald-500" /> Clicks
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-[repeat(14,minmax(0,1fr))] gap-1.5 items-end h-44 pt-4">
                    {analytics.dailyTrend.map((d) => (
                      <div key={d.day} className="flex flex-col items-center gap-1 h-full justify-end">
                        <div className="flex items-end gap-0.5 h-32 w-full justify-center">
                          <div
                            title={`${d.label}: ${d.visits} visits`}
                            className="w-2 rounded-t bg-indigo-500 transition-all"
                            style={{ height: `${Math.max(4, (d.visits / maxDailyVal) * 100)}%` }}
                          />
                          <div
                            title={`${d.label}: ${d.impressions} impressions`}
                            className="w-2 rounded-t bg-amber-400 transition-all"
                            style={{ height: `${Math.max(4, (d.impressions / maxDailyVal) * 100)}%` }}
                          />
                          <div
                            title={`${d.label}: ${d.clicks} clicks`}
                            className="w-2 rounded-t bg-emerald-500 transition-all"
                            style={{ height: `${Math.max(4, (d.clicks / maxDailyVal) * 100)}%` }}
                          />
                        </div>
                        <span className="text-[9px] text-slate-400 truncate max-w-full">
                          {d.label.split(' ')[1]}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="grid gap-6 lg:grid-cols-2">
                  {/* TRAFFIC SOURCES */}
                  <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                    <h3 className="font-display text-base font-bold text-slate-900">
                      Real Traffic Sources (Referrers)
                    </h3>
                    <p className="text-xs text-slate-500 mb-4">
                      Tip: Share links with <code className="bg-slate-100 px-1 rounded">?src=tiktok</code> or{' '}
                      <code className="bg-slate-100 px-1 rounded">?src=facebook</code> to tag social campaigns.
                    </p>
                    {analytics.referrers.length === 0 ? (
                      <p className="text-xs text-slate-400 py-6 text-center">
                        No traffic events recorded yet. Open your live store link to record your first real visit!
                      </p>
                    ) : (
                      <div className="space-y-3">
                        {analytics.referrers.map((r) => {
                          const total = analytics.referrers.reduce((acc, x) => acc + x.count, 0) || 1;
                          const pct = Math.round((r.count / total) * 100);
                          return (
                            <div key={r.source}>
                              <div className="flex justify-between text-xs font-semibold mb-1">
                                <span>{r.source}</span>
                                <span>
                                  {r.count} ({pct}%)
                                </span>
                              </div>
                              <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                                <div className="h-full rounded-full bg-indigo-600" style={{ width: `${pct}%` }} />
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>

                  {/* LIVE EVENT STREAM */}
                  <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                    <h3 className="font-display text-base font-bold text-slate-900 mb-4">
                      Recent Real Event Log
                    </h3>
                    {analytics.recentEvents.length === 0 ? (
                      <p className="text-xs text-slate-400 py-6 text-center">
                        Zero events yet. All events shown here are 100% real visits and clicks.
                      </p>
                    ) : (
                      <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                        {analytics.recentEvents.map((ev) => (
                          <div
                            key={ev.id}
                            className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2 text-xs"
                          >
                            <div className="min-w-0">
                              <span
                                className={`inline-block rounded px-1.5 py-0.5 text-[10px] font-bold mr-2 ${
                                  ev.event_type === 'product_click'
                                    ? 'bg-emerald-100 text-emerald-700'
                                    : ev.event_type === 'store_visit'
                                      ? 'bg-indigo-100 text-indigo-700'
                                      : 'bg-amber-100 text-amber-800'
                                }`}
                              >
                                {ev.event_type === 'product_click'
                                  ? 'Affiliate Click'
                                  : ev.event_type === 'store_visit'
                                    ? 'Store Visit'
                                    : ev.event_type === 'post_view'
                                      ? 'Guide Read'
                                      : 'Product View'}
                              </span>
                              <span className="text-slate-700 truncate">
                                {ev.product_title || 'Storefront'}
                              </span>
                            </div>
                            <span className="text-[10px] font-mono text-slate-400 shrink-0 ml-2">
                              {ev.referrer_source} ·{' '}
                              {new Date(ev.created_at).toLocaleTimeString([], {
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </main>

      {/* CREATE NEW STORE MODAL */}
      {showNewStoreModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display text-lg font-bold text-slate-900">Create New Storefront</h3>
              <button type="button" onClick={() => setShowNewStoreModal(false)}>
                <X className="h-5 w-5 text-slate-400" />
              </button>
            </div>
            <form onSubmit={handleCreateStore} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Store Name</label>
                <input
                  type="text"
                  required
                  value={newStoreName}
                  onChange={(e) => setNewStoreName(e.target.value)}
                  placeholder="e.g. Urban Tech Deals"
                  className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Custom URL Slug (optional)
                </label>
                <input
                  type="text"
                  value={newStoreSlug}
                  onChange={(e) => setNewStoreSlug(e.target.value)}
                  placeholder="urban-tech-deals"
                  className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm font-mono"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">Template</label>
                <select
                  value={newStoreTemplate}
                  onChange={(e) => setNewStoreTemplate(e.target.value)}
                  className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm"
                >
                  {STORE_TEMPLATES.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name} ({t.niche})
                    </option>
                  ))}
                </select>
              </div>
              <button
                type="submit"
                className="w-full rounded-xl bg-[#111315] py-3 text-sm font-bold text-white hover:bg-[#047857] transition-colors"
              >
                Create & Launch Store
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ADD / EDIT PRODUCT MODAL */}
      {showProductModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
          <div className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-2xl bg-white p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display text-lg font-bold text-slate-900">
                {editingProduct ? 'Edit Affiliate Product' : 'Add New Affiliate Product'}
              </h3>
              <button type="button" onClick={() => setShowProductModal(false)}>
                <X className="h-5 w-5 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Product Title *</label>
                  <input
                    type="text"
                    required
                    value={productForm.title}
                    onChange={(e) => setProductForm((p) => ({ ...p, title: e.target.value }))}
                    placeholder="e.g. Digital Kitchen Scale 0.1g"
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Your Affiliate Tracking URL (https://...) *
                  </label>
                  <input
                    type="url"
                    required
                    value={productForm.affiliate_url}
                    onChange={(e) => setProductForm((p) => ({ ...p, affiliate_url: e.target.value }))}
                    placeholder="https://amzn.to/... or https://impact.com/..."
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Category</label>
                  <input
                    type="text"
                    value={productForm.category}
                    onChange={(e) => setProductForm((p) => ({ ...p, category: e.target.value }))}
                    placeholder="Kitchen, Tech, Beauty..."
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Merchant Name</label>
                  <input
                    type="text"
                    value={productForm.merchant_name}
                    onChange={(e) => setProductForm((p) => ({ ...p, merchant_name: e.target.value }))}
                    placeholder="Amazon, Impact, Daraz..."
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Display Price</label>
                  <input
                    type="text"
                    value={productForm.price_display}
                    onChange={(e) => setProductForm((p) => ({ ...p, price_display: e.target.value }))}
                    placeholder="$29.99"
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Original Price (Optional Strikethrough)
                  </label>
                  <input
                    type="text"
                    value={productForm.original_price}
                    onChange={(e) => setProductForm((p) => ({ ...p, original_price: e.target.value }))}
                    placeholder="$39.99"
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Product Image (Upload Photo or Paste URL)
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={productForm.image_url}
                      onChange={(e) => setProductForm((p) => ({ ...p, image_url: e.target.value }))}
                      placeholder="/uploads/... or https://..."
                      className="flex-1 rounded-xl border border-slate-300 px-3 py-2 text-sm"
                    />
                    <label className="inline-flex cursor-pointer items-center gap-1.5 rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-xs font-semibold hover:bg-slate-100">
                      <Upload className="h-3.5 w-3.5" />
                      {uploading ? '...' : 'Upload'}
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={async (e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const url = await handleImageUpload(file);
                            if (url) setProductForm((p) => ({ ...p, image_url: url }));
                          }
                        }}
                      />
                    </label>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Badge (Optional)</label>
                  <input
                    type="text"
                    value={productForm.badge}
                    onChange={(e) => setProductForm((p) => ({ ...p, badge: e.target.value }))}
                    placeholder="Best Seller, Top Pick, Viral..."
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Publish Status</label>
                  <select
                    value={productForm.status}
                    onChange={(e) =>
                      setProductForm((p) => ({ ...p, status: e.target.value as 'draft' | 'published' }))
                    }
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                  >
                    <option value="published">Published (Visible on Store)</option>
                    <option value="draft">Draft (Hidden)</option>
                  </select>
                </div>
                <div className="sm:col-span-2 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-emerald-200 bg-emerald-50/70 px-3.5 py-2.5">
                  <div className="text-xs text-emerald-950">
                    <strong className="font-bold">AI Product Copywriter</strong> — Auto-generate pitch, overview &amp; 4 buyer benefits from title.
                  </div>
                  <button
                    type="button"
                    disabled={aiWritingProduct}
                    onClick={handleAiWriteProduct}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-[#047857] px-3 py-1.5 text-xs font-bold text-white hover:bg-emerald-800 disabled:opacity-60 shrink-0"
                  >
                    <Sparkles className={`h-3.5 w-3.5 ${aiWritingProduct ? 'animate-spin' : ''}`} />
                    {aiWritingProduct ? 'Writing...' : 'AI Auto-Write'}
                  </button>
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Short Pitch</label>
                  <input
                    type="text"
                    value={productForm.short_description}
                    onChange={(e) => setProductForm((p) => ({ ...p, short_description: e.target.value }))}
                    placeholder="1-sentence reason buyers love this product"
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Full Description</label>
                  <textarea
                    rows={3}
                    value={productForm.description}
                    onChange={(e) => setProductForm((p) => ({ ...p, description: e.target.value }))}
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Key Benefits (One per line)
                  </label>
                  <textarea
                    rows={3}
                    value={productForm.benefits}
                    onChange={(e) => setProductForm((p) => ({ ...p, benefits: e.target.value }))}
                    placeholder={"Saves counter space\nEasy 1-button operation\nUSB-C rechargeable"}
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                  />
                </div>
                <div className="sm:col-span-2 rounded-xl border border-slate-200 bg-slate-50 p-3.5">
                  <label className="block text-xs font-bold text-slate-700 mb-2">
                    Available / Deliverable Countries (Where buyers can purchase this product)
                  </label>
                  <div className="flex flex-wrap gap-1.5">
                    {COUNTRY_OPTIONS.map((c) => {
                      const active = productForm.available_countries.includes(c.code);
                      return (
                        <button
                          key={c.code}
                          type="button"
                          onClick={() => {
                            setProductForm((prev) => {
                              if (c.code === 'GLOBAL') {
                                return {
                                  ...prev,
                                  available_countries: active ? ['US'] : ['GLOBAL'],
                                };
                              }
                              const withoutGlobal = prev.available_countries.filter((x) => x !== 'GLOBAL');
                              const next = active
                                ? withoutGlobal.filter((x) => x !== c.code)
                                : [...withoutGlobal, c.code];
                              return {
                                ...prev,
                                available_countries: next.length ? next : ['US'],
                              };
                            });
                          }}
                          className={`rounded-full px-3 py-1 text-xs font-bold transition-colors ${
                            active
                              ? 'bg-[#047857] text-white shadow-sm'
                              : 'bg-white border border-stone-200 text-stone-600 hover:border-emerald-300'
                          }`}
                        >
                          {c.short}
                        </button>
                      );
                    })}
                  </div>
                </div>
                <label className="sm:col-span-2 flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={productForm.is_featured}
                    onChange={(e) => setProductForm((p) => ({ ...p, is_featured: e.target.checked }))}
                    className="h-4 w-4 accent-indigo-600"
                  />
                  Highlight in Storefront &ldquo;Featured Picks&rdquo; Spotlight
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowProductModal(false)}
                  className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm font-semibold text-slate-600"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-[#111315] px-6 py-2.5 text-sm font-bold text-white hover:bg-[#047857] transition-colors"
                >
                  {editingProduct ? 'Save Changes' : 'Publish Product'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADD / EDIT BLOG POST MODAL */}
      {showPostModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
          <div className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-2xl bg-white p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display text-lg font-bold text-slate-900">
                {editingPost ? 'Edit SEO Blog Article' : 'Write New SEO Article'}
              </h3>
              <button type="button" onClick={() => setShowPostModal(false)}>
                <X className="h-5 w-5 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleSavePost} className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Article Title *</label>
                  <input
                    type="text"
                    required
                    value={postForm.title}
                    onChange={(e) => setPostForm((p) => ({ ...p, title: e.target.value }))}
                    placeholder="e.g. Top 7 Budget Desk Upgrades for Remote Workers"
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Category</label>
                  <input
                    type="text"
                    value={postForm.category}
                    onChange={(e) => setPostForm((p) => ({ ...p, category: e.target.value }))}
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Status</label>
                  <select
                    value={postForm.status}
                    onChange={(e) =>
                      setPostForm((p) => ({ ...p, status: e.target.value as 'draft' | 'published' }))
                    }
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                  >
                    <option value="published">Published</option>
                    <option value="draft">Draft</option>
                  </select>
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Cover Image (Upload or URL)
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={postForm.cover_image}
                      onChange={(e) => setPostForm((p) => ({ ...p, cover_image: e.target.value }))}
                      className="flex-1 rounded-xl border border-slate-300 px-3 py-2 text-sm"
                    />
                    <label className="inline-flex cursor-pointer items-center gap-1.5 rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-xs font-semibold">
                      <Upload className="h-3.5 w-3.5" />
                      Upload
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={async (e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const url = await handleImageUpload(file);
                            if (url) setPostForm((p) => ({ ...p, cover_image: url }));
                          }
                        }}
                      />
                    </label>
                  </div>
                </div>
                <div className="sm:col-span-2 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-emerald-200 bg-emerald-50/70 px-3.5 py-2.5">
                  <div className="text-xs text-emerald-950">
                    <strong className="font-bold">AI SEO Buying Guide Writer</strong> — Draft structured guide, excerpt &amp; SEO meta in 1 click.
                  </div>
                  <button
                    type="button"
                    disabled={aiWritingPost}
                    onClick={handleAiWritePost}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-[#047857] px-3 py-1.5 text-xs font-bold text-white hover:bg-emerald-800 disabled:opacity-60 shrink-0"
                  >
                    <Sparkles className={`h-3.5 w-3.5 ${aiWritingPost ? 'animate-spin' : ''}`} />
                    {aiWritingPost ? 'Drafting...' : 'AI Draft Guide'}
                  </button>
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Short Excerpt</label>
                  <input
                    type="text"
                    value={postForm.excerpt}
                    onChange={(e) => setPostForm((p) => ({ ...p, excerpt: e.target.value }))}
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Article Body (Supports ## Headings, - Bullets, **Bold**)
                  </label>
                  <textarea
                    rows={6}
                    required
                    value={postForm.content}
                    onChange={(e) => setPostForm((p) => ({ ...p, content: e.target.value }))}
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm font-mono"
                  />
                </div>
                <div className="sm:col-span-2 rounded-xl bg-slate-50 border border-slate-200 p-4 space-y-2">
                  <p className="text-xs font-bold text-slate-700">Embed Store Products Inside Article</p>
                  <div className="grid gap-1.5 sm:grid-cols-2 max-h-36 overflow-y-auto">
                    {products.map((prod) => {
                      const checked = postForm.featured_product_ids.includes(prod.id);
                      return (
                        <label
                          key={prod.id}
                          className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer"
                        >
                          <input
                            type="checkbox"
                            checked={checked}
                            onChange={(e) => {
                              setPostForm((prev) => ({
                                ...prev,
                                featured_product_ids: e.target.checked
                                  ? [...prev.featured_product_ids, prod.id]
                                  : prev.featured_product_ids.filter((id) => id !== prod.id),
                              }));
                            }}
                            className="accent-indigo-600"
                          />
                          <span className="truncate">{prod.title}</span>
                        </label>
                      );
                    })}
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">SEO Title</label>
                  <input
                    type="text"
                    value={postForm.seo_title}
                    onChange={(e) => setPostForm((p) => ({ ...p, seo_title: e.target.value }))}
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">SEO Meta Description</label>
                  <input
                    type="text"
                    value={postForm.seo_description}
                    onChange={(e) => setPostForm((p) => ({ ...p, seo_description: e.target.value }))}
                    className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-xs"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowPostModal(false)}
                  className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm font-semibold text-slate-600"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-[#111315] px-6 py-2.5 text-sm font-bold text-white hover:bg-[#047857] transition-colors"
                >
                  {editingPost ? 'Update Article' : 'Publish Article'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* BULK CSV IMPORT MODAL */}
      {showCsvModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
          <div className="w-full max-w-2xl rounded-2xl bg-white p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <FileSpreadsheet className="h-5 w-5 text-indigo-600" />
                <h3 className="font-display text-lg font-bold text-slate-900">
                  Bulk CSV Product Import
                </h3>
              </div>
              <button type="button" onClick={() => setShowCsvModal(false)}>
                <X className="h-5 w-5 text-slate-400" />
              </button>
            </div>

            <div className="rounded-xl bg-emerald-50 border border-emerald-200 p-4 mb-4 flex flex-wrap items-center justify-between gap-3">
              <p className="text-xs text-emerald-950">
                Upload a CSV file or paste rows with headers{' '}
                <code className="bg-white px-1 rounded font-mono">title, affiliate_url</code> (plus
                optional category, price_display, merchant_name, benefits separated by |).
              </p>
              <button
                type="button"
                onClick={handleDownloadSampleCsv}
                className="inline-flex items-center gap-1.5 rounded-lg bg-[#047857] px-3 py-1.5 text-xs font-bold text-white hover:bg-emerald-800 shrink-0"
              >
                <Download className="h-3.5 w-3.5" /> Download Sample CSV
              </button>
            </div>

            <form onSubmit={handleBulkCsvImport} className="space-y-4">
              <div>
                <label className="inline-flex cursor-pointer items-center gap-2 rounded-xl border border-slate-300 bg-slate-50 px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-100">
                  <Upload className="h-4 w-4 text-indigo-600" />
                  Load .CSV File from Computer
                  <input
                    type="file"
                    accept=".csv,text/csv"
                    className="hidden"
                    onChange={async (e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const text = await file.text();
                        setCsvText(text);
                      }
                    }}
                  />
                </label>
              </div>

              <textarea
                rows={7}
                required
                value={csvText}
                onChange={(e) => setCsvText(e.target.value)}
                placeholder={'title,affiliate_url,category,price_display,merchant_name\n"Smart Mug Warmer","https://amzn.to/example","Kitchen","$24.99","Amazon"'}
                className="w-full rounded-xl border border-slate-300 p-3 font-mono text-xs focus:border-indigo-500 focus:outline-none"
              />

              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCsvModal(false)}
                  className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm font-semibold text-slate-600"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={importingCsv}
                  className="rounded-xl bg-[#111315] px-6 py-2.5 text-sm font-bold text-white hover:bg-[#047857] transition-colors disabled:opacity-60"
                >
                  {importingCsv ? 'Importing...' : 'Import Products Now'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
