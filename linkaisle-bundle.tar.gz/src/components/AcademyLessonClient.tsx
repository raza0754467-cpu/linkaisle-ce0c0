'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import {
  ArrowLeft,
  ArrowRight,
  BookOpen,
  CheckCircle2,
  Clock,
  Rocket,
} from 'lucide-react';
import { AcademyLesson } from '@/lib/types';
import MarkdownRenderer from './MarkdownRenderer';

export default function AcademyLessonClient({
  lesson,
  prevLesson,
  nextLesson,
  isLoggedIn,
}: {
  lesson: AcademyLesson;
  prevLesson: AcademyLesson | null;
  nextLesson: AcademyLesson | null;
  isLoggedIn: boolean;
}) {
  const [isDone, setIsDone] = useState(false);

  useEffect(() => {
    try {
      const done: string[] = JSON.parse(localStorage.getItem('affiliforge_lessons_done') || '[]');
      setIsDone(done.includes(lesson.id));
    } catch {}
  }, [lesson.id]);

  function toggleComplete() {
    try {
      const done: string[] = JSON.parse(localStorage.getItem('affiliforge_lessons_done') || '[]');
      const next = isDone ? done.filter((id) => id !== lesson.id) : [...new Set([...done, lesson.id])];
      localStorage.setItem('affiliforge_lessons_done', JSON.stringify(next));
      setIsDone(!isDone);
    } catch {}
  }

  return (
    <main className="mx-auto max-w-4xl px-4 py-10 sm:px-6 lg:px-8">
      <Link
        href="/academy"
        className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#047857] hover:underline"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to Affiliate Academy
      </Link>

      <article className="mt-6 rounded-2xl border border-stone-200 bg-white p-6 shadow-sm sm:p-10">
        <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex flex-wrap items-center gap-2.5">
            <span className="rounded-full bg-stone-100 px-3 py-1 font-bold text-[#111315]">
              Module {lesson.module_number}
            </span>
            <span className="rounded-full bg-emerald-50 px-3 py-1 font-bold text-[#047857]">
              {lesson.level}
            </span>
            <span className="flex items-center gap-1 text-stone-500">
              <Clock className="h-3.5 w-3.5" />
              {lesson.duration_minutes} min
            </span>
          </div>

          <button
            type="button"
            onClick={toggleComplete}
            className={`inline-flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-xs font-bold transition-colors ${
              isDone
                ? 'bg-[#047857] text-white'
                : 'border border-stone-200 bg-[#FAFAF9] text-stone-700 hover:bg-emerald-50 hover:text-[#047857]'
            }`}
          >
            <CheckCircle2 className="h-4 w-4" />
            {isDone ? 'Completed' : 'Mark as Complete'}
          </button>
        </div>

        <h1 className="mt-4 font-display text-2xl font-extrabold text-[#111315] sm:text-4xl">
          {lesson.title}
        </h1>
        <p className="mt-3 text-base text-stone-600 border-b border-stone-100 pb-6">
          {lesson.summary}
        </p>

        <div className="mt-6">
          <MarkdownRenderer content={lesson.content} />
        </div>

        <div className="mt-10 rounded-2xl bg-emerald-50 border border-emerald-200 p-5 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <BookOpen className="h-6 w-6 text-[#047857] shrink-0" />
            <div>
              <p className="font-display text-sm font-bold text-[#111315]">
                Ready to put this lesson into practice?
              </p>
              <p className="text-xs text-stone-600">
                Open Creator Studio to add products, generate AI video scripts, or publish SEO guides.
              </p>
            </div>
          </div>
          <Link
            href={isLoggedIn ? '/dashboard' : '/register'}
            className="inline-flex items-center gap-1.5 rounded-full bg-[#111315] px-5 py-2.5 text-xs font-bold text-white hover:bg-[#047857] transition-colors"
          >
            <Rocket className="h-4 w-4" />
            {isLoggedIn ? 'Go to Studio' : 'Create Free Account'}
          </Link>
        </div>
      </article>

      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        {prevLesson ? (
          <Link
            href={`/academy/${prevLesson.slug}`}
            className="rounded-xl border border-stone-200 bg-white p-4 hover:border-[#047857]/40 transition-colors"
          >
            <span className="text-xs font-semibold text-stone-400 flex items-center gap-1">
              <ArrowLeft className="h-3.5 w-3.5" /> Previous Lesson
            </span>
            <p className="mt-1 text-sm font-bold text-[#111315]">{prevLesson.title}</p>
          </Link>
        ) : (
          <div />
        )}
        {nextLesson && (
          <Link
            href={`/academy/${nextLesson.slug}`}
            className="rounded-xl border border-stone-200 bg-white p-4 text-right hover:border-[#047857]/40 transition-colors"
          >
            <span className="text-xs font-semibold text-[#047857] inline-flex items-center gap-1">
              Next Lesson <ArrowRight className="h-3.5 w-3.5" />
            </span>
            <p className="mt-1 text-sm font-bold text-[#111315]">{nextLesson.title}</p>
          </Link>
        )}
      </div>
    </main>
  );
}
