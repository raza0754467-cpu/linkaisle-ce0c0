import React from 'react';

function renderInline(text: string): React.ReactNode[] {
  const tokens = text.split(/(\*\*[^*]+\*\*|`[^`]+`)/g);
  return tokens.map((token, idx) => {
    if (token.startsWith('**') && token.endsWith('**')) {
      return (
        <strong key={idx} className="font-semibold text-slate-900">
          {token.slice(2, -2)}
        </strong>
      );
    }
    if (token.startsWith('`') && token.endsWith('`')) {
      return (
        <code key={idx} className="rounded bg-indigo-50 px-1.5 py-0.5 text-sm font-mono text-indigo-700">
          {token.slice(1, -1)}
        </code>
      );
    }
    return <React.Fragment key={idx}>{token}</React.Fragment>;
  });
}

export default function MarkdownRenderer({ content }: { content: string }) {
  const lines = content.split('\n');
  const elements: React.ReactNode[] = [];
  let listItems: string[] = [];
  let listType: 'ul' | 'ol' | null = null;

  const flushList = (keyPrefix: number) => {
    if (!listItems.length || !listType) return;
    if (listType === 'ul') {
      elements.push(
        <ul key={`list-${keyPrefix}`} className="mb-4 list-disc space-y-2 pl-6 text-slate-700">
          {listItems.map((item, i) => (
            <li key={i}>{renderInline(item)}</li>
          ))}
        </ul>
      );
    } else {
      elements.push(
        <ol key={`list-${keyPrefix}`} className="mb-4 list-decimal space-y-2 pl-6 text-slate-700">
          {listItems.map((item, i) => (
            <li key={i}>{renderInline(item)}</li>
          ))}
        </ol>
      );
    }
    listItems = [];
    listType = null;
  };

  lines.forEach((rawLine, idx) => {
    const line = rawLine.trim();
    if (!line) {
      flushList(idx);
      return;
    }

    if (line.startsWith('## ')) {
      flushList(idx);
      elements.push(
        <h2 key={idx} className="mt-8 mb-3 font-display text-xl font-bold text-slate-900">
          {line.slice(3)}
        </h2>
      );
      return;
    }

    if (line.startsWith('### ')) {
      flushList(idx);
      elements.push(
        <h3 key={idx} className="mt-6 mb-2 font-display text-lg font-bold text-slate-800">
          {line.slice(4)}
        </h3>
      );
      return;
    }

    if (line.startsWith('- ')) {
      if (listType !== 'ul') {
        flushList(idx);
        listType = 'ul';
      }
      listItems.push(line.slice(2));
      return;
    }

    const orderedMatch = line.match(/^\d+\.\s+(.*)$/);
    if (orderedMatch) {
      if (listType !== 'ol') {
        flushList(idx);
        listType = 'ol';
      }
      listItems.push(orderedMatch[1]);
      return;
    }

    flushList(idx);
    elements.push(
      <p key={idx} className="mb-4 leading-relaxed text-slate-700">
        {renderInline(line)}
      </p>
    );
  });

  flushList(lines.length + 1);
  return <div className="prose-custom">{elements}</div>;
}
