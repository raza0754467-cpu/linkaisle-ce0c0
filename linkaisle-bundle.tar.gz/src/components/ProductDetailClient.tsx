'use client';

import { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import {
  ArrowLeft,
  Award,
  Check,
  CheckCircle2,
  Clock,
  Copy,
  ExternalLink,
  Globe,
  MessageSquare,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  Star,
  Store as StoreIcon,
  Tag,
  Truck,
} from 'lucide-react';
import { Product, Store, formatCountryLabel } from '@/lib/types';
import { calcSavingsPct } from './themes/types';

export default function ProductDetailClient({
  store,
  product,
  relatedProducts,
  platformName,
}: {
  store: Store;
  product: Product;
  relatedProducts: Product[];
  platformName: string;
}) {
  const [copied, setCopied] = useState(false);
  const [trafficSrc, setTrafficSrc] = useState('');
  const trackedRef = useRef(false);

  // Real buyer reviews & comments state
  const [reviews, setReviews] = useState<
    { id: string; author_name: string; rating: number; comment: string; created_at: string }[]
  >([]);
  const [reviewAuthor, setReviewAuthor] = useState('');
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [submittingReview, setSubmittingReview] = useState(false);
  const [reviewNotice, setReviewNotice] = useState('');

  // Extract official Amazon ASIN & customer reviews link if affiliate_url is Amazon
  const amazonInfo = (() => {
    try {
      const u = new URL(product.affiliate_url || '');
      const host = u.hostname.toLowerCase();
      if (!host.includes('amazon.')) return null;
      const m = u.pathname.match(/\/(?:dp|gp\/product|gp\/aw\/d)\/([A-Z0-9]{10})(?:[/?]|$)/i);
      const asin = m ? m[1].toUpperCase() : product.asin || null;
      const normHost = host.startsWith('www.') ? host : `www.${host}`;
      return {
        asin,
        reviewsUrl: asin ? `https://${normHost}/product-reviews/${asin}` : null,
      };
    } catch {
      return null;
    }
  })();

  useEffect(() => {
    fetch(`/api/products/${product.id}/reviews`)
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (d?.reviews) setReviews(d.reviews);
      })
      .catch(() => {});
  }, [product.id]);

  async function handleSubmitReview(e: React.FormEvent) {
    e.preventDefault();
    setReviewNotice('');
    setSubmittingReview(true);
    try {
      const res = await fetch(`/api/products/${product.id}/reviews`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          author_name: reviewAuthor,
          rating: reviewRating,
          comment: reviewComment,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setReviewNotice(data.error || 'Could not post review.');
        return;
      }
      setReviews((prev) => [data.review, ...prev]);
      setReviewAuthor('');
      setReviewComment('');
      setReviewRating(5);
      setReviewNotice('Thank you! Your review has been published.');
    } finally {
      setSubmittingReview(false);
    }
  }

  useEffect(() => {
    if (trackedRef.current) return;
    trackedRef.current = true;
    const params = new URLSearchParams(window.location.search);
    const src = params.get('utm_source') || params.get('src') || '';
    if (src) setTrafficSrc(src);

    fetch('/api/track', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        eventType: 'product_impression',
        storeId: store.id,
        productId: product.id,
        referrer: document.referrer || '',
        utmSource: src,
      }),
    }).catch(() => {});
  }, [store.id, product.id]);

  const goUrl = trafficSrc
    ? `/api/go/${product.id}?src=${encodeURIComponent(trafficSrc)}`
    : `/api/go/${product.id}`;

  const savePct = calcSavingsPct(product.price_display, product.original_price);
  const ratingVal = Number(product.rating || 4.8);
  const reviewsVal = Number(product.review_count || 140);

  function handleCopyLink() {
    if (typeof window !== 'undefined') {
      navigator.clipboard?.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  }

  return (
    <div className="min-h-screen bg-[#FAFAF9] text-[#111315]">
      {/* CLEAN STICKY STORE BAR */}
      <header className="sticky top-0 z-30 border-b border-stone-200/90 bg-white/95 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3.5 sm:px-6 lg:px-8">
          <Link
            href={`/s/${store.slug}`}
            className="inline-flex items-center gap-2.5 text-sm font-bold text-[#111315] hover:text-[#047857] transition-colors min-w-0"
          >
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-stone-100 text-stone-700">
              <ArrowLeft className="h-4 w-4" />
            </span>
            <div className="min-w-0">
              <span className="block truncate font-display text-sm font-extrabold leading-tight">
                {store.name}
              </span>
              <span className="block truncate text-[11px] font-normal text-stone-500">
                Back to full collection
              </span>
            </div>
          </Link>

          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={handleCopyLink}
              className="inline-flex items-center gap-1.5 rounded-full border border-stone-200 bg-white px-3.5 py-2 text-xs font-bold text-stone-700 hover:bg-stone-50 transition-colors"
            >
              {copied ? <Check className="h-3.5 w-3.5 text-[#047857]" /> : <Copy className="h-3.5 w-3.5" />}
              {copied ? 'Link Copied' : 'Share'}
            </button>
            <a
              href={goUrl}
              target="_blank"
              rel="noopener noreferrer sponsored"
              className="hidden sm:inline-flex items-center gap-1.5 rounded-full bg-[#111315] px-4 py-2 text-xs font-bold text-white shadow-sm hover:bg-[#047857] transition-colors"
            >
              Check Deal <ExternalLink className="h-3.5 w-3.5" />
            </a>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-8 sm:py-10 sm:px-6 lg:px-8 space-y-14">
        {/* BREADCRUMB */}
        <nav className="flex flex-wrap items-center gap-2 text-xs text-stone-500">
          <Link href="/" className="hover:text-[#111315]">
            {platformName}
          </Link>
          <span>/</span>
          <Link href={`/s/${store.slug}`} className="hover:text-[#111315]">
            {store.name}
          </Link>
          <span>/</span>
          <span className="font-medium text-stone-700">{product.category}</span>
          <span>/</span>
          <span className="truncate text-[#111315] font-semibold max-w-xs">{product.title}</span>
        </nav>

        {/* FLAGSHIP PRODUCT DETAIL LAYOUT */}
        <div className="grid gap-10 lg:grid-cols-12 items-start">
          {/* LEFT COLUMN (STICKY GALLERY + QUICK SPECS + TRUST CARD) */}
          <div className="lg:col-span-6 lg:sticky lg:top-24 space-y-4">
            <div className="group relative overflow-hidden rounded-3xl border border-stone-200/90 bg-white shadow-md aspect-[4/3]">
              {product.image_url ? (
                <img
                  src={product.image_url}
                  alt={product.title}
                  className="h-full w-full object-cover group-hover:scale-[1.03] transition-transform duration-500"
                />
              ) : (
                <div className="flex h-full items-center justify-center text-stone-300">
                  <ShoppingBag className="h-16 w-16" />
                </div>
              )}

              <div className="absolute left-4 top-4 flex flex-wrap gap-2">
                {product.badge && (
                  <span className="rounded-full bg-[#111315]/90 px-3.5 py-1 text-xs font-bold text-white backdrop-blur shadow-sm">
                    {product.badge}
                  </span>
                )}
                {savePct && (
                  <span className="rounded-full bg-[#047857] px-3 py-1 text-xs font-bold text-white shadow-sm">
                    Save {savePct}%
                  </span>
                )}
              </div>
            </div>

            {/* QUICK FACT STRIP */}
            <div className="grid grid-cols-3 gap-3">
              <div className="rounded-2xl border border-stone-200 bg-white p-3.5 text-center">
                <Tag className="mx-auto h-4 w-4 text-[#047857]" />
                <p className="mt-1.5 text-[10px] font-semibold uppercase tracking-wider text-stone-400">
                  Merchant
                </p>
                <p className="mt-0.5 truncate text-xs font-bold text-[#111315]">
                  {product.merchant_name || 'Official Store'}
                </p>
              </div>
              <div className="rounded-2xl border border-stone-200 bg-white p-3.5 text-center">
                <Award className="mx-auto h-4 w-4 text-[#047857]" />
                <p className="mt-1.5 text-[10px] font-semibold uppercase tracking-wider text-stone-400">
                  Listing Quality
                </p>
                <p className="mt-0.5 text-xs font-bold text-[#111315]">
                  {product.quality_score || 85}/100 Verified
                </p>
              </div>
              <div className="rounded-2xl border border-stone-200 bg-white p-3.5 text-center">
                <Truck className="mx-auto h-4 w-4 text-[#047857]" />
                <p className="mt-1.5 text-[10px] font-semibold uppercase tracking-wider text-stone-400">
                  Shipping To
                </p>
                <p className="mt-0.5 truncate text-xs font-bold text-[#111315]">
                  {(product.available_countries || ['US']).length === 1
                    ? formatCountryLabel((product.available_countries || ['US'])[0])
                    : `${(product.available_countries || ['US']).length} Regions`}
                </p>
              </div>
            </div>

            {/* DIRECT MERCHANT TRUST BOX */}
            <div className="rounded-2xl border border-stone-200 bg-white p-4 flex items-start gap-3 text-xs text-stone-600">
              <ShieldCheck className="h-5 w-5 text-[#047857] shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-[#111315]">
                  Official Checkout on {product.merchant_name || 'Merchant Store'}
                </p>
                <p className="mt-0.5 leading-relaxed">
                  You complete your purchase directly on <strong>{product.merchant_name}</strong> — with full
                  official pricing, buyer protection, returns, and warranty.
                </p>
              </div>
            </div>
          </div>

          {/* RIGHT COLUMN: TITLE, DEAL BOX, BENEFITS & DETAILS */}
          <div className="lg:col-span-6 space-y-6">
            <div>
              <div className="flex flex-wrap items-center gap-2.5 text-xs">
                <span className="rounded-full bg-emerald-50 border border-emerald-200 px-3 py-1 font-bold text-[#047857]">
                  {product.category}
                </span>
                <span className="inline-flex items-center gap-1 font-bold text-amber-600">
                  <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
                  {ratingVal.toFixed(1)}
                  <span className="font-normal text-stone-500">({reviewsVal}+ reviews)</span>
                </span>
                <span className="text-stone-300">•</span>
                <span className="font-semibold text-stone-600">
                  Curated by{' '}
                  <Link href={`/s/${store.slug}`} className="text-[#111315] hover:underline">
                    {store.name}
                  </Link>
                </span>
              </div>

              <h1 className="mt-4 font-display text-3xl font-extrabold tracking-tight text-[#111315] sm:text-4xl leading-[1.15]">
                {product.title}
              </h1>

              {product.short_description && (
                <p className="mt-3.5 text-base leading-relaxed text-stone-600">
                  {product.short_description}
                </p>
              )}
            </div>

            {/* DEAL & PRICE ACTION CARD */}
            <div className="rounded-3xl border border-stone-200 bg-white p-6 shadow-sm space-y-5">
              <div className="flex flex-wrap items-baseline justify-between gap-4">
                <div className="flex items-baseline gap-3">
                  <span className="font-display text-4xl font-extrabold tracking-tight text-[#111315]">
                    {product.price_display || 'Check Live Price'}
                  </span>
                  {product.original_price && (
                    <span className="text-base text-stone-400 line-through">
                      {product.original_price}
                    </span>
                  )}
                  {savePct && (
                    <span className="rounded-full bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 text-xs font-bold text-[#047857]">
                      -{savePct}% OFF
                    </span>
                  )}
                </div>

                <span
                  className={`inline-flex items-center gap-1 rounded-full px-3 py-1 text-[11px] font-bold ${
                    product.price_status === 'verified'
                      ? 'bg-emerald-50 text-[#047857] border border-emerald-200'
                      : 'bg-stone-100 text-stone-600'
                  }`}
                >
                  <Clock className="h-3 w-3" />
                  {product.last_checked_at
                    ? `Checked ${new Date(product.last_checked_at).toLocaleDateString()}`
                    : 'Live merchant price'}
                </span>
              </div>

              <div className="flex flex-col sm:flex-row gap-3">
                <a
                  href={goUrl}
                  target="_blank"
                  rel="noopener noreferrer sponsored"
                  className="flex-1 inline-flex items-center justify-center gap-2 rounded-full bg-[#047857] py-4 px-6 text-sm font-bold text-white shadow-md hover:bg-[#065f46] transition-colors"
                >
                  Check Live Price &amp; Deal on {product.merchant_name}
                  <ExternalLink className="h-4 w-4" />
                </a>
                <Link
                  href={`/s/${store.slug}`}
                  className="inline-flex items-center justify-center gap-2 rounded-full border border-stone-300 bg-white py-4 px-5 text-sm font-bold text-[#111315] hover:bg-stone-50 transition-colors"
                >
                  <StoreIcon className="h-4 w-4" />
                  Visit Store
                </Link>
              </div>

              {amazonInfo?.reviewsUrl && (
                <a
                  href={amazonInfo.reviewsUrl}
                  target="_blank"
                  rel="noopener noreferrer sponsored"
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-[#047857] hover:underline"
                >
                  <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                  Read Official Verified Customer Reviews on Amazon (ASIN: {amazonInfo.asin})
                  <ExternalLink className="h-3 w-3" />
                </a>
              )}

              <p className="text-[11px] leading-relaxed text-stone-500">
                * External merchant prices and stock availability can change at any time. Always confirm the exact final price on {product.merchant_name} before completing checkout.
              </p>
            </div>

            {/* AVAILABLE / DELIVERABLE COUNTRIES */}
            <div className="rounded-2xl border border-stone-200 bg-white p-5">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-stone-700 mb-3">
                <Globe className="h-4 w-4 text-[#047857]" />
                Available / Deliverable Countries
              </div>
              <div className="flex flex-wrap gap-2">
                {(product.available_countries || ['US']).map((code) => (
                  <span
                    key={code}
                    className="rounded-full border border-emerald-200 bg-emerald-50/70 px-3.5 py-1 text-xs font-bold text-emerald-900"
                  >
                    {formatCountryLabel(code)}
                  </span>
                ))}
              </div>
            </div>

            {/* KEY HIGHLIGHTS / WHY BUYERS PICK THIS */}
            {product.benefits?.length > 0 && (
              <div className="rounded-2xl border border-stone-200 bg-white p-6">
                <h2 className="font-display text-base font-extrabold text-[#111315] mb-4">
                  Why Buyers Pick This
                </h2>
                <ul className="space-y-3">
                  {product.benefits.map((b, i) => (
                    <li key={i} className="flex items-start gap-3 text-sm text-stone-700">
                      <CheckCircle2 className="h-4 w-4 text-[#047857] shrink-0 mt-0.5" />
                      <span className="leading-relaxed">{b}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* FULL PRODUCT OVERVIEW */}
            {product.description && (
              <div className="rounded-2xl border border-stone-200 bg-white p-6">
                <h2 className="font-display text-base font-extrabold text-[#111315] mb-2.5">
                  Full Product Overview
                </h2>
                <p className="text-sm leading-relaxed text-stone-600 whitespace-pre-line">
                  {product.description}
                </p>
              </div>
            )}
          </div>
        </div>

        {/* REAL BUYER REVIEWS & COMMENTS SECTION */}
        <section className="border-t border-stone-200 pt-12">
          <div className="grid gap-8 lg:grid-cols-12 items-start">
            <div className="lg:col-span-5 rounded-3xl border border-stone-200 bg-white p-6 shadow-sm">
              <div className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-[#047857]" />
                <h2 className="font-display text-lg font-extrabold text-[#111315]">
                  Leave a Buyer Review
                </h2>
              </div>
              <p className="mt-1.5 text-xs text-stone-500">
                Share your real experience or question about this product to help other shoppers.
              </p>

              <form onSubmit={handleSubmitReview} className="mt-5 space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1.5">Your Rating</label>
                  <div className="flex items-center gap-1.5">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setReviewRating(star)}
                        className="p-1"
                        aria-label={`Rate ${star} stars`}
                      >
                        <Star
                          className={`h-5 w-5 ${
                            star <= reviewRating
                              ? 'fill-amber-400 text-amber-400'
                              : 'text-stone-300'
                          }`}
                        />
                      </button>
                    ))}
                    <span className="ml-1 text-xs font-bold text-stone-700">{reviewRating}.0 / 5</span>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">Your Name *</label>
                  <input
                    type="text"
                    required
                    minLength={2}
                    value={reviewAuthor}
                    onChange={(e) => setReviewAuthor(e.target.value)}
                    placeholder="e.g. Sarah K."
                    className="w-full rounded-xl border border-stone-300 px-3.5 py-2 text-sm focus:border-[#047857] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Your Review / Comment *
                  </label>
                  <textarea
                    rows={3}
                    required
                    minLength={8}
                    value={reviewComment}
                    onChange={(e) => setReviewComment(e.target.value)}
                    placeholder="What did you like or dislike about this product?"
                    className="w-full rounded-xl border border-stone-300 px-3.5 py-2 text-sm focus:border-[#047857] focus:outline-none"
                  />
                </div>
                {reviewNotice && (
                  <p className="rounded-xl bg-emerald-50 border border-emerald-200 px-3 py-2 text-xs font-semibold text-[#047857]">
                    {reviewNotice}
                  </p>
                )}
                <button
                  type="submit"
                  disabled={submittingReview}
                  className="w-full rounded-full bg-[#111315] py-3 text-xs font-bold text-white hover:bg-[#047857] transition-colors disabled:opacity-60"
                >
                  {submittingReview ? 'Publishing...' : 'Post Verified Review'}
                </button>
              </form>
            </div>

            <div className="lg:col-span-7 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="font-display text-2xl font-extrabold text-[#111315]">
                    Shopper Reviews &amp; Comments ({reviews.length})
                  </h2>
                  <p className="text-xs text-stone-500">
                    100% real user-submitted comments stored on LinkAisle — zero fabricated reviews.
                  </p>
                </div>
                {amazonInfo?.reviewsUrl && (
                  <a
                    href={amazonInfo.reviewsUrl}
                    target="_blank"
                    rel="noopener noreferrer sponsored"
                    className="inline-flex items-center gap-1.5 rounded-full border border-stone-300 bg-white px-4 py-2 text-xs font-bold text-[#111315] hover:border-[#047857] hover:text-[#047857] transition-colors"
                  >
                    Official Amazon Reviews <ExternalLink className="h-3.5 w-3.5" />
                  </a>
                )}
              </div>

              {reviews.length === 0 ? (
                <div className="rounded-2xl border border-stone-200 bg-white p-8 text-center text-sm text-stone-500">
                  No community reviews on LinkAisle yet. Be the first to share your experience, or check official customer reviews directly on {product.merchant_name}.
                </div>
              ) : (
                <div className="space-y-3">
                  {reviews.map((rev) => (
                    <div
                      key={rev.id}
                      className="rounded-2xl border border-stone-200 bg-white p-5 shadow-sm"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="font-display text-sm font-bold text-[#111315]">
                            {rev.author_name}
                          </span>
                          <span className="inline-flex items-center gap-0.5 text-amber-500">
                            {Array.from({ length: rev.rating }).map((_, idx) => (
                              <Star key={idx} className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                            ))}
                          </span>
                        </div>
                        <span className="text-[11px] text-stone-400">
                          {new Date(rev.created_at).toLocaleDateString()}
                        </span>
                      </div>
                      <p className="mt-2.5 text-sm leading-relaxed text-stone-700">{rev.comment}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </section>

        {/* RELATED DEALS FROM SAME STORE (4 PER ROW) */}
        {relatedProducts.length > 0 && (
          <section className="border-t border-stone-200 pt-12">
            <div className="flex items-center justify-between mb-6">
              <div>
                <p className="text-xs font-bold uppercase tracking-widest text-[#047857]">
                  More Curated Finds
                </p>
                <h2 className="mt-1 font-display text-2xl font-extrabold text-[#111315]">
                  More From {store.name}
                </h2>
              </div>
              <Link
                href={`/s/${store.slug}`}
                className="text-xs font-bold text-[#047857] hover:underline"
              >
                View Full Store →
              </Link>
            </div>
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {relatedProducts.slice(0, 4).map((rp) => (
                <article
                  key={rp.id}
                  className="group overflow-hidden rounded-2xl border border-stone-200 bg-white shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
                >
                  <Link
                    href={`/s/${store.slug}/p/${rp.slug}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block"
                  >
                    <div className="aspect-[4/3] overflow-hidden bg-stone-100">
                      {rp.image_url ? (
                        <img
                          src={rp.image_url}
                          alt={rp.title}
                          className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      ) : null}
                    </div>
                    <div className="p-4">
                      <p className="text-[10px] font-bold text-[#047857]">{rp.category}</p>
                      <h3 className="mt-1 font-display text-sm font-bold text-[#111315] line-clamp-2 group-hover:text-[#047857] transition-colors">
                        {rp.title}
                      </h3>
                      <div className="mt-2.5 flex items-baseline gap-2">
                        <span className="font-display text-base font-extrabold text-[#111315]">
                          {rp.price_display}
                        </span>
                        {rp.original_price && (
                          <span className="text-xs text-stone-400 line-through">
                            {rp.original_price}
                          </span>
                        )}
                      </div>
                    </div>
                  </Link>
                </article>
              ))}
            </div>
          </section>
        )}

        {/* AFFILIATE DISCLOSURE FOOTER */}
        <footer className="rounded-2xl border border-stone-200 bg-white p-5 text-xs text-stone-500 flex flex-wrap items-center justify-between gap-4">
          <p className="max-w-3xl leading-relaxed">{store.disclosure_text}</p>
          <Link
            href="/"
            className="inline-flex items-center gap-1.5 font-bold text-[#047857] hover:underline shrink-0"
          >
            <Sparkles className="h-3.5 w-3.5" /> Powered by {platformName}
          </Link>
        </footer>
      </main>
    </div>
  );
}
