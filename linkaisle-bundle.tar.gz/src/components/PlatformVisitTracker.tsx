'use client';

import { useEffect } from 'react';

export default function PlatformVisitTracker() {
  useEffect(() => {
    const key = 'affiliforge_platform_tracked';
    if (sessionStorage.getItem(key)) return;
    sessionStorage.setItem(key, '1');

    const params = new URLSearchParams(window.location.search);
    fetch('/api/track', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        eventType: 'platform_visit',
        referrer: document.referrer || '',
        utmSource: params.get('utm_source') || params.get('src') || '',
      }),
    }).catch(() => {});
  }, []);

  return null;
}
