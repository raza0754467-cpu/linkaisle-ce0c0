'use client';

import { useState } from 'react';
import { Calculator, AlertTriangle } from 'lucide-react';

export default function ProfitCalculator() {
  const [visitors, setVisitors] = useState(1000);
  const [ctr, setCtr] = useState(12);
  const [convRate, setConvRate] = useState(3);
  const [avgOrder, setAvgOrder] = useState(45);
  const [commissionPct, setCommissionPct] = useState(8);
  const [adSpend, setAdSpend] = useState(0);

  const outboundClicks = Math.round(visitors * (ctr / 100));
  const estSales = Math.round(outboundClicks * (convRate / 100));
  const grossCommission = estSales * avgOrder * (commissionPct / 100);
  const netProfit = grossCommission - adSpend;

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-soft sm:p-8">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-5">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600">
            <Calculator className="h-5 w-5" />
          </div>
          <div>
            <h3 className="font-display text-lg font-bold text-slate-900">
              Affiliate Revenue vs. Net Profit Simulator
            </h3>
            <p className="text-xs text-slate-500">
              Educational model to understand how clicks, conversion rates, and ad costs interact.
            </p>
          </div>
        </div>
        <span className="rounded-full bg-amber-50 px-3 py-1 text-xs font-semibold text-amber-800 border border-amber-200">
          Hypothetical Math Tool
        </span>
      </div>

      <div className="mt-6 grid gap-8 lg:grid-cols-2">
        <div className="space-y-4">
          <div>
            <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
              <span>Monthly Store Visitors</span>
              <span className="text-indigo-600">{visitors.toLocaleString()}</span>
            </div>
            <input
              type="range"
              min={100}
              max={25000}
              step={100}
              value={visitors}
              onChange={(e) => setVisitors(Number(e.target.value))}
              className="w-full accent-indigo-600"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Outbound Click Rate ({ctr}%)
              </label>
              <input
                type="range"
                min={2}
                max={40}
                value={ctr}
                onChange={(e) => setCtr(Number(e.target.value))}
                className="w-full accent-indigo-600"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Merchant Conversion ({convRate}%)
              </label>
              <input
                type="range"
                min={1}
                max={15}
                value={convRate}
                onChange={(e) => setConvRate(Number(e.target.value))}
                className="w-full accent-indigo-600"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Avg Price ($)</label>
              <input
                type="number"
                min={5}
                max={2000}
                value={avgOrder}
                onChange={(e) => setAvgOrder(Math.max(0, Number(e.target.value)))}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm font-medium focus:border-indigo-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Commission (%)</label>
              <input
                type="number"
                min={1}
                max={50}
                value={commissionPct}
                onChange={(e) => setCommissionPct(Math.max(0, Number(e.target.value)))}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm font-medium focus:border-indigo-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Ad Spend ($)</label>
              <input
                type="number"
                min={0}
                max={10000}
                value={adSpend}
                onChange={(e) => setAdSpend(Math.max(0, Number(e.target.value)))}
                className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm font-medium focus:border-indigo-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        <div className="flex flex-col justify-between rounded-xl bg-slate-900 p-6 text-white">
          <div className="grid grid-cols-2 gap-4">
            <div className="rounded-lg bg-white/10 p-3.5">
              <p className="text-xs text-slate-300">Est. Outbound Clicks</p>
              <p className="mt-1 font-display text-2xl font-bold">{outboundClicks.toLocaleString()}</p>
            </div>
            <div className="rounded-lg bg-white/10 p-3.5">
              <p className="text-xs text-slate-300">Est. Qualifying Sales</p>
              <p className="mt-1 font-display text-2xl font-bold">{estSales.toLocaleString()}</p>
            </div>
            <div className="rounded-lg bg-white/10 p-3.5">
              <p className="text-xs text-slate-300">Gross Commission</p>
              <p className="mt-1 font-display text-2xl font-bold text-indigo-300">
                ${grossCommission.toFixed(2)}
              </p>
            </div>
            <div className="rounded-lg bg-white/10 p-3.5">
              <p className="text-xs text-slate-300">Hypothetical Net Result</p>
              <p
                className={`mt-1 font-display text-2xl font-bold ${
                  netProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {netProfit >= 0 ? `+$${netProfit.toFixed(2)}` : `-$${Math.abs(netProfit).toFixed(2)}`}
              </p>
            </div>
          </div>

          <div className="mt-5 flex items-start gap-2 rounded-lg bg-amber-500/10 border border-amber-400/20 p-3 text-xs text-amber-200">
            <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5 text-amber-400" />
            <p>
              Illustrative calculation only — not guaranteed income. Actual commissions depend on
              merchant approval, refunds, attribution windows, and traffic quality.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
