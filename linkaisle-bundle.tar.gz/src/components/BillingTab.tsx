'use client';

import { useCallback, useEffect, useState } from 'react';
import {
  CheckCircle2,
  Clock,
  CreditCard,
  Crown,
  Send,
  ShieldCheck,
  XCircle,
} from 'lucide-react';
import { PlanLimits, UpgradeRequest, UserPlan } from '@/lib/types';

export default function BillingTab({
  onNotify,
}: {
  onNotify: (type: 'success' | 'error', msg: string) => void;
}) {
  const [loading, setLoading] = useState(true);
  const [currentPlan, setCurrentPlan] = useState<UserPlan>('free');
  const [planLimits, setPlanLimits] = useState<PlanLimits | null>(null);
  const [paymentInstructions, setPaymentInstructions] = useState('');
  const [requests, setRequests] = useState<UpgradeRequest[]>([]);

  const [requestedPlan, setRequestedPlan] = useState<'starter' | 'pro'>('starter');
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');
  const [paymentMethod, setPaymentMethod] = useState('Payoneer');
  const [transactionRef, setTransactionRef] = useState('');
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const loadBilling = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/billing/requests');
      if (res.ok) {
        const d = await res.json();
        setCurrentPlan(d.currentPlan);
        setPlanLimits(d.planLimits);
        setPaymentInstructions(d.paymentInstructions || '');
        setRequests(d.requests || []);
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadBilling();
  }, [loadBilling]);

  async function handleSubmitRequest(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await fetch('/api/billing/requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          requested_plan: requestedPlan,
          billing_cycle: billingCycle,
          payment_method: paymentMethod,
          transaction_ref: transactionRef,
          notes,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        onNotify('error', data.error || 'Failed to submit upgrade request');
        return;
      }
      setTransactionRef('');
      setNotes('');
      onNotify('success', 'Upgrade request submitted! Pending owner approval.');
      loadBilling();
    } finally {
      setSubmitting(false);
    }
  }

  if (loading || !planLimits) {
    return (
      <div className="rounded-2xl border border-slate-200 bg-white p-10 text-center text-sm text-slate-500">
        Loading your subscription & billing details...
      </div>
    );
  }

  const chosenMonthly = planLimits[requestedPlan].price;
  const computedPrice =
    billingCycle === 'yearly' ? (chosenMonthly * 12 * 0.8).toFixed(2) : chosenMonthly.toFixed(2);

  return (
    <div className="space-y-6">
      {/* CURRENT PLAN BANNER */}
      <div className="rounded-2xl border border-stone-200 bg-white p-6 text-[#111315] shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-50 border border-emerald-200 text-[#047857]">
              <Crown className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-[#047857]">
                Active Subscription Tier
              </p>
              <h2 className="font-display text-2xl font-extrabold text-[#111315]">
                {planLimits[currentPlan].label} Plan (${planLimits[currentPlan].price}/mo)
              </h2>
            </div>
          </div>
          <div className="flex flex-wrap gap-2.5 text-xs">
            <span className="rounded-lg bg-[#FAFAF9] border border-stone-200 px-3 py-1.5 font-semibold text-stone-700">
              Stores: <strong className="text-[#111315]">{planLimits[currentPlan].maxStores}</strong>
            </span>
            <span className="rounded-lg bg-[#FAFAF9] border border-stone-200 px-3 py-1.5 font-semibold text-stone-700">
              Products:{' '}
              <strong className="text-[#111315]">
                {planLimits[currentPlan].maxProducts >= 9999
                  ? 'Unlimited'
                  : planLimits[currentPlan].maxProducts}
              </strong>
            </span>
            <span className="rounded-lg bg-[#FAFAF9] border border-stone-200 px-3 py-1.5 font-semibold text-stone-700">
              SEO Posts:{' '}
              <strong className="text-[#111315]">
                {planLimits[currentPlan].maxPosts >= 9999
                  ? 'Unlimited'
                  : planLimits[currentPlan].maxPosts}
              </strong>
            </span>
          </div>
        </div>
      </div>

      {/* UPGRADE FORM */}
      <div className="grid gap-6 lg:grid-cols-12">
        <div className="lg:col-span-7 rounded-2xl border border-stone-200 bg-white p-6 shadow-sm">
          <div className="flex items-center gap-2 mb-4">
            <CreditCard className="h-5 w-5 text-[#047857]" />
            <h3 className="font-display text-lg font-bold text-[#111315]">
              Request Plan Upgrade
            </h3>
          </div>

          <div className="rounded-xl bg-amber-50 border border-amber-200 p-4 text-xs text-amber-950 leading-relaxed mb-5">
            <p className="font-bold mb-1">Payment Instructions:</p>
            <p>{paymentInstructions}</p>
          </div>

          <form onSubmit={handleSubmitRequest} className="space-y-4">
            <div className="grid gap-3 sm:grid-cols-2">
              {(['starter', 'pro'] as const).map((planKey) => {
                const tier = planLimits[planKey];
                const active = requestedPlan === planKey;
                return (
                  <button
                    key={planKey}
                    type="button"
                    onClick={() => setRequestedPlan(planKey)}
                    className={`rounded-xl border p-4 text-left transition-all ${
                      active
                        ? 'border-[#047857] bg-emerald-50/70 ring-2 ring-emerald-600/20'
                        : 'border-stone-200 hover:border-stone-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-display text-base font-extrabold text-[#111315]">
                        {tier.label}
                      </span>
                      <span className="font-display text-lg font-extrabold text-[#047857]">
                        ${tier.price}/mo
                      </span>
                    </div>
                    <p className="mt-1.5 text-xs text-slate-600">
                      Up to {tier.maxStores} stores ·{' '}
                      {tier.maxProducts >= 9999 ? 'Unlimited' : tier.maxProducts} products
                    </p>
                  </button>
                );
              })}
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Billing Cycle
                </label>
                <select
                  value={billingCycle}
                  onChange={(e) => setBillingCycle(e.target.value as 'monthly' | 'yearly')}
                  className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm"
                >
                  <option value="monthly">Monthly (${chosenMonthly}/mo)</option>
                  <option value="yearly">
                    Yearly — Save 20% (${(chosenMonthly * 12 * 0.8).toFixed(2)}/yr)
                  </option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Payment Method
                </label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm"
                >
                  <option value="Payoneer">Payoneer (International)</option>
                  <option value="Bank Transfer">Bank Transfer (IBAN / Wire)</option>
                  <option value="Easypaisa / JazzCash">Easypaisa / JazzCash (Pakistan)</option>
                  <option value="Card / Stripe">Card / Stripe</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Transaction ID / Payment Reference *
              </label>
              <input
                type="text"
                required
                value={transactionRef}
                onChange={(e) => setTransactionRef(e.target.value)}
                placeholder="e.g. TXN-98451234 or Payoneer Ref #"
                className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Optional Note (Sender Name / Account Email)
              </label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g. Sent from Ali Raza account"
                className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm"
              />
            </div>

            <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl bg-slate-50 border border-slate-200 p-4">
              <div>
                <p className="text-xs text-slate-500">Total Payable</p>
                <p className="font-display text-2xl font-extrabold text-slate-900">
                  ${computedPrice} <span className="text-xs font-normal text-slate-500">USD</span>
                </p>
              </div>
              <button
                type="submit"
                disabled={submitting}
                className="inline-flex items-center gap-2 rounded-xl bg-[#111315] px-6 py-3 text-sm font-bold text-white shadow-sm hover:bg-[#047857] transition-colors disabled:opacity-60"
              >
                <Send className="h-4 w-4" />
                {submitting ? 'Submitting...' : 'Submit Upgrade Request'}
              </button>
            </div>
          </form>
        </div>

        {/* REQUEST HISTORY */}
        <div className="lg:col-span-5 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
          <div className="flex items-center gap-2 mb-4">
            <ShieldCheck className="h-5 w-5 text-emerald-600" />
            <h3 className="font-display text-base font-bold text-slate-900">
              Your Upgrade History ({requests.length})
            </h3>
          </div>

          {requests.length === 0 ? (
            <p className="py-10 text-center text-xs text-slate-400">
              No upgrade requests submitted yet. Once submitted, track owner verification status here.
            </p>
          ) : (
            <div className="space-y-3">
              {requests.map((r) => (
                <div
                  key={r.id}
                  className="rounded-xl border border-slate-200 bg-slate-50/70 p-4 text-xs space-y-1.5"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-display text-sm font-extrabold uppercase text-slate-900">
                      {r.requested_plan} ({r.billing_cycle})
                    </span>
                    <span
                      className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[10px] font-bold uppercase ${
                        r.status === 'approved'
                          ? 'bg-emerald-100 text-emerald-800'
                          : r.status === 'rejected'
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {r.status === 'approved' && <CheckCircle2 className="h-3 w-3" />}
                      {r.status === 'rejected' && <XCircle className="h-3 w-3" />}
                      {r.status === 'pending' && <Clock className="h-3 w-3" />}
                      {r.status}
                    </span>
                  </div>
                  <p className="text-slate-600">
                    <strong>${r.amount_usd}</strong> via {r.payment_method} · Ref:{' '}
                    <code className="bg-white px-1 rounded font-mono">{r.transaction_ref}</code>
                  </p>
                  {r.admin_note && (
                    <p className="text-indigo-700 bg-indigo-50 rounded px-2 py-1">
                      Owner Note: {r.admin_note}
                    </p>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
