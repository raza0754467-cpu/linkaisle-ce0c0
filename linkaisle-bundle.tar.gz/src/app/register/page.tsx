'use client';

import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { Suspense, useState } from 'react';
import { CheckCircle2, Rocket, ShoppingBag } from 'lucide-react';
import { STORE_TEMPLATES } from '@/lib/types';

function GoogleLogo() {
  return (
    <svg className="h-4 w-4 shrink-0" viewBox="0 0 24 24" aria-hidden="true">
      <path
        fill="#4285F4"
        d="M23.49 12.27c0-.79-.07-1.55-.2-2.27H12v4.3h6.44a5.5 5.5 0 0 1-2.39 3.61v3h3.87c2.26-2.08 3.57-5.15 3.57-8.64Z"
      />
      <path
        fill="#34A853"
        d="M12 24c3.24 0 5.95-1.07 7.93-2.91l-3.87-3c-1.07.72-2.44 1.15-4.06 1.15-3.12 0-5.77-2.11-6.71-4.95H1.29v3.1A12 12 0 0 0 12 24Z"
      />
      <path
        fill="#FBBC05"
        d="M5.29 14.29A7.2 7.2 0 0 1 4.91 12c0-.79.14-1.57.38-2.29V6.61H1.29a12 12 0 0 0 0 10.78l4-3.1Z"
      />
      <path
        fill="#EA4335"
        d="M12 4.76c1.76 0 3.34.61 4.59 1.8l3.44-3.44C17.95 1.19 15.24 0 12 0A12 12 0 0 0 1.29 6.61l4 3.1c.94-2.84 3.59-4.95 6.71-4.95Z"
      />
    </svg>
  );
}

function RegisterForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const initialTemplate = searchParams.get('template') || 'kitchen';

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [storeName, setStoreName] = useState('');
  const [template, setTemplate] = useState(initialTemplate);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password, storeName, template }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Registration failed');
        setLoading(false);
        return;
      }
      router.push('/dashboard');
      router.refresh();
    } catch {
      setError('Network error. Please try again.');
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen grid lg:grid-cols-2 bg-[#FAFAF9]">
      <div className="hidden lg:flex flex-col justify-between bg-[#111315] p-12 text-white">
        <Link href="/" className="flex items-center gap-2.5">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#047857] text-white">
            <ShoppingBag className="h-5 w-5" />
          </div>
          <span className="font-display text-xl font-extrabold">LinkAisle</span>
        </Link>

        <div className="max-w-md space-y-6">
          <h1 className="font-display text-4xl font-extrabold leading-tight">
            Launch Your Curated Affiliate Store in 60 Seconds.
          </h1>
          <ul className="space-y-3 text-sm text-stone-300">
            <li className="flex items-center gap-2.5">
              <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
              Free storefront with your own public LinkAisle URL — no domain needed
            </li>
            <li className="flex items-center gap-2.5">
              <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
              5 bespoke light themes + custom colors &amp; logo upload
            </li>
            <li className="flex items-center gap-2.5">
              <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
              AI Product Writer, AI Price &amp; Link Reviser, SEO Guides &amp; Real Analytics
            </li>
            <li className="flex items-center gap-2.5">
              <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
              Complete access to Affiliate Marketing Academy
            </li>
          </ul>
        </div>

        <p className="text-xs text-stone-400">
          Zero credit card required · Use your own approved affiliate links
        </p>
      </div>

      <div className="flex items-center justify-center p-6 sm:p-10">
        <div className="w-full max-w-md">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-[#047857] font-bold text-sm lg:hidden mb-6"
          >
            <ShoppingBag className="h-4 w-4" /> LinkAisle
          </Link>

          <h2 className="font-display text-2xl font-extrabold text-[#111315]">
            Create your free account
          </h2>
          <p className="mt-1.5 text-sm text-stone-500">
            Already have an account?{' '}
            <Link href="/login" className="font-semibold text-[#047857] hover:underline">
              Sign in
            </Link>
          </p>

          <div className="mt-5">
            <a
              href="/api/auth/google"
              className="w-full inline-flex items-center justify-center gap-2.5 rounded-xl border border-stone-300 bg-white px-4 py-2.5 text-sm font-bold text-[#111315] shadow-sm hover:bg-stone-50 transition-colors"
            >
              <GoogleLogo />
              Continue with Google
            </a>
          </div>

          <div className="my-4 flex items-center gap-3 text-xs text-stone-400">
            <div className="h-px flex-1 bg-stone-200" />
            <span>or create with email</span>
            <div className="h-px flex-1 bg-stone-200" />
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div className="rounded-xl bg-rose-50 border border-rose-200 px-4 py-3 text-xs text-rose-700">
                {error}
              </div>
            )}

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="reg-name" className="block text-xs font-semibold text-stone-700 mb-1">
                  Full Name
                </label>
                <input
                  id="reg-name"
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Alex Morgan"
                  className="w-full rounded-xl border border-stone-300 bg-white px-3.5 py-2.5 text-sm focus:border-[#047857] focus:outline-none"
                />
              </div>
              <div>
                <label htmlFor="reg-email" className="block text-xs font-semibold text-stone-700 mb-1">
                  Email Address
                </label>
                <input
                  id="reg-email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full rounded-xl border border-stone-300 bg-white px-3.5 py-2.5 text-sm focus:border-[#047857] focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label htmlFor="reg-password" className="block text-xs font-semibold text-stone-700 mb-1">
                Password (min 6 characters)
              </label>
              <input
                id="reg-password"
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Create a secure password"
                className="w-full rounded-xl border border-stone-300 bg-white px-3.5 py-2.5 text-sm focus:border-[#047857] focus:outline-none"
              />
            </div>

            <div className="rounded-2xl border border-stone-200 bg-white p-4 space-y-3">
              <p className="text-xs font-bold uppercase tracking-wider text-[#047857]">
                Instant Storefront Setup
              </p>
              <div>
                <label htmlFor="reg-store" className="block text-xs font-semibold text-stone-700 mb-1">
                  First Store Name
                </label>
                <input
                  id="reg-store"
                  type="text"
                  required
                  value={storeName}
                  onChange={(e) => setStoreName(e.target.value)}
                  placeholder="e.g. Daily Tech Picks"
                  className="w-full rounded-xl border border-stone-300 bg-[#FAFAF9] px-3.5 py-2 text-sm focus:bg-white focus:border-[#047857] focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  Choose Starting Theme
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {STORE_TEMPLATES.map((t) => (
                    <button
                      type="button"
                      key={t.id}
                      onClick={() => setTemplate(t.id)}
                      className={`rounded-lg border p-2 text-left text-xs transition-all ${
                        template === t.id
                          ? 'border-[#047857] bg-emerald-50 text-[#047857] font-bold ring-1 ring-[#047857]'
                          : 'border-stone-200 hover:border-stone-300 text-stone-700'
                      }`}
                    >
                      <div className="flex items-center gap-1.5">
                        <span
                          className="h-2.5 w-2.5 rounded-full shrink-0"
                          style={{ backgroundColor: t.defaultPrimary }}
                        />
                        <span className="truncate">{t.niche}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-[#111315] py-3 text-sm font-bold text-white shadow-sm hover:bg-[#047857] disabled:opacity-60 transition-colors"
            >
              <Rocket className="h-4 w-4" />
              {loading ? 'Creating Your Store...' : 'Launch My Free Storefront'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default function RegisterPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-[#FAFAF9]" />}>
      <RegisterForm />
    </Suspense>
  );
}
