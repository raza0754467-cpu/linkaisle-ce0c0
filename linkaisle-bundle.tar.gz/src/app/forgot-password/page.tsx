'use client';

import Link from 'next/link';
import { useState } from 'react';
import { ArrowLeft, CheckCircle2, Mail, ShoppingBag } from 'lucide-react';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [devResetUrl, setDevResetUrl] = useState('');

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setMessage('');
    setDevResetUrl('');
    setLoading(true);
    try {
      const res = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Could not process request.');
        return;
      }
      setMessage(data.message);
      if (data.devResetUrl) setDevResetUrl(data.devResetUrl);
    } catch {
      setError('Network error. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-[#FAFAF9] flex items-center justify-center p-6">
      <div className="w-full max-w-md rounded-3xl border border-stone-200 bg-white p-8 shadow-sm">
        <Link href="/" className="inline-flex items-center gap-2 text-[#111315] font-display font-extrabold">
          <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-[#047857] text-white">
            <ShoppingBag className="h-4 w-4" />
          </span>
          LinkAisle
        </Link>

        <h1 className="mt-6 font-display text-2xl font-extrabold text-[#111315]">
          Reset your password
        </h1>
        <p className="mt-1.5 text-sm text-stone-500">
          Enter the email address associated with your account and we&apos;ll send a secure reset link.
        </p>

        {message ? (
          <div className="mt-6 rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-xs leading-relaxed text-emerald-950 space-y-2">
            <div className="flex items-center gap-2 font-bold text-[#047857]">
              <CheckCircle2 className="h-4 w-4 shrink-0" />
              Reset Link Ready
            </div>
            <p>{message}</p>
            {devResetUrl && (
              <Link
                href={devResetUrl}
                className="inline-block rounded-lg bg-[#047857] px-3 py-1.5 font-bold text-white hover:bg-emerald-800"
              >
                Open Reset Password Link →
              </Link>
            )}
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="mt-6 space-y-4">
            {error && (
              <div className="rounded-xl bg-rose-50 border border-rose-200 px-4 py-3 text-xs text-rose-700">
                {error}
              </div>
            )}
            <div>
              <label htmlFor="forgot-email" className="block text-xs font-semibold text-stone-700 mb-1.5">
                Email Address
              </label>
              <div className="relative">
                <Mail className="pointer-events-none absolute left-3.5 top-3 h-4 w-4 text-stone-400" />
                <input
                  id="forgot-email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full rounded-xl border border-stone-300 bg-white py-2.5 pl-10 pr-4 text-sm focus:border-[#047857] focus:outline-none"
                />
              </div>
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-xl bg-[#111315] py-3 text-sm font-bold text-white hover:bg-[#047857] disabled:opacity-60 transition-colors"
            >
              {loading ? 'Sending...' : 'Send Reset Link'}
            </button>
          </form>
        )}

        <Link
          href="/login"
          className="mt-6 inline-flex items-center gap-1.5 text-xs font-semibold text-stone-600 hover:text-[#111315]"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> Back to Sign In
        </Link>
      </div>
    </div>
  );
}
