import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import { getDb, getPlatformSettings } from '@/lib/db';
import { AcademyLesson } from '@/lib/types';
import Navbar from '@/components/Navbar';
import AcademyLessonClient from '@/components/AcademyLessonClient';
import PlatformAdSlot from '@/components/PlatformAdSlot';

export const dynamic = 'force-dynamic';

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const db = getDb();
  const lesson = db
    .prepare('SELECT title, summary FROM academy_lessons WHERE slug = ? AND is_published = 1')
    .get(slug) as { title: string; summary: string } | undefined;

  if (!lesson) return { title: 'Lesson Not Found' };
  return {
    title: `${lesson.title} — Affiliate Academy`,
    description: lesson.summary,
    openGraph: { title: lesson.title, description: lesson.summary, type: 'article' },
  };
}

export default async function LessonPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const user = await getCurrentUser();
  const settings = getPlatformSettings();
  const db = getDb();

  const rawLessons = db
    .prepare(
      'SELECT * FROM academy_lessons WHERE is_published = 1 ORDER BY module_number ASC, order_index ASC'
    )
    .all() as unknown as AcademyLesson[];

  const lessons = rawLessons.map((l) => ({ ...l }));
  const idx = lessons.findIndex((l) => l.slug === slug);
  if (idx === -1) notFound();

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar user={user} platformName={settings.platform_name} />
      <div className="mx-auto max-w-4xl px-4 pt-6 sm:px-6 lg:px-8">
        <PlatformAdSlot monetization={settings.monetization} />
      </div>
      <AcademyLessonClient
        lesson={lessons[idx]}
        prevLesson={idx > 0 ? lessons[idx - 1] : null}
        nextLesson={idx < lessons.length - 1 ? lessons[idx + 1] : null}
        isLoggedIn={Boolean(user)}
      />
    </div>
  );
}
