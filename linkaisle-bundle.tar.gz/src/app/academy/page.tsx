import type { Metadata } from 'next';
import { getCurrentUser } from '@/lib/auth';
import { getDb, getPlatformSettings } from '@/lib/db';
import { AcademyLesson } from '@/lib/types';
import Navbar from '@/components/Navbar';
import AcademyListClient from '@/components/AcademyListClient';
import PlatformAdSlot from '@/components/PlatformAdSlot';

export const dynamic = 'force-dynamic';

export const metadata: Metadata = {
  title: 'Affiliate Academy — LinkAisle',
  description:
    'Free step-by-step affiliate marketing curriculum covering Amazon Associates, Impact.com, storefronts, free short-video traffic, SEO blogging, and profit tracking.',
};

export default async function AcademyPage() {
  const user = await getCurrentUser();
  const settings = getPlatformSettings();
  const db = getDb();

  const rawLessons = db
    .prepare(
      'SELECT * FROM academy_lessons WHERE is_published = 1 ORDER BY module_number ASC, order_index ASC'
    )
    .all() as unknown as AcademyLesson[];

  const lessons = rawLessons.map((l) => ({ ...l }));

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar user={user} platformName={settings.platform_name} />
      <AcademyListClient
        lessons={lessons}
        platformName={settings.platform_name}
        isLoggedIn={Boolean(user)}
      />
      <div className="mx-auto max-w-6xl px-4 pb-12 sm:px-6 lg:px-8">
        <PlatformAdSlot monetization={settings.monetization} />
      </div>
    </div>
  );
}
