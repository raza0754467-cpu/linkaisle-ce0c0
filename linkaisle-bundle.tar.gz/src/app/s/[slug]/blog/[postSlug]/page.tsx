import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { ArrowLeft, ExternalLink, ShoppingBag } from 'lucide-react';
import { getDb, getPlatformSettings } from '@/lib/db';
import { BlogPost, Product, Store } from '@/lib/types';
import MarkdownRenderer from '@/components/MarkdownRenderer';
import PostViewTracker from '@/components/PostViewTracker';

export const dynamic = 'force-dynamic';

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string; postSlug: string }>;
}): Promise<Metadata> {
  const { slug, postSlug } = await params;
  const db = getDb();
  const row = db
    .prepare(
      `SELECT b.title, b.excerpt, b.seo_title, b.seo_description, b.cover_image, s.name as store_name
       FROM blog_posts b
       JOIN stores s ON s.id = b.store_id
       WHERE s.slug = ? AND b.slug = ? AND b.status = 'published' AND s.is_published = 1 AND s.is_suspended = 0`
    )
    .get(slug, postSlug) as
    | {
        title: string;
        excerpt: string;
        seo_title: string;
        seo_description: string;
        cover_image: string;
        store_name: string;
      }
    | undefined;

  if (!row) return { title: 'Guide Not Found' };
  const title = row.seo_title || `${row.title} | ${row.store_name}`;
  const description = row.seo_description || row.excerpt || row.title;

  return {
    title,
    description,
    openGraph: {
      title,
      description,
      type: 'article',
      ...(row.cover_image ? { images: [{ url: row.cover_image }] } : {}),
    },
    twitter: {
      card: 'summary_large_image',
      title,
      description,
    },
  };
}

export default async function StoreBlogPostPage({
  params,
}: {
  params: Promise<{ slug: string; postSlug: string }>;
}) {
  const { slug, postSlug } = await params;
  const db = getDb();
  const settings = getPlatformSettings();

  const rawStore = db
    .prepare('SELECT * FROM stores WHERE slug = ? AND is_published = 1 AND is_suspended = 0')
    .get(slug) as Store | undefined;
  if (!rawStore) notFound();
  const store: Store = { ...rawStore };

  const rawPost = db
    .prepare(
      `SELECT * FROM blog_posts WHERE store_id = ? AND slug = ? AND status = 'published'`
    )
    .get(store.id, postSlug) as (Omit<BlogPost, 'featured_product_ids'> & { featured_product_ids: string }) | undefined;

  if (!rawPost) notFound();

  const featuredIds: string[] = (() => {
    try {
      return JSON.parse(rawPost.featured_product_ids || '[]');
    } catch {
      return [];
    }
  })();

  let embeddedProducts: Product[] = [];
  if (featuredIds.length > 0) {
    const placeholders = featuredIds.map(() => '?').join(',');
    const rows = db
      .prepare(
        `SELECT * FROM products WHERE store_id = ? AND status = 'published' AND id IN (${placeholders})`
      )
      .all(store.id, ...featuredIds) as unknown as (Omit<Product, 'benefits' | 'available_countries'> & {
      benefits: string;
      available_countries?: string;
    })[];
    embeddedProducts = rows.map((p) => ({
      ...p,
      benefits: (() => {
        try {
          return JSON.parse(p.benefits || '[]');
        } catch {
          return [];
        }
      })(),
      available_countries: (() => {
        try {
          return JSON.parse(p.available_countries || '["US"]');
        } catch {
          return ['US'];
        }
      })(),
    }));
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <PostViewTracker storeId={store.id} postId={rawPost.id} />
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-4xl items-center justify-between px-4 py-4 sm:px-6">
          <Link
            href={`/s/${store.slug}`}
            className="inline-flex items-center gap-2 text-sm font-bold text-slate-800 hover:text-indigo-600"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to {store.name}
          </Link>
          <span className="text-xs font-semibold text-slate-400">{rawPost.category}</span>
        </div>
      </header>

      <main className="mx-auto max-w-4xl px-4 py-10 sm:px-6">
        <article className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-soft">
          {rawPost.cover_image && (
            <img
              src={rawPost.cover_image}
              alt={rawPost.title}
              className="h-64 w-full object-cover sm:h-80"
            />
          )}
          <div className="p-6 sm:p-10">
            <span
              className="inline-block rounded-full px-3 py-1 text-xs font-bold text-white"
              style={{ backgroundColor: store.primary_color }}
            >
              {rawPost.category}
            </span>
            <h1 className="mt-4 font-display text-2xl font-extrabold text-slate-900 sm:text-4xl">
              {rawPost.title}
            </h1>
            {rawPost.excerpt && (
              <p className="mt-3 text-base text-slate-600 border-b border-slate-100 pb-6">
                {rawPost.excerpt}
              </p>
            )}

            <div className="mt-6">
              <MarkdownRenderer content={rawPost.content} />
            </div>

            {embeddedProducts.length > 0 && (
              <div className="mt-10 border-t border-slate-200 pt-8">
                <h2 className="font-display text-xl font-extrabold text-slate-900 mb-4 flex items-center gap-2">
                  <ShoppingBag className="h-5 w-5" style={{ color: store.primary_color }} />
                  Products Mentioned in This Guide
                </h2>
                <div className="grid gap-4 sm:grid-cols-2">
                  {embeddedProducts.map((product) => (
                    <div
                      key={product.id}
                      className="flex gap-4 rounded-xl border border-slate-200 bg-slate-50 p-4"
                    >
                      {product.image_url && (
                        <img
                          src={product.image_url}
                          alt={product.title}
                          className="h-20 w-20 rounded-lg object-cover shrink-0"
                        />
                      )}
                      <div className="flex flex-1 flex-col justify-between">
                        <div>
                          <p className="font-display text-sm font-bold text-slate-900 leading-snug">
                            {product.title}
                          </p>
                          <p className="mt-1 text-sm font-extrabold" style={{ color: store.primary_color }}>
                            {product.price_display}
                          </p>
                        </div>
                        <a
                          href={`/api/go/${product.id}`}
                          target="_blank"
                          rel="noopener noreferrer sponsored"
                          className="mt-2 inline-flex w-fit items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-bold text-white"
                          style={{ backgroundColor: store.primary_color }}
                        >
                          View Deal <ExternalLink className="h-3 w-3" />
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="mt-10 rounded-xl bg-slate-100 p-4 text-xs text-slate-600">
              {store.disclosure_text}
            </div>
          </div>
        </article>

        <div className="mt-8 text-center text-xs text-slate-500">
          Published on{' '}
          <Link href={`/s/${store.slug}`} className="font-semibold underline">
            {store.name}
          </Link>{' '}
          · Powered by{' '}
          <Link href="/" className="font-semibold text-indigo-600 hover:underline">
            {settings.platform_name}
          </Link>
        </div>
      </main>
    </div>
  );
}
