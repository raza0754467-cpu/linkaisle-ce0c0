import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { ShieldAlert, EyeOff } from 'lucide-react';
import { getDb, getPlatformSettings } from '@/lib/db';
import { BlogPost, Product, Store } from '@/lib/types';
import StorefrontClient from '@/components/StorefrontClient';

export const dynamic = 'force-dynamic';

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const db = getDb();
  const store = db
    .prepare('SELECT name, tagline, description, hero_title, logo_url FROM stores WHERE slug = ? AND is_published = 1 AND is_suspended = 0')
    .get(slug) as
    | { name: string; tagline: string; description: string; hero_title: string; logo_url: string }
    | undefined;

  if (!store) return { title: 'Storefront Not Found' };

  const title = `${store.name} — ${store.tagline || 'Curated Affiliate Deals'}`;
  const description = store.description || store.tagline || `Explore curated affiliate finds on ${store.name}.`;

  return {
    title,
    description,
    openGraph: {
      title,
      description,
      type: 'website',
      ...(store.logo_url ? { images: [{ url: store.logo_url }] } : {}),
    },
    twitter: {
      card: 'summary_large_image',
      title,
      description,
    },
  };
}

export default async function PublicStorePage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ preview?: string }>;
}) {
  const { slug } = await params;
  const sp = await searchParams;
  const db = getDb();
  const settings = getPlatformSettings();

  const rawStore = db.prepare('SELECT * FROM stores WHERE slug = ?').get(slug) as Store | undefined;
  if (!rawStore) notFound();
  const store: Store = { ...rawStore };

  if (store.is_suspended) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 p-6">
        <div className="max-w-md rounded-2xl border border-rose-200 bg-white p-8 text-center shadow-soft">
          <ShieldAlert className="mx-auto h-12 w-12 text-rose-500" />
          <h1 className="mt-4 font-display text-xl font-bold text-slate-900">
            Storefront Temporarily Suspended
          </h1>
          <p className="mt-2 text-sm text-slate-600">
            This storefront has been paused by platform moderation for policy review.
          </p>
          <Link
            href="/"
            className="mt-6 inline-block rounded-xl bg-slate-900 px-5 py-2.5 text-sm font-semibold text-white"
          >
            Return to {settings.platform_name}
          </Link>
        </div>
      </div>
    );
  }

  if (!store.is_published) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 p-6">
        <div className="max-w-md rounded-2xl border border-slate-200 bg-white p-8 text-center shadow-soft">
          <EyeOff className="mx-auto h-12 w-12 text-slate-400" />
          <h1 className="mt-4 font-display text-xl font-bold text-slate-900">
            Storefront Is Currently in Draft Mode
          </h1>
          <p className="mt-2 text-sm text-slate-600">
            The creator is still preparing products for <strong>{store.name}</strong>. Check back soon!
          </p>
          <Link
            href="/"
            className="mt-6 inline-block rounded-xl bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white"
          >
            Explore {settings.platform_name}
          </Link>
        </div>
      </div>
    );
  }

  const rawProducts = db
    .prepare(
      `SELECT * FROM products WHERE store_id = ? AND status = 'published' ORDER BY is_featured DESC, created_at DESC`
    )
    .all(store.id) as unknown as (Omit<Product, 'benefits' | 'available_countries'> & {
    benefits: string;
    available_countries?: string;
  })[];

  const products: Product[] = rawProducts.map((p) => ({
    ...p,
    benefits: (() => {
      try {
        return JSON.parse(p.benefits || '[]');
      } catch {
        return [];
      }
    })(),
    available_countries: (() => {
      try {
        const arr = JSON.parse(p.available_countries || '["US"]');
        return Array.isArray(arr) && arr.length ? arr : ['US'];
      } catch {
        return ['US'];
      }
    })(),
  }));

  const rawPosts = db
    .prepare(
      `SELECT * FROM blog_posts WHERE store_id = ? AND status = 'published' ORDER BY created_at DESC`
    )
    .all(store.id) as (Omit<BlogPost, 'featured_product_ids'> & { featured_product_ids: string })[];

  const posts: BlogPost[] = rawPosts.map((p) => ({
    ...p,
    featured_product_ids: (() => {
      try {
        return JSON.parse(p.featured_product_ids || '[]');
      } catch {
        return [];
      }
    })(),
  }));

  return (
    <StorefrontClient
      store={store}
      products={products}
      posts={posts}
      platformName={settings.platform_name}
      previewTemplate={sp.preview || null}
    />
  );
}
