import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { getDb, getPlatformSettings } from '@/lib/db';
import { Product, Store } from '@/lib/types';
import ProductDetailClient from '@/components/ProductDetailClient';

export const dynamic = 'force-dynamic';

function parseProduct(raw: Record<string, unknown>): Product {
  return {
    ...(raw as unknown as Product),
    benefits: (() => {
      try {
        return JSON.parse(String(raw.benefits || '[]'));
      } catch {
        return [];
      }
    })(),
    available_countries: (() => {
      try {
        const arr = JSON.parse(String(raw.available_countries || '["US"]'));
        return Array.isArray(arr) && arr.length ? arr : ['US'];
      } catch {
        return ['US'];
      }
    })(),
  };
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string; productSlug: string }>;
}): Promise<Metadata> {
  const { slug, productSlug } = await params;
  const db = getDb();
  const row = db
    .prepare(
      `SELECT p.title, p.price_display, p.short_description, p.image_url, s.name as store_name
       FROM products p
       JOIN stores s ON s.id = p.store_id
       WHERE s.slug = ? AND p.slug = ? AND p.status = 'published' AND s.is_published = 1 AND s.is_suspended = 0`
    )
    .get(slug, productSlug) as
    | { title: string; price_display: string; short_description: string; image_url: string; store_name: string }
    | undefined;

  if (!row) return { title: 'Product Not Found' };
  const title = `${row.title} (${row.price_display}) — ${row.store_name}`;
  const description = row.short_description || `Inspect deal details for ${row.title} on ${row.store_name}.`;

  return {
    title,
    description,
    openGraph: {
      title,
      description,
      ...(row.image_url ? { images: [{ url: row.image_url }] } : {}),
    },
  };
}

export default async function ProductDetailPage({
  params,
}: {
  params: Promise<{ slug: string; productSlug: string }>;
}) {
  const { slug, productSlug } = await params;
  const db = getDb();
  const settings = getPlatformSettings();

  const rawStore = db
    .prepare('SELECT * FROM stores WHERE slug = ? AND is_published = 1 AND is_suspended = 0')
    .get(slug) as Store | undefined;
  if (!rawStore) notFound();
  const store: Store = { ...rawStore };

  const rawProduct = db
    .prepare(`SELECT * FROM products WHERE store_id = ? AND slug = ? AND status = 'published'`)
    .get(store.id, productSlug) as Record<string, unknown> | undefined;
  if (!rawProduct) notFound();

  const product = parseProduct({ ...rawProduct });

  const rawRelated = db
    .prepare(
      `SELECT * FROM products WHERE store_id = ? AND id != ? AND status = 'published' ORDER BY is_featured DESC, created_at DESC LIMIT 4`
    )
    .all(store.id, product.id) as unknown as Record<string, unknown>[];

  const relatedProducts = rawRelated.map((r) => parseProduct({ ...r }));

  const numericPrice = (product.price_display || '').replace(/[^0-9.]/g, '');
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: product.title,
    description: product.short_description || product.description,
    image: product.image_url ? [product.image_url] : undefined,
    category: product.category,
    brand: { '@type': 'Brand', name: product.merchant_name || store.name },
    offers: {
      '@type': 'Offer',
      priceCurrency: store.currency || 'USD',
      ...(numericPrice ? { price: numericPrice } : {}),
      availability: 'https://schema.org/InStock',
      seller: { '@type': 'Organization', name: product.merchant_name || store.name },
    },
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <ProductDetailClient
        store={store}
        product={product}
        relatedProducts={relatedProducts}
        platformName={settings.platform_name}
      />
    </>
  );
}
