import type { Metadata } from 'next';
import Link from 'next/link';
import { ArrowLeft, ShieldCheck } from 'lucide-react';
import Navbar from '@/components/Navbar';
import { getCurrentUser } from '@/lib/auth';
import { getPlatformSettings } from '@/lib/db';

export const dynamic = 'force-dynamic';

export const metadata: Metadata = {
  title: 'Privacy Policy — LinkAisle',
  description: 'How LinkAisle collects, uses, and protects your account, storefront, and visitor data.',
};

export default async function PrivacyPage() {
  const user = await getCurrentUser();
  const settings = getPlatformSettings();

  return (
    <div className="min-h-screen bg-[#FAFAF9] text-[#111315]">
      <Navbar user={user} platformName={settings.platform_name} />
      <main className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8">
        <Link href="/" className="inline-flex items-center gap-1.5 text-xs font-bold text-[#047857] hover:underline">
          <ArrowLeft className="h-3.5 w-3.5" /> Back to LinkAisle
        </Link>

        <article className="mt-6 rounded-3xl border border-stone-200 bg-white p-8 sm:p-10 shadow-sm space-y-6">
          <div className="flex items-center gap-2.5 text-[#047857]">
            <ShieldCheck className="h-6 w-6" />
            <span className="text-xs font-bold uppercase tracking-widest">Legal &amp; Privacy</span>
          </div>
          <h1 className="font-display text-3xl font-extrabold text-[#111315]">Privacy Policy</h1>
          <p className="text-xs text-stone-500">Last updated: {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</p>

          <section className="space-y-2 text-sm leading-relaxed text-stone-700">
            <h2 className="font-display text-lg font-bold text-[#111315]">1. Information We Collect</h2>
            <p>
              When you register on LinkAisle, we collect your name, verified email address, encrypted password hash (or verified Google OAuth profile email and name), and the storefront details, product listings, and buying guides you publish.
            </p>
            <p>
              When visitors browse storefronts or click outbound deal links, we record privacy-friendly aggregate analytics (page visits, product impressions, outbound deal clicks, referrer source, and country code). We do not sell personal visitor data to third parties.
            </p>
          </section>

          <section className="space-y-2 text-sm leading-relaxed text-stone-700">
            <h2 className="font-display text-lg font-bold text-[#111315]">2. Authentication, Security &amp; Third-Party Services</h2>
            <ul className="list-disc pl-5 space-y-1.5">
              <li><strong>Passwords &amp; Sessions:</strong> Passwords are salted and hashed with Node.js <code>scrypt</code>. Active sessions use HTTP-only, SameSite cookies.</li>
              <li><strong>Google Sign-In:</strong> If you use Continue with Google, we only request basic profile scopes (<code>openid email profile</code>) to verify your identity.</li>
              <li><strong>Cloud Storage &amp; Email:</strong> LinkAisle uses Supabase for cloud persistence/media storage and Resend/Supabase Auth for verification and password reset emails.</li>
              <li><strong>AI Assistant:</strong> Messages you send to the optional LinkAisle AI Assistant are processed solely to generate helpful responses and are not used to sell personal data.</li>
            </ul>
          </section>

          <section className="space-y-2 text-sm leading-relaxed text-stone-700">
            <h2 className="font-display text-lg font-bold text-[#111315]">3. External Merchant Links</h2>
            <p>
              LinkAisle storefronts link to external retailers such as Amazon and Impact.com partner brands. Once you click through to an external merchant, that retailer&apos;s own privacy policy and cookie practices govern your checkout and browsing.
            </p>
          </section>

          <section className="space-y-2 text-sm leading-relaxed text-stone-700">
            <h2 className="font-display text-lg font-bold text-[#111315]">4. Data Deletion &amp; Contact</h2>
            <p>
              You may delete your storefronts or products anytime from Creator Studio, or request full account deletion by emailing <strong>raza0754467@gmail.com</strong>.
            </p>
          </section>
        </article>
      </main>
    </div>
  );
}
