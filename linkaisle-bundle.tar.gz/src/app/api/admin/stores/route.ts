import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { getDb } from '@/lib/db';

export const runtime = 'nodejs';

export async function PATCH(req: NextRequest) {
  const admin = await getCurrentUser();
  if (!admin || admin.role !== 'admin') {
    return NextResponse.json({ error: 'Admin access required' }, { status: 403 });
  }

  try {
    const body = await req.json();
    const storeId = String(body.storeId || '');
    if (!storeId) return NextResponse.json({ error: 'storeId is required' }, { status: 400 });

    const db = getDb();
    const store = db.prepare('SELECT id, is_suspended FROM stores WHERE id = ?').get(storeId) as
      | { id: string; is_suspended: number }
      | undefined;

    if (!store) return NextResponse.json({ error: 'Store not found' }, { status: 404 });

    const nextSuspended = body.is_suspended ? 1 : 0;
    db.prepare('UPDATE stores SET is_suspended = ?, updated_at = ? WHERE id = ?').run(
      nextSuspended,
      new Date().toISOString(),
      storeId
    );

    return NextResponse.json({ ok: true, is_suspended: nextSuspended });
  } catch (err) {
    console.error('Admin update store error:', err);
    return NextResponse.json({ error: 'Failed to update store.' }, { status: 500 });
  }
}
