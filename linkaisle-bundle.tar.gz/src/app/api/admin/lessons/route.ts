import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { createId, getDb, slugify } from '@/lib/db';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const admin = await getCurrentUser();
  if (!admin || admin.role !== 'admin') {
    return NextResponse.json({ error: 'Admin access required' }, { status: 403 });
  }

  try {
    const body = await req.json();
    const title = String(body.title || '').trim();
    const summary = String(body.summary || '').trim();
    const content = String(body.content || '').trim();
    if (!title || !content) {
      return NextResponse.json({ error: 'Title and content are required.' }, { status: 400 });
    }

    const db = getDb();
    const id = createId('les');
    const slug = `${slugify(title)}-${id.slice(-3)}`;
    const now = new Date().toISOString();

    db.prepare(
      `INSERT INTO academy_lessons (
        id, module_number, order_index, slug, title, summary, content,
        title_ur, summary_ur, content_ur,
        duration_minutes, level, is_published, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      id,
      Number(body.module_number || 1),
      Number(body.order_index || 10),
      slug,
      title,
      summary || title,
      content,
      String(body.title_ur || '').trim(),
      String(body.summary_ur || '').trim(),
      String(body.content_ur || '').trim(),
      Number(body.duration_minutes || 6),
      ['Beginner', 'Intermediate', 'Pro'].includes(String(body.level)) ? String(body.level) : 'Beginner',
      body.is_published === false ? 0 : 1,
      now
    );

    const lesson = db.prepare('SELECT * FROM academy_lessons WHERE id = ?').get(id);
    return NextResponse.json({ lesson }, { status: 201 });
  } catch (err) {
    console.error('Create lesson error:', err);
    return NextResponse.json({ error: 'Failed to create lesson.' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const admin = await getCurrentUser();
  if (!admin || admin.role !== 'admin') {
    return NextResponse.json({ error: 'Admin access required' }, { status: 403 });
  }

  try {
    const body = await req.json();
    const lessonId = String(body.id || '');
    if (!lessonId) return NextResponse.json({ error: 'Lesson id is required' }, { status: 400 });

    const db = getDb();
    const existing = db.prepare('SELECT * FROM academy_lessons WHERE id = ?').get(lessonId) as
      | Record<string, unknown>
      | undefined;
    if (!existing) return NextResponse.json({ error: 'Lesson not found' }, { status: 404 });

    db.prepare(
      `UPDATE academy_lessons SET
        title = ?, summary = ?, content = ?, module_number = ?, duration_minutes = ?, level = ?, is_published = ?
       WHERE id = ?`
    ).run(
      body.title !== undefined ? String(body.title).trim() : String(existing.title),
      body.summary !== undefined ? String(body.summary).trim() : String(existing.summary),
      body.content !== undefined ? String(body.content).trim() : String(existing.content),
      body.module_number !== undefined ? Number(body.module_number) : Number(existing.module_number),
      body.duration_minutes !== undefined ? Number(body.duration_minutes) : Number(existing.duration_minutes),
      body.level !== undefined ? String(body.level) : String(existing.level),
      body.is_published !== undefined ? (body.is_published ? 1 : 0) : Number(existing.is_published),
      lessonId
    );

    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error('Update lesson error:', err);
    return NextResponse.json({ error: 'Failed to update lesson.' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const admin = await getCurrentUser();
  if (!admin || admin.role !== 'admin') {
    return NextResponse.json({ error: 'Admin access required' }, { status: 403 });
  }

  const id = req.nextUrl.searchParams.get('id');
  if (!id) return NextResponse.json({ error: 'Lesson id required' }, { status: 400 });

  const db = getDb();
  db.prepare('DELETE FROM academy_lessons WHERE id = ?').run(id);
  return NextResponse.json({ ok: true });
}
