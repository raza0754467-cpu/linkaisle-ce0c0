import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { createId, getDb, persistDbToCloud } from '@/lib/db';

export const runtime = 'nodejs';

function isValidHttpUrl(str: string): boolean {
  try {
    const u = new URL(str);
    return u.protocol === 'http:' || u.protocol === 'https:';
  } catch {
    return false;
  }
}

export async function POST(req: NextRequest) {
  const admin = await getCurrentUser();
  if (!admin || admin.role !== 'admin') {
    return NextResponse.json({ error: 'Admin access required' }, { status: 403 });
  }

  try {
    const body = await req.json();
    const name = String(body.name || '').trim();
    const affiliateUrl = String(body.affiliate_url || '').trim();
    if (!name || !isValidHttpUrl(affiliateUrl)) {
      return NextResponse.json(
        { error: 'Tool name and valid https:// affiliate URL are required.' },
        { status: 400 }
      );
    }

    const db = getDb();
    const id = createId('tl');
    const now = new Date().toISOString();

    db.prepare(
      `INSERT INTO partner_tools (
        id, name, category, tagline, description, affiliate_url,
        commission_note, badge, clicks, is_published, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 1, ?)`
    ).run(
      id,
      name,
      String(body.category || 'Affiliate Networks').trim(),
      String(body.tagline || '').trim(),
      String(body.description || '').trim(),
      affiliateUrl,
      String(body.commission_note || '').trim(),
      String(body.badge || '').trim(),
      now
    );

    const tool = db.prepare('SELECT * FROM partner_tools WHERE id = ?').get(id);
    await persistDbToCloud();
    return NextResponse.json({ tool }, { status: 201 });
  } catch (err) {
    console.error('Create partner tool error:', err);
    return NextResponse.json({ error: 'Failed to add tool.' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const admin = await getCurrentUser();
  if (!admin || admin.role !== 'admin') {
    return NextResponse.json({ error: 'Admin access required' }, { status: 403 });
  }

  try {
    const body = await req.json();
    const id = String(body.id || '');
    if (!id) return NextResponse.json({ error: 'Tool id required' }, { status: 400 });

    const db = getDb();
    const existing = db.prepare('SELECT * FROM partner_tools WHERE id = ?').get(id) as
      | Record<string, unknown>
      | undefined;
    if (!existing) return NextResponse.json({ error: 'Tool not found' }, { status: 404 });

    const nextUrl =
      body.affiliate_url !== undefined ? String(body.affiliate_url).trim() : String(existing.affiliate_url);
    if (!isValidHttpUrl(nextUrl)) {
      return NextResponse.json({ error: 'Invalid affiliate URL' }, { status: 400 });
    }

    db.prepare(
      `UPDATE partner_tools SET
        name = ?, category = ?, tagline = ?, description = ?,
        affiliate_url = ?, commission_note = ?, badge = ?, is_published = ?
       WHERE id = ?`
    ).run(
      body.name !== undefined ? String(body.name).trim() : String(existing.name),
      body.category !== undefined ? String(body.category).trim() : String(existing.category),
      body.tagline !== undefined ? String(body.tagline).trim() : String(existing.tagline),
      body.description !== undefined ? String(body.description).trim() : String(existing.description),
      nextUrl,
      body.commission_note !== undefined
        ? String(body.commission_note).trim()
        : String(existing.commission_note),
      body.badge !== undefined ? String(body.badge).trim() : String(existing.badge),
      body.is_published !== undefined ? (body.is_published ? 1 : 0) : Number(existing.is_published),
      id
    );

    await persistDbToCloud();
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error('Update partner tool error:', err);
    return NextResponse.json({ error: 'Failed to update tool.' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const admin = await getCurrentUser();
  if (!admin || admin.role !== 'admin') {
    return NextResponse.json({ error: 'Admin access required' }, { status: 403 });
  }

  const id = req.nextUrl.searchParams.get('id');
  if (!id) return NextResponse.json({ error: 'Tool id required' }, { status: 400 });

  const db = getDb();
  db.prepare('DELETE FROM partner_tools WHERE id = ?').run(id);
  await persistDbToCloud();
  return NextResponse.json({ ok: true });
}
