import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { getDb, getPlatformSettings } from '@/lib/db';
import { getPlatformAdminAnalytics } from '@/lib/analytics';

export const runtime = 'nodejs';

export async function GET() {
  const user = await getCurrentUser();
  if (!user || user.role !== 'admin') {
    return NextResponse.json({ error: 'Admin access required' }, { status: 403 });
  }

  const db = getDb();
  const analytics = getPlatformAdminAnalytics();
  const settings = getPlatformSettings();

  const users = db
    .prepare(
      `SELECT u.id, u.name, u.email, u.role, u.plan, u.status, u.created_at,
        (SELECT COUNT(*) FROM stores s WHERE s.user_id = u.id) as store_count,
        (SELECT COUNT(*) FROM products p JOIN stores s ON s.id = p.store_id WHERE s.user_id = u.id) as product_count
       FROM users u
       ORDER BY u.created_at DESC`
    )
    .all();

  const lessons = db
    .prepare('SELECT * FROM academy_lessons ORDER BY module_number ASC, order_index ASC')
    .all();

  const upgradeRequests = db
    .prepare(
      `SELECT r.*, u.name as user_name, u.email as user_email, u.plan as current_plan
       FROM upgrade_requests r
       JOIN users u ON u.id = r.user_id
       ORDER BY CASE WHEN r.status = 'pending' THEN 0 ELSE 1 END, r.created_at DESC`
    )
    .all();

  const revenueStats = db
    .prepare(
      `SELECT
        COALESCE(SUM(CASE WHEN status = 'approved' THEN amount_usd ELSE 0 END), 0) as approved_revenue,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_count,
        SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved_count
       FROM upgrade_requests`
    )
    .get() as { approved_revenue: number; pending_count: number | null; approved_count: number | null };

  const paidUsersCount = (
    db.prepare(`SELECT COUNT(*) as count FROM users WHERE plan IN ('starter', 'pro')`).get() as {
      count: number;
    }
  ).count;

  const partnerTools = db
    .prepare('SELECT * FROM partner_tools ORDER BY clicks DESC, created_at ASC')
    .all();

  const totalToolClicks = (
    db.prepare('SELECT COALESCE(SUM(clicks), 0) as total FROM partner_tools').get() as { total: number }
  ).total;

  return NextResponse.json({
    analytics,
    settings,
    users,
    lessons,
    billing: {
      requests: upgradeRequests,
      approvedRevenueUsd: Number(revenueStats?.approved_revenue || 0),
      pendingCount: Number(revenueStats?.pending_count || 0),
      approvedCount: Number(revenueStats?.approved_count || 0),
      paidUsersCount,
    },
    partnerTools,
    totalToolClicks,
  });
}
