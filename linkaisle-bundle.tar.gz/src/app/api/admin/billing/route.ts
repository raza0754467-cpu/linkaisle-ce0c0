import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { getDb, persistDbToCloud } from '@/lib/db';

export const runtime = 'nodejs';

export async function PATCH(req: NextRequest) {
  const admin = await getCurrentUser();
  if (!admin || admin.role !== 'admin') {
    return NextResponse.json({ error: 'Admin access required' }, { status: 403 });
  }

  try {
    const body = await req.json();
    const requestId = String(body.requestId || '');
    const action = String(body.action || '');
    const adminNote = String(body.admin_note || '').trim();

    if (!requestId || (action !== 'approve' && action !== 'reject')) {
      return NextResponse.json({ error: 'Valid requestId and action (approve/reject) required.' }, { status: 400 });
    }

    const db = getDb();
    const reqRow = db
      .prepare('SELECT * FROM upgrade_requests WHERE id = ?')
      .get(requestId) as
      | { id: string; user_id: string; requested_plan: string; status: string }
      | undefined;

    if (!reqRow) {
      return NextResponse.json({ error: 'Upgrade request not found.' }, { status: 404 });
    }

    const now = new Date().toISOString();
    const nextStatus = action === 'approve' ? 'approved' : 'rejected';

    db.prepare(
      'UPDATE upgrade_requests SET status = ?, admin_note = ?, reviewed_at = ? WHERE id = ?'
    ).run(nextStatus, adminNote, now, requestId);

    if (action === 'approve') {
      db.prepare('UPDATE users SET plan = ? WHERE id = ?').run(
        reqRow.requested_plan,
        reqRow.user_id
      );
    }

    await persistDbToCloud();
    return NextResponse.json({ ok: true, status: nextStatus });
  } catch (err) {
    console.error('Admin billing action error:', err);
    return NextResponse.json({ error: 'Failed to process upgrade request.' }, { status: 500 });
  }
}
