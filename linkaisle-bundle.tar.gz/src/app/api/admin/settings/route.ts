import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { getDb, getPlatformSettings } from '@/lib/db';

export const runtime = 'nodejs';

export async function PATCH(req: NextRequest) {
  const admin = await getCurrentUser();
  if (!admin || admin.role !== 'admin') {
    return NextResponse.json({ error: 'Admin access required' }, { status: 403 });
  }

  try {
    const body = await req.json();
    const db = getDb();
    const upsert = db.prepare('INSERT OR REPLACE INTO platform_settings (key, value) VALUES (?, ?)');

    if (body.platform_name !== undefined) {
      upsert.run('platform_name', String(body.platform_name).trim() || 'LinkAisle');
    }
    if (body.platform_tagline !== undefined) {
      upsert.run('platform_tagline', String(body.platform_tagline).trim());
    }
    if (body.allow_registrations !== undefined) {
      upsert.run('allow_registrations', body.allow_registrations ? 'true' : 'false');
    }
    if (body.plan_limits !== undefined) {
      upsert.run('plan_limits', JSON.stringify(body.plan_limits));
    }

    if (body.monetization !== undefined && typeof body.monetization === 'object') {
      const m = body.monetization;
      if (m.ads_enabled !== undefined) upsert.run('ads_enabled', m.ads_enabled ? 'true' : 'false');
      if (m.ad_network_label !== undefined) upsert.run('ad_network_label', String(m.ad_network_label).trim());
      if (m.ad_sponsor_title !== undefined) upsert.run('ad_sponsor_title', String(m.ad_sponsor_title).trim());
      if (m.ad_sponsor_desc !== undefined) upsert.run('ad_sponsor_desc', String(m.ad_sponsor_desc).trim());
      if (m.ad_sponsor_cta_text !== undefined)
        upsert.run('ad_sponsor_cta_text', String(m.ad_sponsor_cta_text).trim());
      if (m.ad_sponsor_cta_url !== undefined)
        upsert.run('ad_sponsor_cta_url', String(m.ad_sponsor_cta_url).trim());
      if (m.payment_instructions !== undefined)
        upsert.run('payment_instructions', String(m.payment_instructions).trim());
    }

    return NextResponse.json({ settings: getPlatformSettings() });
  } catch (err) {
    console.error('Update settings error:', err);
    return NextResponse.json({ error: 'Failed to save settings.' }, { status: 500 });
  }
}
