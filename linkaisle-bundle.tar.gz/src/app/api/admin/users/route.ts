import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { getDb, persistDbToCloud } from '@/lib/db';

export const runtime = 'nodejs';

export async function PATCH(req: NextRequest) {
  const admin = await getCurrentUser();
  if (!admin || admin.role !== 'admin') {
    return NextResponse.json({ error: 'Admin access required' }, { status: 403 });
  }

  try {
    const body = await req.json();
    const userId = String(body.userId || '');
    if (!userId) return NextResponse.json({ error: 'userId is required' }, { status: 400 });
    if (userId === admin.id && body.status === 'suspended') {
      return NextResponse.json({ error: 'You cannot suspend your own admin account.' }, { status: 400 });
    }

    const db = getDb();
    const target = db.prepare('SELECT * FROM users WHERE id = ?').get(userId) as Record<string, unknown> | undefined;
    if (!target) return NextResponse.json({ error: 'User not found' }, { status: 404 });

    const validPlans = ['free', 'starter', 'pro'];
    const validStatuses = ['active', 'suspended'];
    const validRoles = ['user', 'admin'];

    const nextPlan = body.plan && validPlans.includes(String(body.plan)) ? String(body.plan) : String(target.plan);
    const nextStatus =
      body.status && validStatuses.includes(String(body.status)) ? String(body.status) : String(target.status);
    const nextRole = body.role && validRoles.includes(String(body.role)) ? String(body.role) : String(target.role);

    db.prepare('UPDATE users SET plan = ?, status = ?, role = ? WHERE id = ?').run(
      nextPlan,
      nextStatus,
      nextRole,
      userId
    );

    if (nextStatus === 'suspended') {
      db.prepare('DELETE FROM sessions WHERE user_id = ?').run(userId);
    }

    await persistDbToCloud();
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error('Admin update user error:', err);
    return NextResponse.json({ error: 'Failed to update user.' }, { status: 500 });
  }
}
