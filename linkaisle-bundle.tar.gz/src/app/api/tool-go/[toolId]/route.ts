import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/lib/db';

export const runtime = 'nodejs';

export async function GET(
  req: NextRequest,
  context: { params: Promise<{ toolId: string }> }
) {
  const { toolId } = await context.params;
  const db = getDb();

  const tool = db
    .prepare('SELECT id, affiliate_url FROM partner_tools WHERE id = ? AND is_published = 1')
    .get(toolId) as { id: string; affiliate_url: string } | undefined;

  if (!tool) {
    return NextResponse.redirect(new URL('/tools', req.url));
  }

  try {
    const dest = new URL(tool.affiliate_url);
    if (dest.protocol !== 'http:' && dest.protocol !== 'https:') {
      return NextResponse.redirect(new URL('/tools', req.url));
    }
    db.prepare('UPDATE partner_tools SET clicks = clicks + 1 WHERE id = ?').run(tool.id);
    return NextResponse.redirect(dest.toString(), { status: 302 });
  } catch {
    return NextResponse.redirect(new URL('/tools', req.url));
  }
}
