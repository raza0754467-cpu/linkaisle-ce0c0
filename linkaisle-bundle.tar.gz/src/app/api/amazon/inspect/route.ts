import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import {
  fetchOfficialAmazonProduct,
  isAmazonPaApiConfigured,
  parseAmazonUrl,
} from '@/lib/amazon-paapi';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const body = await req.json();
    const rawUrl = String(body.url || '').trim();
    if (!rawUrl) {
      return NextResponse.json({ error: 'Please paste an Amazon product URL first.' }, { status: 400 });
    }

    const parsed = parseAmazonUrl(rawUrl);
    if (!parsed.isAmazon) {
      return NextResponse.json({
        isAmazon: false,
        message: 'This is not an Amazon URL — you can still add it as a standard Impact / merchant product.',
      });
    }

    const paApiReady = isAmazonPaApiConfigured();
    let officialData = null;
    let paApiNote =
      'ASIN & Marketplace detected! To auto-fetch official live Amazon Price, Stock & Best Sellers Rank, add AMAZON_ACCESS_KEY, AMAZON_SECRET_KEY & AMAZON_PARTNER_TAG (unlocked after 3 qualifying sales on Amazon Associates).';

    if (paApiReady && parsed.asin) {
      const result = await fetchOfficialAmazonProduct(parsed.asin, parsed.host);
      if (result.data) {
        officialData = result.data;
        paApiNote = 'Live product details synced directly from Official Amazon PA-API 5.0!';
      } else if (result.error) {
        paApiNote = `Amazon PA-API note: ${result.error}`;
      }
    }

    return NextResponse.json({
      isAmazon: true,
      asin: parsed.asin,
      host: parsed.host,
      countryCode: parsed.countryCode,
      currency: parsed.currency,
      partnerTag: parsed.partnerTag,
      hasAffiliateTag: Boolean(parsed.partnerTag || rawUrl.includes('amzn.to')),
      reviewsUrl: parsed.reviewsUrl,
      canonicalUrl: parsed.canonicalUrl,
      paApiConfigured: paApiReady,
      officialData,
      note: paApiNote,
    });
  } catch {
    return NextResponse.json({ error: 'Could not inspect URL.' }, { status: 500 });
  }
}
