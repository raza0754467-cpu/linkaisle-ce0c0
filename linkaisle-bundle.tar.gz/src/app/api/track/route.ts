import { NextRequest, NextResponse } from 'next/server';
import {
  AnalyticsEventType,
  detectReferrerSource,
  detectVisitorCountry,
  hashVisitor,
  recordAnalyticsEvent,
} from '@/lib/analytics';
import { checkRateLimit } from '@/lib/rate-limit';

export const runtime = 'nodejs';

const VALID_TYPES: AnalyticsEventType[] = [
  'platform_visit',
  'store_visit',
  'product_impression',
  'product_click',
  'post_view',
];

export async function POST(req: NextRequest) {
  try {
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || '127.0.0.1';
    const rl = checkRateLimit(`track:${ip}`, 120, 60 * 1000);
    if (!rl.allowed) {
      return NextResponse.json({ ok: false, error: 'Rate limit exceeded' }, { status: 429 });
    }

    const body = await req.json();
    const eventType = String(body.eventType || '') as AnalyticsEventType;
    if (!VALID_TYPES.includes(eventType)) {
      return NextResponse.json({ error: 'Invalid eventType' }, { status: 400 });
    }

    const ua = req.headers.get('user-agent') || 'unknown';
    const referrer = String(body.referrer || req.headers.get('referer') || '');
    const utmSource = String(body.utmSource || '');

    const source = detectReferrerSource(referrer, utmSource);
    const visitorHash = hashVisitor(ip, ua);
    const country = detectVisitorCountry(req.headers, body.country ? String(body.country) : null);

    // Support batch product impressions when a storefront renders multiple cards
    if (eventType === 'product_impression' && Array.isArray(body.productIds)) {
      const storeId = body.storeId ? String(body.storeId) : null;
      for (const pid of body.productIds.slice(0, 50)) {
        recordAnalyticsEvent({
          eventType: 'product_impression',
          storeId,
          productId: String(pid),
          referrerSource: source,
          visitorHash,
          country,
        });
      }
      return NextResponse.json({ ok: true, tracked: body.productIds.length });
    }

    recordAnalyticsEvent({
      eventType,
      storeId: body.storeId ? String(body.storeId) : null,
      productId: body.productId ? String(body.productId) : null,
      postId: body.postId ? String(body.postId) : null,
      referrerSource: source,
      visitorHash,
      country,
    });

    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error('Track error:', err);
    return NextResponse.json({ error: 'Failed to record event' }, { status: 500 });
  }
}
