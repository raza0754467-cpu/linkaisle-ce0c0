import { NextRequest, NextResponse } from 'next/server';
import { createId, getDb, getPlatformSettings, hashPassword, persistDbToCloud, slugify } from '@/lib/db';
import { createSession } from '@/lib/auth';
import { checkRateLimit } from '@/lib/rate-limit';
import { sendWelcomeEmail } from '@/lib/email';
import { STORE_TEMPLATES } from '@/lib/types';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  try {
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'local';
    const rl = checkRateLimit(`register:${ip}`, 15, 15 * 60 * 1000);
    if (!rl.allowed) {
      return NextResponse.json(
        { error: `Too many registration attempts. Try again in ${rl.retryAfterSeconds}s.` },
        { status: 429 }
      );
    }

    const settings = getPlatformSettings();
    if (!settings.allow_registrations) {
      return NextResponse.json({ error: 'New registrations are currently paused by the platform admin.' }, { status: 403 });
    }

    const body = await req.json();
    const name = String(body.name || '').trim();
    const email = String(body.email || '').trim().toLowerCase();
    const password = String(body.password || '');
    const storeName = String(body.storeName || '').trim();
    const template = String(body.template || 'kitchen').trim();

    if (!name || name.length < 2) {
      return NextResponse.json({ error: 'Please enter your full name.' }, { status: 400 });
    }
    if (!email || !email.includes('@')) {
      return NextResponse.json({ error: 'Please enter a valid email address.' }, { status: 400 });
    }
    if (password.length < 6) {
      return NextResponse.json({ error: 'Password must be at least 6 characters.' }, { status: 400 });
    }

    const db = getDb();
    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
    if (existing) {
      return NextResponse.json({ error: 'An account with this email already exists.' }, { status: 409 });
    }

    const userId = createId('usr');
    const now = new Date().toISOString();

    db.prepare(
      `INSERT INTO users (id, name, email, password_hash, role, plan, status, created_at)
       VALUES (?, ?, ?, ?, 'user', 'free', 'active', ?)`
    ).run(userId, name, email, hashPassword(password), now);

    // Optionally bootstrap their first store immediately so onboarding feels effortless
    let createdStoreSlug = '';
    if (storeName) {
      let baseSlug = slugify(storeName);
      const slugConflict = db.prepare('SELECT id FROM stores WHERE slug = ?').get(baseSlug);
      if (slugConflict) {
        baseSlug = `${baseSlug}-${Math.floor(100 + Math.random() * 900)}`;
      }
      createdStoreSlug = baseSlug;
      const chosenTemplateObj =
        STORE_TEMPLATES.find((t) => t.id === template) || STORE_TEMPLATES[0];
      const storeId = createId('str');

      db.prepare(
        `INSERT INTO stores (
          id, user_id, slug, name, tagline, description, template,
          primary_color, accent_color, hero_title, hero_subtitle, hero_cta,
          contact_email, is_published, is_suspended, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Explore Top Picks', ?, 1, 0, ?, ?)`
      ).run(
        storeId,
        userId,
        baseSlug,
        storeName,
        'Handpicked affiliate deals & honest recommendations.',
        `Welcome to ${storeName}. Every product here is curated to save you time and money.`,
        chosenTemplateObj.id,
        chosenTemplateObj.defaultPrimary,
        chosenTemplateObj.defaultAccent,
        `Top Curated Picks by ${storeName}`,
        'Browse our handpicked collection of high-value products with direct merchant links.',
        email,
        now,
        now
      );
    }

    await createSession(userId);
    await persistDbToCloud();

    const origin =
      process.env.NEXT_PUBLIC_SITE_URL?.replace(/\/$/, '') ||
      req.nextUrl.origin ||
      'https://linkaisle.netlify.app';
    void sendWelcomeEmail({
      to: email,
      name,
      storeName: storeName || `${name}'s Store`,
      storeUrl: createdStoreSlug ? `${origin}/s/${createdStoreSlug}` : `${origin}/dashboard`,
      studioUrl: `${origin}/dashboard`,
    });

    return NextResponse.json({
      user: { id: userId, name, email, role: 'user', plan: 'free', status: 'active' },
    });
  } catch (err) {
    console.error('Register error:', err);
    return NextResponse.json({ error: 'Failed to register account.' }, { status: 500 });
  }
}
