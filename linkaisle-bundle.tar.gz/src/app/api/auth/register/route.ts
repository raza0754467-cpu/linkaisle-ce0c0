import { NextRequest, NextResponse } from 'next/server';
import { createId, getDb, getPlatformSettings, hashPassword, persistDbToCloud, slugify } from '@/lib/db';
import { createSession } from '@/lib/auth';
import { checkRateLimit } from '@/lib/rate-limit';
import { STORE_TEMPLATES } from '@/lib/types';

export const runtime = 'nodejs';

const EMAIL_RX = /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/i;
const BLOCKED_FAKE_DOMAINS = new Set([
  'test.com',
  'example.com',
  'fake.com',
  'asdf.com',
  'mailinator.com',
  'tempmail.com',
  '10minutemail.com',
  'yopmail.com',
]);

export async function POST(req: NextRequest) {
  try {
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'local';
    const rl = checkRateLimit(`register:${ip}`, 15, 15 * 60 * 1000);
    if (!rl.allowed) {
      return NextResponse.json(
        { error: `Too many registration attempts. Try again in ${rl.retryAfterSeconds}s.` },
        { status: 429 }
      );
    }

    const settings = getPlatformSettings();
    if (!settings.allow_registrations) {
      return NextResponse.json(
        { error: 'New registrations are currently paused by the platform admin.' },
        { status: 403 }
      );
    }

    const body = await req.json();
    const name = String(body.name || '').trim();
    const email = String(body.email || '').trim().toLowerCase();
    const password = String(body.password || '');
    const storeName = String(body.storeName || '').trim();
    const template = String(body.template || 'kitchen').trim();

    if (!name || name.length < 2) {
      return NextResponse.json({ error: 'Please enter your full name.' }, { status: 400 });
    }
    if (!email || !EMAIL_RX.test(email)) {
      return NextResponse.json({ error: 'Please enter a valid real email address.' }, { status: 400 });
    }
    const emailDomain = email.split('@')[1] || '';
    if (BLOCKED_FAKE_DOMAINS.has(emailDomain) || emailDomain.endsWith('.local')) {
      return NextResponse.json(
        { error: 'Temporary or fake email domains are not allowed. Please use a real email address.' },
        { status: 400 }
      );
    }
    if (password.length < 6) {
      return NextResponse.json({ error: 'Password must be at least 6 characters.' }, { status: 400 });
    }
    if (!storeName || storeName.length < 2) {
      return NextResponse.json({ error: 'Please enter a name for your first store.' }, { status: 400 });
    }

    const db = getDb();
    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
    if (existing) {
      return NextResponse.json(
        { error: 'An account with this email already exists. Please sign in.' },
        { status: 409 }
      );
    }

    const supabaseUrl = (process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL || '')
      .trim()
      .replace(/\/$/, '');
    const supabaseAnonKey = (process.env.SUPABASE_ANON_KEY || '').trim();
    const origin =
      process.env.NEXT_PUBLIC_SITE_URL?.replace(/\/$/, '') ||
      req.nextUrl.origin ||
      'https://linkaisle.netlify.app';

    // REAL PRODUCTION FLOW: Require genuine email inbox verification via Supabase Auth!
    if (supabaseUrl && supabaseAnonKey.length > 20) {
      const now = new Date().toISOString();
      const chosenTemplateObj =
        STORE_TEMPLATES.find((t) => t.id === template) || STORE_TEMPLATES[0];

      db.prepare(
        `INSERT OR REPLACE INTO pending_registrations (email, name, password_hash, store_name, template, created_at)
         VALUES (?, ?, ?, ?, ?, ?)`
      ).run(email, name, hashPassword(password), storeName, chosenTemplateObj.id, now);
      await persistDbToCloud();

      const redirectTo = `${origin}/auth/callback`;

      // Trigger real verification email via Supabase Auth
      const sbRes = await fetch(
        `${supabaseUrl}/auth/v1/signup?redirect_to=${encodeURIComponent(redirectTo)}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            apikey: supabaseAnonKey,
          },
          body: JSON.stringify({
            email,
            password,
            data: { name, store_name: storeName },
            gotrue_meta_security: {},
          }),
        }
      );

      let sentOk = sbRes.ok;
      let errMsg = '';

      if (!sbRes.ok) {
        const sbErr = (await sbRes.json().catch(() => ({}))) as { msg?: string; message?: string };
        errMsg = sbErr.msg || sbErr.message || '';

        // If the email already existed in Supabase Auth from an earlier attempt, send a fresh OTP/Magic Link
        const otpRes = await fetch(
          `${supabaseUrl}/auth/v1/otp?redirect_to=${encodeURIComponent(redirectTo)}`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              apikey: supabaseAnonKey,
            },
            body: JSON.stringify({
              email,
              create_user: true,
              data: { name, store_name: storeName },
            }),
          }
        );
        sentOk = otpRes.ok;
        if (!otpRes.ok) {
          const otpErr = (await otpRes.json().catch(() => ({}))) as { msg?: string; message?: string };
          errMsg = otpErr.msg || otpErr.message || errMsg;
        }
      }

      if (!sentOk) {
        return NextResponse.json(
          {
            error:
              errMsg ||
              'Could not send verification email to this address right now. Please check the email spelling or wait a minute and retry.',
          },
          { status: 400 }
        );
      }

      return NextResponse.json({
        ok: true,
        requiresVerification: true,
        email,
        message: `Verification email sent to ${email}. Open your real email inbox and click the confirmation link to activate your account & launch "${storeName}".`,
      });
    }

    // Localhost offline dev fallback only when Supabase Auth is not configured
    const userId = createId('usr');
    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO users (id, name, email, password_hash, role, plan, status, created_at)
       VALUES (?, ?, ?, ?, 'user', 'free', 'active', ?)`
    ).run(userId, name, email, hashPassword(password), now);

    let baseSlug = slugify(storeName);
    if (db.prepare('SELECT id FROM stores WHERE slug = ?').get(baseSlug)) {
      baseSlug = `${baseSlug}-${Math.floor(100 + Math.random() * 900)}`;
    }
    const chosenTemplateObj = STORE_TEMPLATES.find((t) => t.id === template) || STORE_TEMPLATES[0];
    db.prepare(
      `INSERT INTO stores (
        id, user_id, slug, name, tagline, description, template,
        primary_color, accent_color, hero_title, hero_subtitle, hero_cta,
        contact_email, is_published, is_suspended, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Explore Top Picks', ?, 1, 0, ?, ?)`
    ).run(
      createId('str'),
      userId,
      baseSlug,
      storeName,
      'Handpicked affiliate deals & honest recommendations.',
      `Welcome to ${storeName}. Every product here is curated to save you time and money.`,
      chosenTemplateObj.id,
      chosenTemplateObj.defaultPrimary,
      chosenTemplateObj.defaultAccent,
      `Top Curated Picks by ${storeName}`,
      'Browse our handpicked collection of high-value products with direct merchant links.',
      email,
      now,
      now
    );

    await createSession(userId);
    return NextResponse.json({
      user: { id: userId, name, email, role: 'user', plan: 'free', status: 'active' },
    });
  } catch (err) {
    console.error('Register error:', err);
    return NextResponse.json({ error: 'Failed to register account.' }, { status: 500 });
  }
}
