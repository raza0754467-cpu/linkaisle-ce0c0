import { NextRequest, NextResponse } from 'next/server';
import { getDb, hashPassword, persistDbToCloud, refreshDbFromCloudSync } from '@/lib/db';
import { checkRateLimit } from '@/lib/rate-limit';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  try {
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'local';
    const rl = checkRateLimit(`reset-pw:${ip}`, 15, 15 * 60 * 1000);
    if (!rl.allowed) {
      return NextResponse.json(
        { error: `Too many password reset attempts. Please wait ${rl.retryAfterSeconds}s.` },
        { status: 429 }
      );
    }

    const body = await req.json();
    const token = String(body.token || '').trim();
    const password = String(body.password || '');

    if (!token || password.length < 6) {
      return NextResponse.json(
        { error: 'Valid reset token and a new password (min 6 characters) are required.' },
        { status: 400 }
      );
    }

    let db = getDb();
    let row = db
      .prepare('SELECT token, user_id, expires_at, used FROM password_resets WHERE token = ?')
      .get(token) as
      | { token: string; user_id: string; expires_at: string; used: number }
      | undefined;

    if (!row && refreshDbFromCloudSync()) {
      db = getDb();
      row = db
        .prepare('SELECT token, user_id, expires_at, used FROM password_resets WHERE token = ?')
        .get(token) as typeof row;
    }

    if (!row || row.used === 1 || new Date(row.expires_at).getTime() < Date.now()) {
      return NextResponse.json(
        { error: 'This password reset link is invalid or has expired. Please request a new one.' },
        { status: 400 }
      );
    }

    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(
      hashPassword(password),
      row.user_id
    );
    db.prepare('UPDATE password_resets SET used = 1 WHERE token = ?').run(token);
    db.prepare('DELETE FROM sessions WHERE user_id = ?').run(row.user_id);
    await persistDbToCloud();

    return NextResponse.json({ ok: true, message: 'Password updated! You can now sign in.' });
  } catch {
    return NextResponse.json({ error: 'Could not reset password.' }, { status: 500 });
  }
}
