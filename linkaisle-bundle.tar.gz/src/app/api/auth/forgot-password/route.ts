import crypto from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { checkRateLimit } from '@/lib/rate-limit';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'local';
  const rl = checkRateLimit(`forgot:${ip}`, 8, 15 * 60_000);
  if (!rl.allowed) {
    return NextResponse.json(
      { error: 'Too many reset requests. Please try again in a few minutes.' },
      { status: 429 }
    );
  }

  try {
    const body = await req.json();
    const email = String(body.email || '').trim().toLowerCase();
    if (!email || !email.includes('@')) {
      return NextResponse.json({ error: 'Please enter a valid email address.' }, { status: 400 });
    }

    const db = getDb();
    const user = db
      .prepare('SELECT id, name, email FROM users WHERE email = ?')
      .get(email) as { id: string; name: string; email: string } | undefined;

    // Always return generic success message to prevent email enumeration
    const genericMessage =
      'If an account exists with that email, a password reset link has been sent.';

    if (!user) {
      return NextResponse.json({ ok: true, message: genericMessage });
    }

    const token = crypto.randomBytes(32).toString('hex');
    const now = new Date();
    const expires = new Date(now.getTime() + 60 * 60 * 1000); // 1 hour

    db.prepare('DELETE FROM password_resets WHERE user_id = ?').run(user.id);
    db.prepare(
      'INSERT INTO password_resets (token, user_id, expires_at, used, created_at) VALUES (?, ?, ?, 0, ?)'
    ).run(token, user.id, expires.toISOString(), now.toISOString());

    const origin =
      process.env.NEXT_PUBLIC_SITE_URL?.replace(/\/$/, '') ||
      req.nextUrl.origin ||
      'http://localhost:3000';
    const resetUrl = `${origin}/reset-password?token=${token}`;

    // Send real email via Resend Free Tier (3,000 free emails/month) if configured
    const resendKey = (process.env.RESEND_API_KEY || '').trim();
    const fromEmail = (process.env.EMAIL_FROM || 'LinkAisle <onboarding@resend.dev>').trim();

    if (resendKey.length > 10) {
      try {
        await fetch('https://api.resend.com/emails', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${resendKey}`,
          },
          body: JSON.stringify({
            from: fromEmail,
            to: [user.email],
            subject: 'Reset your LinkAisle password',
            html: `
              <div style="font-family:Inter,Arial,sans-serif;max-width:520px;margin:0 auto;padding:24px;color:#111315;">
                <h2 style="margin:0 0 12px;">Reset Your LinkAisle Password</h2>
                <p style="font-size:14px;line-height:1.6;color:#444;">Hi ${user.name}, we received a request to reset your password. Click the button below within 1 hour:</p>
                <p style="margin:24px 0;">
                  <a href="${resetUrl}" style="display:inline-block;background:#047857;color:#fff;padding:12px 24px;border-radius:999px;text-decoration:none;font-weight:700;font-size:14px;">Reset Password</a>
                </p>
                <p style="font-size:12px;color:#777;">If you didn't request this, you can safely ignore this email.</p>
              </div>
            `,
          }),
        });
      } catch (mailErr) {
        console.error('Resend email error:', mailErr);
      }
      return NextResponse.json({ ok: true, message: genericMessage });
    }

    // Local / unconfigured SMTP fallback: log securely to server console for testing
    console.log(`[LinkAisle Password Reset] ${user.email} -> ${resetUrl}`);
    const isLocal = origin.includes('localhost') || origin.includes('127.0.0.1');
    return NextResponse.json({
      ok: true,
      message: isLocal
        ? 'Email delivery (RESEND_API_KEY) is not configured yet on localhost. Use the local test reset link below:'
        : genericMessage,
      devResetUrl: isLocal ? resetUrl : undefined,
    });
  } catch {
    return NextResponse.json({ error: 'Unable to process reset request.' }, { status: 500 });
  }
}
