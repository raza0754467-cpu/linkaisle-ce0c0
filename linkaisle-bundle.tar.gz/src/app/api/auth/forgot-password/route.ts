import crypto from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import { getDb, persistDbToCloud } from '@/lib/db';
import { checkRateLimit } from '@/lib/rate-limit';
import { isResendConfigured, sendPasswordResetEmail } from '@/lib/email';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'local';
  const rl = checkRateLimit(`forgot:${ip}`, 8, 15 * 60_000);
  if (!rl.allowed) {
    return NextResponse.json(
      { error: 'Too many reset requests. Please try again in a few minutes.' },
      { status: 429 }
    );
  }

  try {
    const body = await req.json();
    const email = String(body.email || '').trim().toLowerCase();
    if (!email || !email.includes('@')) {
      return NextResponse.json({ error: 'Please enter a valid email address.' }, { status: 400 });
    }

    const db = getDb();
    const user = db
      .prepare('SELECT id, name, email FROM users WHERE email = ?')
      .get(email) as { id: string; name: string; email: string } | undefined;

    // Always return generic success message to prevent email enumeration
    const genericMessage =
      'If an account exists with that email, a password reset link has been sent.';

    if (!user) {
      return NextResponse.json({ ok: true, message: genericMessage });
    }

    const token = crypto.randomBytes(32).toString('hex');
    const now = new Date();
    const expires = new Date(now.getTime() + 60 * 60 * 1000); // 1 hour

    db.prepare('DELETE FROM password_resets WHERE user_id = ?').run(user.id);
    db.prepare(
      'INSERT INTO password_resets (token, user_id, expires_at, used, created_at) VALUES (?, ?, ?, 0, ?)'
    ).run(token, user.id, expires.toISOString(), now.toISOString());
    await persistDbToCloud();

    const origin =
      process.env.NEXT_PUBLIC_SITE_URL?.replace(/\/$/, '') ||
      req.nextUrl.origin ||
      'http://localhost:3000';
    const resetUrl = `${origin}/reset-password?token=${token}`;

    // Send real email via Resend Free Tier (3,000 free emails/month) if configured
    if (isResendConfigured()) {
      const mailRes = await sendPasswordResetEmail({
        to: user.email,
        name: user.name,
        resetUrl,
      });
      if (!mailRes.sent) {
        console.error('Resend email error:', mailRes.error);
      }
      return NextResponse.json({ ok: true, message: genericMessage });
    }

    // Local / unconfigured SMTP fallback: log securely to server console for testing
    console.log(`[LinkAisle Password Reset] ${user.email} -> ${resetUrl}`);
    const isLocal = origin.includes('localhost') || origin.includes('127.0.0.1');
    return NextResponse.json({
      ok: true,
      message: isLocal
        ? 'Email delivery (RESEND_API_KEY) is not configured yet on localhost. Use the local test reset link below:'
        : genericMessage,
      devResetUrl: isLocal ? resetUrl : undefined,
    });
  } catch {
    return NextResponse.json({ error: 'Unable to process reset request.' }, { status: 500 });
  }
}
