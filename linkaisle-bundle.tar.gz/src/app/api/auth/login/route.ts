import { NextRequest, NextResponse } from 'next/server';
import { getDb, refreshDbFromCloudSync, verifyPassword } from '@/lib/db';
import { createSession } from '@/lib/auth';
import { checkRateLimit } from '@/lib/rate-limit';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  try {
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'local';
    const rl = checkRateLimit(`login:${ip}`, 30, 15 * 60 * 1000);
    if (!rl.allowed) {
      return NextResponse.json(
        { error: `Too many sign-in attempts. Please retry in ${rl.retryAfterSeconds}s.` },
        { status: 429 }
      );
    }

    const body = await req.json();
    const email = String(body.email || '').trim().toLowerCase();
    const password = String(body.password || '');

    if (!email || !password) {
      return NextResponse.json({ error: 'Email and password are required.' }, { status: 400 });
    }

    let db = getDb();
    let user = db
      .prepare('SELECT id, name, email, password_hash, role, plan, status FROM users WHERE email = ?')
      .get(email) as
      | {
          id: string;
          name: string;
          email: string;
          password_hash: string;
          role: string;
          plan: string;
          status: string;
        }
      | undefined;

    if ((!user || !verifyPassword(password, user.password_hash)) && refreshDbFromCloudSync()) {
      db = getDb();
      user = db
        .prepare('SELECT id, name, email, password_hash, role, plan, status FROM users WHERE email = ?')
        .get(email) as typeof user;
    }

    if (!user || !verifyPassword(password, user.password_hash)) {
      return NextResponse.json({ error: 'Invalid email or password.' }, { status: 401 });
    }

    if (user.status === 'suspended') {
      return NextResponse.json({ error: 'This account has been suspended by the administrator.' }, { status: 403 });
    }

    await createSession(user.id);

    return NextResponse.json({
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        plan: user.plan,
        status: user.status,
      },
    });
  } catch (err) {
    console.error('Login error:', err);
    return NextResponse.json({ error: 'Failed to sign in.' }, { status: 500 });
  }
}
