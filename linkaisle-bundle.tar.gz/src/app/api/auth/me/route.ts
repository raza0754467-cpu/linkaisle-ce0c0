import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { getDb, getPlatformSettings } from '@/lib/db';

export const runtime = 'nodejs';

export async function GET() {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ user: null });
  }

  const db = getDb();
  const stores = db
    .prepare('SELECT * FROM stores WHERE user_id = ? ORDER BY created_at DESC')
    .all(user.id);
  const settings = getPlatformSettings();

  return NextResponse.json({
    user,
    stores,
    planLimit: settings.plan_limits[user.plan],
    platformName: settings.platform_name,
  });
}
