import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { checkRateLimit } from '@/lib/rate-limit';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'local';
  const rl = checkRateLimit(`magic:${ip}`, 10, 15 * 60_000);
  if (!rl.allowed) {
    return NextResponse.json(
      { error: 'Too many sign-in link requests. Please wait a few minutes.' },
      { status: 429 }
    );
  }

  try {
    const body = await req.json();
    const email = String(body.email || '').trim().toLowerCase();
    if (!email || !email.includes('@')) {
      return NextResponse.json({ error: 'Please enter a valid email address.' }, { status: 400 });
    }

    const db = getDb();
    const user = db.prepare('SELECT id, status FROM users WHERE email = ?').get(email) as
      | { id: string; status: string }
      | undefined;

    if (!user) {
      return NextResponse.json(
        { error: 'No verified LinkAisle account found with this email. Please register first.' },
        { status: 404 }
      );
    }
    if (user.status !== 'active') {
      return NextResponse.json({ error: 'This account is suspended.' }, { status: 403 });
    }

    const supabaseUrl = (process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL || '')
      .trim()
      .replace(/\/$/, '');
    const supabaseAnonKey = (process.env.SUPABASE_ANON_KEY || '').trim();
    const origin =
      process.env.NEXT_PUBLIC_SITE_URL?.replace(/\/$/, '') ||
      req.nextUrl.origin ||
      'https://linkaisle.netlify.app';

    if (!supabaseUrl || supabaseAnonKey.length <= 20) {
      return NextResponse.json(
        { error: 'Email sign-in links require Supabase Auth configuration.' },
        { status: 503 }
      );
    }

    const redirectTo = `${origin}/auth/callback`;
    const res = await fetch(
      `${supabaseUrl}/auth/v1/otp?redirect_to=${encodeURIComponent(redirectTo)}`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          apikey: supabaseAnonKey,
        },
        body: JSON.stringify({
          email,
          create_user: true,
        }),
      }
    );

    if (!res.ok) {
      const err = (await res.json().catch(() => ({}))) as { msg?: string; message?: string };
      return NextResponse.json(
        { error: err.msg || err.message || 'Could not send sign-in email. Please wait a minute and retry.' },
        { status: 400 }
      );
    }

    return NextResponse.json({
      ok: true,
      message: `A real one-time sign-in link has been sent to ${email}. Open your email inbox and click the link to sign in!`,
    });
  } catch {
    return NextResponse.json({ error: 'Failed to send sign-in link.' }, { status: 500 });
  }
}
