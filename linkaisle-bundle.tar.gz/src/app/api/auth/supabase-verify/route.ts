import crypto from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import { createId, getDb, hashPassword, persistDbToCloud, slugify } from '@/lib/db';
import { createSession } from '@/lib/auth';
import { STORE_TEMPLATES } from '@/lib/types';
import { sendWelcomeEmail } from '@/lib/email';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const accessToken = String(body.access_token || '').trim();

    const supabaseUrl = (process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL || '')
      .trim()
      .replace(/\/$/, '');
    const supabaseAnonKey = (process.env.SUPABASE_ANON_KEY || '').trim();

    if (!accessToken || !supabaseUrl || !supabaseAnonKey) {
      return NextResponse.json({ error: 'Invalid verification token.' }, { status: 400 });
    }

    // Cryptographically verify the token directly against Supabase Auth API
    const sbRes = await fetch(`${supabaseUrl}/auth/v1/user`, {
      headers: {
        apikey: supabaseAnonKey,
        Authorization: `Bearer ${accessToken}`,
      },
    });

    if (!sbRes.ok) {
      return NextResponse.json(
        { error: 'Verification link expired or invalid. Please request a new link.' },
        { status: 401 }
      );
    }

    const sbUser = (await sbRes.json()) as {
      email?: string;
      email_confirmed_at?: string;
      user_metadata?: { name?: string; full_name?: string; store_name?: string };
    };

    const email = (sbUser.email || '').trim().toLowerCase();
    if (!email || !sbUser.email_confirmed_at) {
      return NextResponse.json(
        { error: 'Email address has not been confirmed yet.' },
        { status: 403 }
      );
    }

    const db = getDb();
    let existingUser = db
      .prepare('SELECT id, name, email, role, plan, status FROM users WHERE email = ?')
      .get(email) as
      | { id: string; name: string; email: string; role: 'user' | 'admin'; plan: string; status: string }
      | undefined;

    if (existingUser && existingUser.status !== 'active') {
      return NextResponse.json({ error: 'This account is suspended.' }, { status: 403 });
    }

    if (!existingUser) {
      const pending = db
        .prepare('SELECT * FROM pending_registrations WHERE email = ?')
        .get(email) as
        | { email: string; name: string; password_hash: string; store_name: string; template: string }
        | undefined;

      const now = new Date().toISOString();
      const userId = createId('usr');
      const displayName =
        pending?.name ||
        sbUser.user_metadata?.name ||
        sbUser.user_metadata?.full_name ||
        email.split('@')[0];
      const passwordHash = pending?.password_hash || hashPassword(crypto.randomBytes(24).toString('hex'));
      const storeName = pending?.store_name || sbUser.user_metadata?.store_name || `${displayName}'s Store`;
      const tplId = pending?.template || 'kitchen';

      db.prepare(
        `INSERT INTO users (id, name, email, password_hash, role, plan, status, created_at)
         VALUES (?, ?, ?, ?, 'user', 'free', 'active', ?)`
      ).run(userId, displayName, email, passwordHash, now);

      let baseSlug = slugify(storeName) || 'my-store';
      if (db.prepare('SELECT id FROM stores WHERE slug = ?').get(baseSlug)) {
        baseSlug = `${baseSlug}-${Math.floor(100 + Math.random() * 900)}`;
      }
      const chosenTemplateObj = STORE_TEMPLATES.find((t) => t.id === tplId) || STORE_TEMPLATES[0];

      db.prepare(
        `INSERT INTO stores (
          id, user_id, slug, name, tagline, description, template,
          primary_color, accent_color, hero_title, hero_subtitle, hero_cta,
          contact_email, is_published, is_suspended, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Explore Top Picks', ?, 1, 0, ?, ?)`
      ).run(
        createId('str'),
        userId,
        baseSlug,
        storeName,
        'Handpicked affiliate deals & honest recommendations.',
        `Welcome to ${storeName}. Every product here is curated to save you time and money.`,
        chosenTemplateObj.id,
        chosenTemplateObj.defaultPrimary,
        chosenTemplateObj.defaultAccent,
        `Top Curated Picks by ${storeName}`,
        'Browse our handpicked collection of high-value products with direct merchant links.',
        email,
        now,
        now
      );

      db.prepare('DELETE FROM pending_registrations WHERE email = ?').run(email);

      const origin =
        process.env.NEXT_PUBLIC_SITE_URL?.replace(/\/$/, '') || 'https://linkaisle.netlify.app';
      void sendWelcomeEmail({
        to: email,
        name: displayName,
        storeName,
        storeUrl: `${origin}/s/${baseSlug}`,
        studioUrl: `${origin}/dashboard`,
      });

      existingUser = { id: userId, name: displayName, email, role: 'user', plan: 'free', status: 'active' };
    }

    await createSession(existingUser.id);
    await persistDbToCloud();

    return NextResponse.json({
      ok: true,
      user: existingUser,
      redirectTo: existingUser.role === 'admin' ? '/admin' : '/dashboard',
    });
  } catch (err) {
    console.error('Supabase verify error:', err);
    return NextResponse.json({ error: 'Verification failed. Please try again.' }, { status: 500 });
  }
}
