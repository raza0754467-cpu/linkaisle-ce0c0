import crypto from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { createSession } from '@/lib/auth';
import { getDb, hashPassword, slugify } from '@/lib/db';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const origin =
    process.env.NEXT_PUBLIC_SITE_URL?.replace(/\/$/, '') ||
    req.nextUrl.origin ||
    'http://localhost:3000';

  const code = req.nextUrl.searchParams.get('code');
  const state = req.nextUrl.searchParams.get('state');
  const cookieStore = await cookies();
  const savedState = cookieStore.get('linkaisle_oauth_state')?.value;
  cookieStore.delete('linkaisle_oauth_state');

  const clientId = (process.env.GOOGLE_CLIENT_ID || '').trim();
  const clientSecret = (process.env.GOOGLE_CLIENT_SECRET || '').trim();

  if (!code || !state || !savedState || state !== savedState || !clientId || !clientSecret) {
    return NextResponse.redirect(`${origin}/login?error=google_auth_failed`);
  }

  try {
    const redirectUri = `${origin}/api/auth/google/callback`;
    const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: clientId,
        client_secret: clientSecret,
        redirect_uri: redirectUri,
        grant_type: 'authorization_code',
      }),
    });

    if (!tokenRes.ok) {
      return NextResponse.redirect(`${origin}/login?error=google_auth_failed`);
    }

    const tokenJson = (await tokenRes.json()) as { access_token?: string };
    if (!tokenJson.access_token) {
      return NextResponse.redirect(`${origin}/login?error=google_auth_failed`);
    }

    const profileRes = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
      headers: { Authorization: `Bearer ${tokenJson.access_token}` },
    });
    if (!profileRes.ok) {
      return NextResponse.redirect(`${origin}/login?error=google_auth_failed`);
    }

    const profile = (await profileRes.json()) as {
      email?: string;
      name?: string;
      email_verified?: boolean;
    };

    const email = (profile.email || '').trim().toLowerCase();
    if (!email || !profile.email_verified) {
      return NextResponse.redirect(`${origin}/login?error=google_email_unverified`);
    }

    const db = getDb();
    let user = db
      .prepare('SELECT id, role, status FROM users WHERE email = ?')
      .get(email) as { id: string; role: 'user' | 'admin'; status: string } | undefined;

    if (user && user.status !== 'active') {
      return NextResponse.redirect(`${origin}/login?error=account_suspended`);
    }

    if (!user) {
      const now = new Date().toISOString();
      const userId = `usr_${crypto.randomBytes(6).toString('hex')}`;
      const displayName = (profile.name || email.split('@')[0]).trim();
      const randomPass = crypto.randomBytes(24).toString('hex');

      db.prepare(
        'INSERT INTO users (id, name, email, password_hash, role, plan, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
      ).run(userId, displayName, email, hashPassword(randomPass), 'user', 'free', 'active', now);

      // Provision instant free storefront for new Google users
      const baseSlug = slugify(displayName) || 'my-store';
      let finalSlug = baseSlug;
      let counter = 2;
      while (db.prepare('SELECT id FROM stores WHERE slug = ?').get(finalSlug)) {
        finalSlug = `${baseSlug}-${counter++}`;
      }

      const storeId = `str_${crypto.randomBytes(6).toString('hex')}`;
      db.prepare(
        `INSERT INTO stores (
          id, user_id, slug, name, tagline, description, template,
          primary_color, accent_color, hero_title, hero_subtitle, hero_cta,
          disclosure_text, contact_email, target_country, currency, is_published, is_suspended, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 0, ?, ?)`
      ).run(
        storeId,
        userId,
        finalSlug,
        `${displayName}'s Picks`,
        'Curated everyday finds with verified merchant links.',
        'Handpicked deals organized in one clean storefront.',
        'kitchen',
        '#047857',
        '#111315',
        `${displayName}'s Curated Finds`,
        'Explore top-rated products with transparent merchant checkout.',
        'Browse Curated Deals',
        'Affiliate Disclosure: We may earn a small commission on qualifying purchases made through links on this storefront at no extra cost to you.',
        email,
        'US',
        'USD',
        now,
        now
      );

      user = { id: userId, role: 'user', status: 'active' };
    }

    await createSession(user.id);
    return NextResponse.redirect(`${origin}${user.role === 'admin' ? '/admin' : '/dashboard'}`);
  } catch {
    return NextResponse.redirect(`${origin}/login?error=google_auth_failed`);
  }
}
