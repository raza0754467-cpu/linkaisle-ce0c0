import { NextRequest, NextResponse } from 'next/server';
import { createId, getDb, persistDbToCloud } from '@/lib/db';
import { checkRateLimit } from '@/lib/rate-limit';

export const runtime = 'nodejs';

export async function GET(
  _req: NextRequest,
  context: { params: Promise<{ productId: string }> }
) {
  const { productId } = await context.params;
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT id, product_id, author_name, rating, comment, created_at
       FROM product_reviews
       WHERE product_id = ?
       ORDER BY created_at DESC
       LIMIT 50`
    )
    .all(productId) as unknown as {
    id: string;
    product_id: string;
    author_name: string;
    rating: number;
    comment: string;
    created_at: string;
  }[];

  const avg =
    rows.length > 0
      ? Number((rows.reduce((sum, r) => sum + Number(r.rating), 0) / rows.length).toFixed(1))
      : null;

  return NextResponse.json({
    reviews: rows.map((r) => ({ ...r })),
    count: rows.length,
    averageRating: avg,
  });
}

export async function POST(
  req: NextRequest,
  context: { params: Promise<{ productId: string }> }
) {
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'local';
  const rl = checkRateLimit(`review:${ip}`, 10, 15 * 60_000);
  if (!rl.allowed) {
    return NextResponse.json(
      { error: 'Too many review submissions. Please wait a few minutes.' },
      { status: 429 }
    );
  }

  try {
    const { productId } = await context.params;
    const body = await req.json();
    const authorName = String(body.author_name || '').trim().slice(0, 60);
    const comment = String(body.comment || '').trim().slice(0, 800);
    const rating = Math.min(5, Math.max(1, Math.round(Number(body.rating || 5))));

    if (authorName.length < 2) {
      return NextResponse.json({ error: 'Please enter your name (at least 2 characters).' }, { status: 400 });
    }
    if (comment.length < 8) {
      return NextResponse.json(
        { error: 'Please write a helpful comment (at least 8 characters).' },
        { status: 400 }
      );
    }

    const db = getDb();
    const product = db.prepare('SELECT id FROM products WHERE id = ?').get(productId);
    if (!product) {
      return NextResponse.json({ error: 'Product not found.' }, { status: 404 });
    }

    const id = createId('rev');
    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO product_reviews (id, product_id, author_name, rating, comment, created_at)
       VALUES (?, ?, ?, ?, ?, ?)`
    ).run(id, productId, authorName, rating, comment, now);

    // Update product's real LinkAisle community rating & review count
    const stats = db
      .prepare('SELECT COUNT(*) as cnt, AVG(rating) as avg_rating FROM product_reviews WHERE product_id = ?')
      .get(productId) as { cnt: number; avg_rating: number };

    db.prepare('UPDATE products SET rating = ?, review_count = ? WHERE id = ?').run(
      Number((stats.avg_rating || rating).toFixed(1)),
      stats.cnt,
      productId
    );

    await persistDbToCloud();

    return NextResponse.json(
      {
        review: {
          id,
          product_id: productId,
          author_name: authorName,
          rating,
          comment,
          created_at: now,
        },
        count: stats.cnt,
        averageRating: Number((stats.avg_rating || rating).toFixed(1)),
      },
      { status: 201 }
    );
  } catch {
    return NextResponse.json({ error: 'Failed to submit review.' }, { status: 500 });
  }
}
