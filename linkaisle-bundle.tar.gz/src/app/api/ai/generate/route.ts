import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { checkRateLimit } from '@/lib/rate-limit';
import { extractJsonObject, generateWithFreeAi, getAiArchitectureStatus } from '@/lib/ai-provider';

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  return NextResponse.json(getAiArchitectureStatus());
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'local';
  const rl = checkRateLimit(`ai:${user.id}:${ip}`, 30, 60_000);
  if (!rl.allowed) {
    return NextResponse.json(
      { error: 'Too many AI requests. Please wait a minute and try again.' },
      { status: 429 }
    );
  }

  try {
    const body = await req.json();
    const task = String(body.task || '').trim();

    if (task === 'product_copy') {
      const title = String(body.title || '').trim();
      const category = String(body.category || 'Everyday Essentials').trim();
      const merchant = String(body.merchant_name || 'Amazon').trim();
      const price = String(body.price_display || '').trim();
      const countries = Array.isArray(body.available_countries)
        ? body.available_countries.join(', ')
        : 'US';

      if (!title) {
        return NextResponse.json({ error: 'Enter a product title first.' }, { status: 400 });
      }

      const fallbackObj = {
        short_description: `Practical ${category.toLowerCase()} upgrade designed to save time and deliver dependable everyday value via ${merchant}.`,
        description: `${title} is curated for shoppers looking for reliable performance without overpaying. Whether you use it daily at home or gift it to someone upgrading their ${category.toLowerCase()} setup, it combines clean design, straightforward usability, and strong buyer ratings on ${merchant}. Always verify the latest live price and shipping eligibility (${countries}) directly on ${merchant} before checkout.`,
        benefits: [
          `Carefully selected for practical daily ${category.toLowerCase()} performance`,
          `Direct official checkout & buyer protection on ${merchant}`,
          price ? `Strong value around ${price} compared to bulkier alternatives` : 'Great everyday value without unnecessary clutter',
          `Clean, beginner-friendly setup that works right out of the box`,
        ],
        badge: 'Top Pick',
      };

      const res = await generateWithFreeAi({
        systemPrompt:
          'You are an honest, conversion-focused e-commerce product copywriter for LinkAisle. Never make fake medical or income guarantees. Return ONLY valid JSON with keys: short_description (1 crisp sentence, max 130 chars), description (2 concise paragraphs, honest editorial tone), benefits (array of exactly 4 short bullet strings), badge (1-2 word badge like "Top Pick" or "Best Value").',
        userPrompt: `Product Title: ${title}\nCategory: ${category}\nMerchant: ${merchant}\nPrice: ${price || 'Check live price'}\nTarget Regions: ${countries}`,
        fallback: () => JSON.stringify(fallbackObj),
      });

      const parsed = extractJsonObject<typeof fallbackObj>(res.text) || fallbackObj;
      return NextResponse.json({
        data: {
          short_description: String(parsed.short_description || fallbackObj.short_description),
          description: String(parsed.description || fallbackObj.description),
          benefits: Array.isArray(parsed.benefits) && parsed.benefits.length > 0
            ? parsed.benefits.map((b) => String(b)).slice(0, 5)
            : fallbackObj.benefits,
          badge: String(parsed.badge || 'Top Pick'),
        },
        provider: res.provider,
        providerLabel: res.providerLabel,
        usedCloudAi: res.usedCloudAi,
      });
    }

    if (task === 'seo_guide') {
      const title = String(body.title || '').trim();
      const category = String(body.category || 'Buyer Guides').trim();
      const storeName = String(body.store_name || 'Our Curated Store').trim();
      const products = Array.isArray(body.products) ? body.products.slice(0, 6) : [];

      if (!title) {
        return NextResponse.json({ error: 'Enter an article title first.' }, { status: 400 });
      }

      const productLines = products
        .map(
          (p: { title?: string; price_display?: string; merchant_name?: string }) =>
            `- **${p.title || 'Featured Pick'}** (${p.price_display || 'Check Live Price'} on ${p.merchant_name || 'Merchant'})`
        )
        .join('\n');

      const fallbackObj = {
        excerpt: `An honest, practical ${category.toLowerCase()} comparison from ${storeName} helping you choose the right gear without wasting money.`,
        content: `## Why Choosing the Right ${category} Matters\nBuying online can feel overwhelming when dozens of nearly identical listings compete for attention. In this guide from ${storeName}, we focus on practical value, durability, and real everyday usefulness.\n\n## What to Look For Before You Buy\n- **Build Quality & Daily Utility:** Prioritize items you will actually use every week.\n- **Transparent Merchant Checkout:** Always confirm live pricing, shipping region, and return policies directly on the official retailer.\n- **Clean Footprint:** Compact, easy-to-maintain upgrades beat oversized gadgets every time.\n\n## Top Curated Picks to Check Out\n${productLines || '- Explore the featured products embedded below for current deals and ratings.'}\n\n## Final Verdict\nCompare the embedded picks below based on your budget and country availability, and always check the latest live merchant price before ordering.`,
        seo_title: `${title} | ${storeName} Buying Guide`,
        seo_description: `Compare the best curated ${category.toLowerCase()} picks in ${title}. Honest highlights, country availability, and direct merchant deal links.`,
      };

      const res = await generateWithFreeAi({
        systemPrompt:
          'You are an editorial SEO buying-guide writer. Write helpful, transparent, human-sounding buying guides in clean Markdown (using ## headings and - bullet points). Never make fake claims. Return ONLY valid JSON with keys: excerpt, content, seo_title, seo_description.',
        userPrompt: `Guide Title: ${title}\nCategory: ${category}\nStore Name: ${storeName}\nStore Products to mention naturally:\n${productLines || 'General niche picks'}`,
        fallback: () => JSON.stringify(fallbackObj),
      });

      const parsed = extractJsonObject<typeof fallbackObj>(res.text) || fallbackObj;
      return NextResponse.json({
        data: {
          excerpt: String(parsed.excerpt || fallbackObj.excerpt),
          content: String(parsed.content || fallbackObj.content),
          seo_title: String(parsed.seo_title || fallbackObj.seo_title),
          seo_description: String(parsed.seo_description || fallbackObj.seo_description),
        },
        provider: res.provider,
        providerLabel: res.providerLabel,
        usedCloudAi: res.usedCloudAi,
      });
    }

    if (task === 'viral_script') {
      const lang = body.lang === 'ur' ? 'ur' : 'en';
      const storeName = String(body.store_name || 'LinkAisle Store').trim();
      const storeUrl = String(body.store_url || 'https://linkaisle.com').trim();
      const product = body.product || null;

      const targetDesc = product
        ? `Single Product: ${product.title} (${product.price_display || 'Deal'}, Category: ${product.category || 'Finds'})`
        : `Entire Curated Store Collection: ${storeName}`;

      const fallbackObj = {
        videoScript:
          lang === 'ur'
            ? `🎬 20-SECOND VIRAL REEL / TIKTOK SCRIPT (Roman Urdu)\n\n[0-3s HOOK]\n"Agar aap online shopping me time aur paise dono bachana chahte hain to yeh dekhein!"\n\n[3-14s SHOWCASE]\n"${product ? product.title : storeName} — bilkul practical aur tested finds ek hi saaf store me arrange kiye gaye hain."\n\n[15-20s CTA]\n"Bio me '${storeName}' ka link mojood hai — direct live price check kar lein!"\n🔗 ${storeUrl}?src=tiktok`
            : `🎬 20-SECOND TIKTOK / REELS SCRIPT\n\n[0-3s HOOK]\n"Stop scrolling through hundreds of random listings — here is a cleaner way to find real deals."\n\n[3-14s SHOWCASE]\n"Check out ${product ? product.title : storeName}: practical everyday upgrades organized cleanly with direct merchant links."\n\n[15-20s CTA]\n"Full list is in my bio link under '${storeName}'!"\n🔗 ${storeUrl}?src=tiktok`,
        fbAdCopy:
          lang === 'ur'
            ? `📣 FACEBOOK / INSTAGRAM POST\n\nHeadline: ${product ? product.title : `Top Useful Finds — ${storeName}`}\n\nRoz ke kaam ko aasan banane wale handpicked products ab ek hi clean page par dekhein aur official store par live price verify karein.\n\n👉 Store Kholein: ${storeUrl}?src=facebook\n(Affiliate Disclosure: Eligible purchases par humein chhota commission mil sakta hai.)`
            : `📣 FACEBOOK / INSTAGRAM POST\n\nHeadline: ${product ? `${product.title} (${product.price_display || 'Curated Pick'})` : `Handpicked Everyday Upgrades — ${storeName}`}\n\nSkip the clutter and browse curated finds with clear highlights and direct official checkout.\n\n👉 Explore Now: ${storeUrl}?src=facebook\n(Disclosure: Affiliate links — we may earn a commission on qualifying purchases.)`,
        pinterestCopy: `📌 PIN TITLE: ${product ? product.title : `${storeName} Curated Deals`}\n\n📌 PIN DESCRIPTION: Save this handpicked pick from ${storeName} and check current merchant pricing anytime.\n🔗 ${storeUrl}?src=pinterest`,
      };

      const res = await generateWithFreeAi({
        systemPrompt: `You are a short-form social media strategist for affiliate creators. Write natural, non-spammy, high-retention promotion copy in ${
          lang === 'ur' ? 'natural everyday Roman Urdu (Pakistani/South Asian audience)' : 'crisp modern English'
        }. Always include a short affiliate disclosure reminder where appropriate and never promise guaranteed income. Return ONLY valid JSON with keys: videoScript, fbAdCopy, pinterestCopy.`,
        userPrompt: `Target: ${targetDesc}\nStore Name: ${storeName}\nStore Base URL: ${storeUrl}\nLanguage: ${lang === 'ur' ? 'Roman Urdu' : 'English'}`,
        fallback: () => JSON.stringify(fallbackObj),
      });

      const parsed = extractJsonObject<typeof fallbackObj>(res.text) || fallbackObj;
      return NextResponse.json({
        data: {
          videoScript: String(parsed.videoScript || fallbackObj.videoScript),
          fbAdCopy: String(parsed.fbAdCopy || fallbackObj.fbAdCopy),
          pinterestCopy: String(parsed.pinterestCopy || fallbackObj.pinterestCopy),
        },
        provider: res.provider,
        providerLabel: res.providerLabel,
        usedCloudAi: res.usedCloudAi,
      });
    }

    return NextResponse.json({ error: 'Unsupported AI task' }, { status: 400 });
  } catch {
    return NextResponse.json({ error: 'Failed to run AI generator' }, { status: 500 });
  }
}
