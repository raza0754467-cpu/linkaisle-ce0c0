import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { checkRateLimit } from '@/lib/rate-limit';
import { generateWithFreeAi } from '@/lib/ai-provider';
import { formatCountryLabel } from '@/lib/types';

export const runtime = 'nodejs';

interface ChatMsg {
  role: 'user' | 'assistant';
  content: string;
}

export async function POST(req: NextRequest) {
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'local';
  const rl = checkRateLimit(`ai-chat:${ip}`, 25, 60_000);
  if (!rl.allowed) {
    return NextResponse.json(
      { error: 'Too many messages. Please wait a minute and try again.' },
      { status: 429 }
    );
  }

  try {
    const body = await req.json();
    const rawMessages = Array.isArray(body.messages) ? (body.messages as ChatMsg[]) : [];
    const pathname = String(body.pathname || '/').trim();

    const cleanHistory = rawMessages
      .filter((m) => (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string')
      .map((m) => ({ role: m.role, content: m.content.trim().slice(0, 1000) }))
      .filter((m) => m.content.length > 0)
      .slice(-8);

    const lastUserMessage = [...cleanHistory].reverse().find((m) => m.role === 'user')?.content || '';
    if (!lastUserMessage) {
      return NextResponse.json({ error: 'Please type a message.' }, { status: 400 });
    }

    // Build real database context depending on the page the visitor is viewing
    let pageContext = 'The user is browsing the main LinkAisle website (a free affiliate storefront builder & learning platform where anyone can create a curated product store at /s/your-store with zero domain or hosting required).';
    let mode: 'store' | 'dashboard' | 'support' = 'support';

    const storeMatch = pathname.match(/^\/s\/([^/?#]+)(?:\/p\/([^/?#]+))?/);
    if (storeMatch) {
      mode = 'store';
      const storeSlug = decodeURIComponent(storeMatch[1]);
      const productSlug = storeMatch[2] ? decodeURIComponent(storeMatch[2]) : null;
      const db = getDb();
      const store = db
        .prepare(
          'SELECT id, name, tagline, target_country, currency, disclosure_text FROM stores WHERE slug = ? AND is_published = 1 AND is_suspended = 0'
        )
        .get(storeSlug) as
        | {
            id: string;
            name: string;
            tagline: string;
            target_country: string;
            currency: string;
            disclosure_text: string;
          }
        | undefined;

      if (store) {
        const products = db
          .prepare(
            'SELECT title, slug, category, price_display, original_price, merchant_name, short_description, available_countries FROM products WHERE store_id = ? AND status = ? ORDER BY is_featured DESC, created_at DESC LIMIT 12'
          )
          .all(store.id, 'published') as unknown as {
          title: string;
          slug: string;
          category: string;
          price_display: string;
          original_price: string;
          merchant_name: string;
          short_description: string;
          available_countries: string;
        }[];

        const catalogText = products
          .map((p) => {
            let countries = 'US';
            try {
              const arr = JSON.parse(p.available_countries || '["US"]') as string[];
              countries = arr.map((c) => formatCountryLabel(c)).join(', ');
            } catch {}
            return `- ${p.title} (${p.category}) | Price: ${p.price_display}${
              p.original_price ? ` (was ${p.original_price})` : ''
            } | Merchant: ${p.merchant_name} | Ships to: ${countries} | Pitch: ${p.short_description}`;
          })
          .join('\n');

        const activeProd = productSlug ? products.find((p) => p.slug === productSlug) : null;
        pageContext = `The visitor is shopping inside the live storefront "${store.name}" (${store.tagline}). Primary market: ${formatCountryLabel(
          store.target_country
        )} (${store.currency}).${
          activeProd ? `\nCurrently viewing product listing: "${activeProd.title}" (${activeProd.price_display} on ${activeProd.merchant_name}).` : ''
        }\nLive published catalog in this store:\n${catalogText || 'No products listed yet.'}\nNote: Buyers click "Check Live Price & Deal" to complete official checkout directly on the merchant website (like Amazon or Impact brands).`;
      }
    } else if (pathname.startsWith('/dashboard') || pathname.startsWith('/admin')) {
      mode = 'dashboard';
      pageContext =
        'The user is signed into the LinkAisle Creator Studio / Owner Control Center. They may ask for help creating high-converting product listings, writing titles/descriptions, adding affiliate links (Amazon Associates, Impact.com), choosing target countries, using the AI Price & Link Reviser, or promoting their storefront organically.';
    }

    const transcript = cleanHistory
      .map((m) => `${m.role === 'user' ? 'User' : 'Assistant'}: ${m.content}`)
      .join('\n');

    const systemPrompt = `You are LinkAisle AI — a friendly, knowledgeable, multilingual customer support, shopping concierge, and creator copilot built into LinkAisle.

STRICT RULES:
1. Reply in the EXACT SAME LANGUAGE the user wrote in (English, Urdu, Roman Urdu, Arabic, Hindi, Spanish, French, etc.). If unclear, reply in crisp, friendly English.
2. Keep answers concise, practical, and easy to read (2–5 short sentences or quick bullets).
3. Be 100% honest: never promise guaranteed income, never invent fake products or fake prices not present in the catalog, and remind shoppers that final prices/shipping are confirmed directly on the official merchant checkout page.
4. For customer support questions about LinkAisle: explain that anyone can start free at /register (no domain or coding needed, instant /s/your-store link, 5 light themes, country filters, AI listing tools, real click analytics, and free Academy).

CURRENT PAGE CONTEXT:
${pageContext}`;

    const aiRes = await generateWithFreeAi({
      systemPrompt,
      userPrompt: `Conversation so far:\n${transcript}\n\nRespond helpfully to the latest user message.`,
      fallback: () =>
        mode === 'store'
          ? 'Hi! I can help you compare products in this store, check deliverable countries, or explain how direct merchant checkout works. Click any product card to open its full listing page and verify the live merchant deal.'
          : mode === 'dashboard'
            ? 'Hi! Inside Creator Studio you can click "AI Auto-Write" when adding a product, run "AI Price & Link Reviser" to audit links & quality scores, or draft SEO guides and social scripts in one click.'
            : 'Welcome to LinkAisle! You can launch a free affiliate storefront in minutes at /register (no domain required), learn step-by-step in /academy, or browse curated deals right on the homepage. What can I help you with?',
    });

    return NextResponse.json({
      reply: aiRes.text,
      providerLabel: aiRes.providerLabel,
      usedCloudAi: aiRes.usedCloudAi,
      mode,
    });
  } catch {
    return NextResponse.json({ error: 'Unable to answer right now. Please try again.' }, { status: 500 });
  }
}
