import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import {
  detectReferrerSource,
  detectVisitorCountry,
  hashVisitor,
  recordAnalyticsEvent,
} from '@/lib/analytics';

export const runtime = 'nodejs';

export async function GET(
  req: NextRequest,
  context: { params: Promise<{ productId: string }> }
) {
  const { productId } = await context.params;
  const db = getDb();

  const product = db
    .prepare(
      `SELECT p.id, p.store_id, p.affiliate_url, s.is_suspended
       FROM products p
       JOIN stores s ON s.id = p.store_id
       WHERE p.id = ? AND p.status = 'published'`
    )
    .get(productId) as
    | { id: string; store_id: string; affiliate_url: string; is_suspended: number }
    | undefined;

  if (!product || product.is_suspended) {
    return NextResponse.redirect(new URL('/', req.url));
  }

  try {
    const dest = new URL(product.affiliate_url);
    if (dest.protocol !== 'http:' && dest.protocol !== 'https:') {
      return NextResponse.redirect(new URL('/', req.url));
    }

    const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || '127.0.0.1';
    const ua = req.headers.get('user-agent') || 'unknown';
    const ref = req.headers.get('referer') || '';
    const utm = req.nextUrl.searchParams.get('src') || '';
    const countryHint = req.nextUrl.searchParams.get('country') || '';

    recordAnalyticsEvent({
      eventType: 'product_click',
      storeId: product.store_id,
      productId: product.id,
      referrerSource: detectReferrerSource(ref, utm),
      visitorHash: hashVisitor(ip, ua),
      country: detectVisitorCountry(req.headers, countryHint),
    });

    return NextResponse.redirect(dest.toString(), { status: 302 });
  } catch {
    return NextResponse.redirect(new URL('/', req.url));
  }
}
