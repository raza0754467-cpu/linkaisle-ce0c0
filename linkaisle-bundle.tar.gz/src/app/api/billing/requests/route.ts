import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { createId, getDb, getPlatformSettings } from '@/lib/db';
import { checkRateLimit } from '@/lib/rate-limit';

export const runtime = 'nodejs';

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const db = getDb();
  const settings = getPlatformSettings();
  const requests = db
    .prepare('SELECT * FROM upgrade_requests WHERE user_id = ? ORDER BY created_at DESC')
    .all(user.id);

  return NextResponse.json({
    currentPlan: user.plan,
    planLimits: settings.plan_limits,
    paymentInstructions: settings.monetization.payment_instructions,
    requests,
  });
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const rl = checkRateLimit(`billing:${user.id}`, 10, 15 * 60 * 1000);
    if (!rl.allowed) {
      return NextResponse.json(
        { error: `Too many billing submissions. Please wait ${rl.retryAfterSeconds}s.` },
        { status: 429 }
      );
    }

    const body = await req.json();
    const requestedPlan = String(body.requested_plan || '');
    const billingCycle = body.billing_cycle === 'yearly' ? 'yearly' : 'monthly';
    const paymentMethod = String(body.payment_method || '').trim();
    const transactionRef = String(body.transaction_ref || '').trim();
    const notes = String(body.notes || '').trim();

    if (requestedPlan !== 'starter' && requestedPlan !== 'pro') {
      return NextResponse.json({ error: 'Please select Starter or Pro plan.' }, { status: 400 });
    }
    if (!paymentMethod) {
      return NextResponse.json({ error: 'Please choose a payment method.' }, { status: 400 });
    }
    if (!transactionRef || transactionRef.length < 3) {
      return NextResponse.json(
        { error: 'Please provide a valid Transaction ID or Payment Reference.' },
        { status: 400 }
      );
    }

    const settings = getPlatformSettings();
    const monthlyPrice = settings.plan_limits[requestedPlan].price;
    const amountUsd =
      billingCycle === 'yearly' ? Number((monthlyPrice * 12 * 0.8).toFixed(2)) : monthlyPrice;

    const db = getDb();
    const id = createId('upg');
    const now = new Date().toISOString();

    db.prepare(
      `INSERT INTO upgrade_requests (
        id, user_id, requested_plan, billing_cycle, amount_usd,
        payment_method, transaction_ref, notes, status, admin_note, created_at, reviewed_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', '', ?, '')`
    ).run(id, user.id, requestedPlan, billingCycle, amountUsd, paymentMethod, transactionRef, notes, now);

    const created = db.prepare('SELECT * FROM upgrade_requests WHERE id = ?').get(id);
    return NextResponse.json({ request: created }, { status: 201 });
  } catch (err) {
    console.error('Upgrade request error:', err);
    return NextResponse.json({ error: 'Failed to submit upgrade request.' }, { status: 500 });
  }
}
