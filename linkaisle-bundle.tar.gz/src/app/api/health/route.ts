import { NextResponse } from 'next/server';
import { getDb, getPlatformSettings } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const db = getDb();
    const settings = getPlatformSettings();
    const stats = db
      .prepare(
        `SELECT
          (SELECT COUNT(*) FROM users) as users,
          (SELECT COUNT(*) FROM stores WHERE is_published = 1 AND is_suspended = 0) as live_stores,
          (SELECT COUNT(*) FROM products WHERE status = 'published') as live_products`
      )
      .get() as { users: number; live_stores: number; live_products: number };

    return NextResponse.json({
      status: 'healthy',
      platform: settings.platform_name,
      database: 'sqlite-connected',
      uptimeSeconds: Math.round(process.uptime()),
      timestamp: new Date().toISOString(),
      counts: {
        users: Number(stats.users),
        liveStores: Number(stats.live_stores),
        liveProducts: Number(stats.live_products),
      },
    });
  } catch (err) {
    console.error('Health check failed:', err);
    return NextResponse.json({ status: 'unhealthy' }, { status: 500 });
  }
}
