import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { getAiArchitectureStatus } from '@/lib/ai-provider';
import { isSupabaseStorageReady } from '@/lib/supabase-storage';
import { isResendConfigured } from '@/lib/email';

export const runtime = 'nodejs';

export async function GET() {
  try {
    const db = getDb();
    const row = db.prepare('SELECT COUNT(*) as stores FROM stores').get() as { stores: number };
    const ai = getAiArchitectureStatus();
    return NextResponse.json({
      status: 'ok',
      platform: 'LinkAisle',
      stores: row.stores,
      integrations: {
        cloudAiActive: ai.configured,
        aiProvider: ai.providerName,
        supabasePersistence: isSupabaseStorageReady(),
        resendEmailActive: isResendConfigured(),
        googleOAuthConfigured: Boolean(
          (process.env.GOOGLE_CLIENT_ID || '').trim() &&
            (process.env.GOOGLE_CLIENT_SECRET || '').trim()
        ),
      },
      timestamp: new Date().toISOString(),
    });
  } catch {
    return NextResponse.json({ status: 'error' }, { status: 500 });
  }
}
