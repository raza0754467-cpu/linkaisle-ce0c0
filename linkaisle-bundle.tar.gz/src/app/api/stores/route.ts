import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { createId, getDb, getPlatformSettings, slugify } from '@/lib/db';
import { STORE_TEMPLATES } from '@/lib/types';

export const runtime = 'nodejs';

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const db = getDb();
  const stores = db
    .prepare(
      `SELECT s.*,
        (SELECT COUNT(*) FROM products p WHERE p.store_id = s.id) as product_count,
        (SELECT COUNT(*) FROM blog_posts b WHERE b.store_id = s.id) as post_count,
        (SELECT COUNT(*) FROM analytics_events e WHERE e.store_id = s.id AND e.event_type = 'store_visit') as total_visits,
        (SELECT COUNT(*) FROM analytics_events e WHERE e.store_id = s.id AND e.event_type = 'product_click') as total_clicks
       FROM stores s
       WHERE s.user_id = ?
       ORDER BY s.created_at DESC`
    )
    .all(user.id);

  return NextResponse.json({ stores });
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const db = getDb();
    const settings = getPlatformSettings();
    const limit = settings.plan_limits[user.plan];

    const countRow = db
      .prepare('SELECT COUNT(*) as count FROM stores WHERE user_id = ?')
      .get(user.id) as { count: number };

    if (user.role !== 'admin' && countRow.count >= limit.maxStores) {
      return NextResponse.json(
        { error: `Your ${limit.label} plan allows up to ${limit.maxStores} store(s). Upgrade to create more.` },
        { status: 403 }
      );
    }

    const body = await req.json();
    const name = String(body.name || '').trim();
    const rawSlug = String(body.slug || name).trim();
    const templateId = String(body.template || 'kitchen').trim();
    const tagline = String(body.tagline || 'Curated affiliate products & honest buying guides.').trim();

    if (!name || name.length < 2) {
      return NextResponse.json({ error: 'Store name must be at least 2 characters.' }, { status: 400 });
    }

    const slug = slugify(rawSlug);
    const conflict = db.prepare('SELECT id FROM stores WHERE slug = ?').get(slug);
    if (conflict) {
      return NextResponse.json({ error: `The store URL "/s/${slug}" is already taken. Try another slug.` }, { status: 409 });
    }

    const template = STORE_TEMPLATES.find((t) => t.id === templateId) || STORE_TEMPLATES[0];
    const storeId = createId('str');
    const now = new Date().toISOString();

    db.prepare(
      `INSERT INTO stores (
        id, user_id, slug, name, tagline, description, template,
        primary_color, accent_color, logo_url, hero_title, hero_subtitle, hero_cta,
        contact_email, is_published, is_suspended, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, '', ?, ?, 'Explore Deals', ?, 1, 0, ?, ?)`
    ).run(
      storeId,
      user.id,
      slug,
      name,
      tagline,
      `Welcome to ${name}. Explore our carefully researched affiliate product recommendations.`,
      template.id,
      template.defaultPrimary,
      template.defaultAccent,
      `Handpicked ${template.niche} Deals You Will Actually Use`,
      tagline,
      user.email,
      now,
      now
    );

    const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(storeId);
    return NextResponse.json({ store }, { status: 201 });
  } catch (err) {
    console.error('Create store error:', err);
    return NextResponse.json({ error: 'Failed to create store.' }, { status: 500 });
  }
}
