import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { createId, getDb, persistDbToCloud } from '@/lib/db';
import { checkRateLimit } from '@/lib/rate-limit';
import { extractJsonObject, generateWithFreeAi } from '@/lib/ai-provider';
import { SocialPlatform, SocialPost, Store } from '@/lib/types';

export const runtime = 'nodejs';

const ALL_PLATFORMS: SocialPlatform[] = [
  'instagram',
  'facebook',
  'tiktok',
  'pinterest',
  'youtube_shorts',
  'x',
  'threads',
];

const VIDEO_PLATFORMS = new Set<SocialPlatform>(['tiktok', 'instagram', 'youtube_shorts']);

const PLATFORM_META: Record<
  SocialPlatform,
  { label: string; src: string; creativeStyle: string; needsVideo: boolean }
> = {
  instagram: {
    label: 'Instagram',
    src: 'instagram',
    creativeStyle: 'Clean lifestyle carousel or 15s aesthetic Reel on a bright tabletop',
    needsVideo: true,
  },
  facebook: {
    label: 'Facebook',
    src: 'facebook',
    creativeStyle: 'Problem-vs-solution product graphic with price callout badge',
    needsVideo: false,
  },
  tiktok: {
    label: 'TikTok',
    src: 'tiktok',
    creativeStyle: 'Fast-cut 20s POV demo video starting with a relatable everyday hook',
    needsVideo: true,
  },
  pinterest: {
    label: 'Pinterest',
    src: 'pinterest',
    creativeStyle: 'Vertical 2:3 clean pin featuring product photo + bold serif headline overlay',
    needsVideo: false,
  },
  youtube_shorts: {
    label: 'YouTube Shorts',
    src: 'youtube',
    creativeStyle: '25s crisp vertical mini-review highlighting 3 real buyer benefits',
    needsVideo: true,
  },
  x: {
    label: 'X',
    src: 'x',
    creativeStyle: 'Minimalist single product photo with concise punchy value breakdown',
    needsVideo: false,
  },
  threads: {
    label: 'Threads',
    src: 'threads',
    creativeStyle: 'Casual, conversational recommendation photo that invites replies',
    needsVideo: false,
  },
};

const DAILY_ANGLES = [
  'Everyday Problem Solver',
  'Honest Mini-Review',
  'Best Value Under Budget',
  '3 Reasons Buyers Love It',
  'Morning / Daily Routine Upgrade',
  'Gift-Worthy Smart Find',
  'Before vs. After Time-Saver',
  'Most-Asked Buyer Question Answered',
  'Minimalist Setup Essential',
  'Why It Beats Pricier Alternatives',
  'Quick 15-Second Hands-On Look',
  'Top Curated Pick This Week',
  'Real-Life Convenience Test',
  'Small Upgrade, Big Daily Difference',
  'Weekend Deal Spotlight',
];

interface ProductRow {
  id: string;
  title: string;
  slug: string;
  category: string;
  price_display: string;
  original_price: string;
  image_url: string;
  short_description: string;
  benefits: string;
  merchant_name: string;
  badge: string;
}

interface AiIdeaSlot {
  creative_idea: string;
  caption: string;
  hashtags: string;
  cta: string;
  video_script: string;
}

async function authorizeStore(storeId: string) {
  const user = await getCurrentUser();
  if (!user) {
    return { error: NextResponse.json({ error: 'Unauthorized' }, { status: 401 }) };
  }
  const db = getDb();
  const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(storeId) as Store | undefined;
  if (!store || (store.user_id !== user.id && user.role !== 'admin')) {
    return { error: NextResponse.json({ error: 'Forbidden' }, { status: 403 }) };
  }
  return { user, db, store: { ...store } };
}

function addDaysIso(startDate: Date, offsetDays: number): string {
  const d = new Date(startDate);
  d.setDate(d.getDate() + offsetDays);
  return d.toISOString().slice(0, 10);
}

function buildFallbackSlot(
  product: ProductRow,
  platform: SocialPlatform,
  angle: string,
  storeName: string,
  link: string
): AiIdeaSlot {
  const meta = PLATFORM_META[platform];
  let benefits: string[] = [];
  try {
    benefits = JSON.parse(product.benefits || '[]');
  } catch {}
  const b1 = benefits[0] || product.short_description || 'Practical everyday time-saver';
  const b2 = benefits[1] || 'Compact, clean design built for daily use';
  const b3 = benefits[2] || `Direct official checkout via ${product.merchant_name || 'Merchant'}`;
  const catTag = (product.category || 'deals').toLowerCase().replace(/[^a-z0-9]/g, '');

  const creative_idea = `${meta.creativeStyle} — Angle: ${angle}. Spotlight "${product.title}" (${product.price_display || 'Live Deal'}) with crisp natural lighting and clear text overlay highlighting: "${b1}".`;

  const caption =
    platform === 'x'
      ? `${angle}: ${product.title} (${product.price_display || 'Check Deal'}). ${b1}. Worth checking out on ${product.merchant_name} — link below. (Affiliate link)`
      : platform === 'threads'
        ? `Honest find from ${storeName}: ${product.title} (${product.price_display || 'Live Price'}). What stands out most is ${b1.toLowerCase()}. Would you use this daily? Full details & official link below. (Disclosure: affiliate link)`
        : `${angle} — Meet the ${product.title} (${product.price_display || 'Check Live Price'}).\n\n${product.short_description || b1}\n\nKey highlights:\n• ${b1}\n• ${b2}\n• ${b3}\n\nCheck current availability and official pricing via ${storeName}. (Affiliate disclosure: We may earn a small commission at no extra cost to you.)`;

  const hashtags = `#${catTag || 'smartfinds'} #${(product.merchant_name || 'amazon').toLowerCase().replace(/[^a-z0-9]/g, '')}finds #usefulgadgets #curateddeals #linkaisle #${platform === 'youtube_shorts' ? 'shorts' : platform}`;

  const cta =
    platform === 'pinterest'
      ? `Save this pin & tap the link to check today's live price on ${product.merchant_name}: ${link}`
      : platform === 'tiktok' || platform === 'instagram'
        ? `Tap the link in bio or visit ${link} to check the live deal on ${product.merchant_name}!`
        : `Check full product specs & live deal on ${product.merchant_name}: ${link}`;

  const video_script = meta.needsVideo
    ? `[0-3s HOOK] "If you want a smarter ${product.category.toLowerCase()} upgrade under ${product.price_display || 'budget'}, look at this."\n[3-15s DEMO] "This is the ${product.title}. First, ${b1}. Second, ${b2}. Third, ${b3}."\n[15-22s CTA] "I saved the direct official link inside ${storeName} — check the link to see today's live price!"`
    : '';

  return { creative_idea, caption, hashtags, cta, video_script };
}

export async function GET(
  _req: NextRequest,
  context: { params: Promise<{ storeId: string }> }
) {
  const { storeId } = await context.params;
  const auth = await authorizeStore(storeId);
  if ('error' in auth) return auth.error;

  const rows = auth.db
    .prepare(
      `SELECT * FROM social_posts
       WHERE store_id = ?
       ORDER BY scheduled_date ASC, day_number ASC, created_at DESC`
    )
    .all(storeId) as unknown as SocialPost[];

  return NextResponse.json({ posts: rows.map((r) => ({ ...r })) });
}

export async function POST(
  req: NextRequest,
  context: { params: Promise<{ storeId: string }> }
) {
  const { storeId } = await context.params;
  const auth = await authorizeStore(storeId);
  if ('error' in auth) return auth.error;

  const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'local';
  const rl = checkRateLimit(`social-gen:${auth.user.id}:${ip}`, 20, 60_000);
  if (!rl.allowed) {
    return NextResponse.json(
      { error: 'Too many generation requests. Please wait a minute and try again.' },
      { status: 429 }
    );
  }

  try {
    const body = await req.json();
    const mode: 'daily' | '7day' | '30day' =
      body.mode === '30day' ? '30day' : body.mode === '7day' ? '7day' : 'daily';
    const replaceExisting = Boolean(body.replaceExisting);

    const requestedPlatforms: SocialPlatform[] = Array.isArray(body.platforms)
      ? body.platforms.filter((p: string): p is SocialPlatform =>
          ALL_PLATFORMS.includes(p as SocialPlatform)
        )
      : [];
    const platforms = requestedPlatforms.length > 0 ? requestedPlatforms : ALL_PLATFORMS;

    const requestedIds: string[] = Array.isArray(body.productIds)
      ? body.productIds.map((x: unknown) => String(x)).filter(Boolean)
      : [];

    const allProducts = auth.db
      .prepare(
        `SELECT id, title, slug, category, price_display, original_price, image_url, short_description, benefits, merchant_name, badge
         FROM products
         WHERE store_id = ? AND status = 'published'
         ORDER BY is_featured DESC, created_at DESC`
      )
      .all(storeId) as unknown as ProductRow[];

    const selectedProducts =
      requestedIds.length > 0
        ? allProducts.filter((p) => requestedIds.includes(p.id))
        : allProducts;

    if (selectedProducts.length === 0) {
      return NextResponse.json(
        { error: 'Please publish at least one product in your store before generating social posts.' },
        { status: 400 }
      );
    }

    const totalDays = mode === '30day' ? 30 : mode === '7day' ? 7 : 1;
    const siteOrigin = (
      process.env.NEXT_PUBLIC_SITE_URL ||
      req.nextUrl.origin ||
      'https://linkaisle.netlify.app'
    ).replace(/\/$/, '');

    // Determine rotation & date offset so repeated 1-click daily generations rotate cleanly across products & platforms
    const existingStats = auth.db
      .prepare('SELECT COUNT(*) as cnt, MAX(day_number) as max_day FROM social_posts WHERE store_id = ?')
      .get(storeId) as { cnt: number; max_day: number | null };
    const existingCount = Number(existingStats?.cnt || 0);
    const baseDayNumber = replaceExisting && mode !== 'daily' ? 0 : Number(existingStats?.max_day || 0);
    const rotationOffset = mode === 'daily' ? existingCount : replaceExisting ? 0 : existingCount;

    // Build deterministic schedule plan (rotates cleanly across products & selected platforms)
    const today = new Date();
    const schedulePlan = Array.from({ length: totalDays }, (_, idx) => {
      const rot = rotationOffset + idx;
      const product = selectedProducts[rot % selectedProducts.length];
      const platform = platforms[rot % platforms.length];
      const angle = DAILY_ANGLES[rot % DAILY_ANGLES.length];
      const scheduledDate = mode === 'daily' ? addDaysIso(today, 0) : addDaysIso(today, idx);
      const affiliateLink = `${siteOrigin}/s/${auth.store.slug}/p/${product.slug}?src=${PLATFORM_META[platform].src}`;
      return {
        dayNumber: baseDayNumber + idx + 1,
        scheduledDate,
        product,
        platform,
        angle,
        affiliateLink,
      };
    });

    // Generate fresh AI posts in ONE fast batched Cloud AI call (max 7 unique rich templates for 7/30-day, or 1 for daily)
    const aiBatchCount = Math.min(totalDays, 7);
    const aiBatchSpec = schedulePlan.slice(0, aiBatchCount).map((s) => ({
      day: s.dayNumber,
      platform: PLATFORM_META[s.platform].label,
      needsVideoScript: VIDEO_PLATFORMS.has(s.platform),
      angle: s.angle,
      productTitle: s.product.title,
      category: s.product.category,
      price: s.product.price_display || 'Check live price',
      merchant: s.product.merchant_name || 'Amazon',
      pitch: s.product.short_description || '',
      link: s.affiliateLink,
    }));

    const aiResponse = await generateWithFreeAi({
      systemPrompt:
        'You are an expert affiliate social media strategist for LinkAisle. Write fresh, high-converting, SEO-friendly promotional posts tailored to each platform. Never make fake income or medical promises, and keep a natural brief affiliate disclosure. Return ONLY valid JSON in the exact format: { "items": [ { "creative_idea": "...", "caption": "...", "hashtags": "#tag1 #tag2 ...", "cta": "...", "video_script": "..." } ] }. Include a punchy 15-25s video_script (Hook / Demo / CTA) whenever needsVideoScript is true, otherwise empty string "".',
      userPrompt: `Store Name: ${auth.store.name}\nGenerate exactly ${aiBatchCount} distinct social media post object(s) matching these slots in order:\n${JSON.stringify(
        aiBatchSpec,
        null,
        2
      )}`,
      fallback: () =>
        JSON.stringify({
          items: schedulePlan
            .slice(0, aiBatchCount)
            .map((s) => buildFallbackSlot(s.product, s.platform, s.angle, auth.store.name, s.affiliateLink)),
        }),
    });

    const parsedAi = extractJsonObject<{ items?: Partial<AiIdeaSlot>[] }>(aiResponse.text);
    const aiItems = Array.isArray(parsedAi?.items) ? parsedAi.items : [];

    if (replaceExisting && mode !== 'daily') {
      auth.db.prepare('DELETE FROM social_posts WHERE store_id = ?').run(storeId);
    }

    const now = new Date().toISOString();
    const insertStmt = auth.db.prepare(
      `INSERT INTO social_posts (
        id, store_id, product_id, day_number, scheduled_date, platform,
        creative_idea, caption, hashtags, cta, affiliate_link, video_script,
        image_url, product_title, status, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'scheduled', ?, ?)`
    );

    const createdPosts: SocialPost[] = [];

    for (let i = 0; i < schedulePlan.length; i++) {
      const slot = schedulePlan[i];
      const fallback = buildFallbackSlot(
        slot.product,
        slot.platform,
        slot.angle,
        auth.store.name,
        slot.affiliateLink
      );

      // Use direct AI item for days 1..7; for days 8..30 blend fresh product/platform-specific fallback + week variation
      const aiSlot = i < aiItems.length ? aiItems[i] : null;
      const weekNum = Math.floor(i / 7) + 1;
      const weekLead =
        weekNum === 1
          ? ''
          : weekNum === 2
            ? 'Week 2 Spotlight — '
            : weekNum === 3
              ? 'Trending Curated Pick — '
              : weekNum === 4
                ? 'Monthly Favorite — '
                : 'Bonus Deal Pick — ';

      const creative_idea =
        (aiSlot?.creative_idea && String(aiSlot.creative_idea).trim()) ||
        `${weekLead}${fallback.creative_idea}`;
      const caption =
        (aiSlot?.caption && String(aiSlot.caption).trim()) ||
        `${weekLead}${fallback.caption}`;
      const hashtags =
        (aiSlot?.hashtags && String(aiSlot.hashtags).trim()) || fallback.hashtags;
      const cta = (aiSlot?.cta && String(aiSlot.cta).trim()) || fallback.cta;
      const video_script = VIDEO_PLATFORMS.has(slot.platform)
        ? (aiSlot?.video_script && String(aiSlot.video_script).trim()) || fallback.video_script
        : (aiSlot?.video_script && String(aiSlot.video_script).trim()) || '';

      const id = createId('soc');
      insertStmt.run(
        id,
        storeId,
        slot.product.id,
        slot.dayNumber,
        slot.scheduledDate,
        slot.platform,
        creative_idea,
        caption,
        hashtags,
        cta,
        slot.affiliateLink,
        video_script,
        slot.product.image_url || '',
        slot.product.title,
        now,
        now
      );

      createdPosts.push({
        id,
        store_id: storeId,
        product_id: slot.product.id,
        day_number: slot.dayNumber,
        scheduled_date: slot.scheduledDate,
        platform: slot.platform,
        creative_idea,
        caption,
        hashtags,
        cta,
        affiliate_link: slot.affiliateLink,
        video_script,
        image_url: slot.product.image_url || '',
        product_title: slot.product.title,
        status: 'scheduled',
        created_at: now,
        updated_at: now,
      });
    }

    await persistDbToCloud();

    return NextResponse.json(
      {
        createdCount: createdPosts.length,
        posts: createdPosts,
        providerLabel: aiResponse.providerLabel,
        usedCloudAi: aiResponse.usedCloudAi,
      },
      { status: 201 }
    );
  } catch (err) {
    console.error('Social posts generation error:', err);
    return NextResponse.json({ error: 'Failed to generate social media posts.' }, { status: 500 });
  }
}

export async function PATCH(
  req: NextRequest,
  context: { params: Promise<{ storeId: string }> }
) {
  const { storeId } = await context.params;
  const auth = await authorizeStore(storeId);
  if ('error' in auth) return auth.error;

  try {
    const body = await req.json();
    const id = String(body.id || '').trim();
    if (!id) return NextResponse.json({ error: 'Post ID is required.' }, { status: 400 });

    const existing = auth.db
      .prepare('SELECT * FROM social_posts WHERE id = ? AND store_id = ?')
      .get(id, storeId) as SocialPost | undefined;
    if (!existing) return NextResponse.json({ error: 'Post not found.' }, { status: 404 });

    const nextPlatform = ALL_PLATFORMS.includes(body.platform)
      ? (body.platform as SocialPlatform)
      : existing.platform;
    const nextStatus =
      body.status === 'posted' || body.status === 'draft' || body.status === 'scheduled'
        ? body.status
        : existing.status;

    const now = new Date().toISOString();
    auth.db
      .prepare(
        `UPDATE social_posts
         SET platform = ?, scheduled_date = ?, creative_idea = ?, caption = ?,
             hashtags = ?, cta = ?, affiliate_link = ?, video_script = ?,
             status = ?, updated_at = ?
         WHERE id = ? AND store_id = ?`
      )
      .run(
        nextPlatform,
        body.scheduled_date !== undefined ? String(body.scheduled_date).trim() : existing.scheduled_date,
        body.creative_idea !== undefined ? String(body.creative_idea).trim() : existing.creative_idea,
        body.caption !== undefined ? String(body.caption).trim() : existing.caption,
        body.hashtags !== undefined ? String(body.hashtags).trim() : existing.hashtags,
        body.cta !== undefined ? String(body.cta).trim() : existing.cta,
        body.affiliate_link !== undefined ? String(body.affiliate_link).trim() : existing.affiliate_link,
        body.video_script !== undefined ? String(body.video_script).trim() : existing.video_script,
        nextStatus,
        now,
        id,
        storeId
      );

    const updated = auth.db
      .prepare('SELECT * FROM social_posts WHERE id = ? AND store_id = ?')
      .get(id, storeId) as unknown as SocialPost;

    await persistDbToCloud();
    return NextResponse.json({ post: { ...updated } });
  } catch {
    return NextResponse.json({ error: 'Failed to update social post.' }, { status: 500 });
  }
}

export async function DELETE(
  req: NextRequest,
  context: { params: Promise<{ storeId: string }> }
) {
  const { storeId } = await context.params;
  const auth = await authorizeStore(storeId);
  if ('error' in auth) return auth.error;

  const id = req.nextUrl.searchParams.get('id');
  const clearAll = req.nextUrl.searchParams.get('clearAll') === 'true';

  if (clearAll) {
    auth.db.prepare('DELETE FROM social_posts WHERE store_id = ?').run(storeId);
  } else if (id) {
    auth.db.prepare('DELETE FROM social_posts WHERE id = ? AND store_id = ?').run(id, storeId);
  } else {
    return NextResponse.json({ error: 'Provide id or clearAll=true.' }, { status: 400 });
  }

  await persistDbToCloud();
  return NextResponse.json({ ok: true });
}
