import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { getDb, persistDbToCloud } from '@/lib/db';
import { Store } from '@/lib/types';

export const runtime = 'nodejs';

export async function PATCH(
  req: NextRequest,
  context: { params: Promise<{ storeId: string; postId: string }> }
) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { storeId, postId } = await context.params;
  const db = getDb();
  const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(storeId) as Store | undefined;
  if (!store || (store.user_id !== user.id && user.role !== 'admin')) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const existing = db
    .prepare('SELECT * FROM blog_posts WHERE id = ? AND store_id = ?')
    .get(postId, storeId) as Record<string, unknown> | undefined;

  if (!existing) {
    return NextResponse.json({ error: 'Post not found' }, { status: 404 });
  }

  try {
    const body = await req.json();
    const now = new Date().toISOString();

    db.prepare(
      `UPDATE blog_posts SET
        title = ?, excerpt = ?, content = ?, cover_image = ?, category = ?,
        seo_title = ?, seo_description = ?, featured_product_ids = ?, status = ?, updated_at = ?
       WHERE id = ? AND store_id = ?`
    ).run(
      body.title !== undefined ? String(body.title).trim() : String(existing.title),
      body.excerpt !== undefined ? String(body.excerpt).trim() : String(existing.excerpt),
      body.content !== undefined ? String(body.content).trim() : String(existing.content),
      body.cover_image !== undefined ? String(body.cover_image).trim() : String(existing.cover_image),
      body.category !== undefined ? String(body.category).trim() : String(existing.category),
      body.seo_title !== undefined ? String(body.seo_title).trim() : String(existing.seo_title),
      body.seo_description !== undefined ? String(body.seo_description).trim() : String(existing.seo_description),
      body.featured_product_ids !== undefined
        ? JSON.stringify(Array.isArray(body.featured_product_ids) ? body.featured_product_ids : [])
        : String(existing.featured_product_ids),
      body.status !== undefined ? (body.status === 'draft' ? 'draft' : 'published') : String(existing.status),
      now,
      postId,
      storeId
    );

    const updated = db.prepare('SELECT * FROM blog_posts WHERE id = ?').get(postId) as Record<string, unknown> & {
      featured_product_ids: string;
    };

    await persistDbToCloud();
    return NextResponse.json({
      post: { ...updated, featured_product_ids: JSON.parse(updated.featured_product_ids || '[]') },
    });
  } catch (err) {
    console.error('Update post error:', err);
    return NextResponse.json({ error: 'Failed to update post.' }, { status: 500 });
  }
}

export async function DELETE(
  _req: NextRequest,
  context: { params: Promise<{ storeId: string; postId: string }> }
) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { storeId, postId } = await context.params;
  const db = getDb();
  const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(storeId) as Store | undefined;
  if (!store || (store.user_id !== user.id && user.role !== 'admin')) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  db.prepare('DELETE FROM blog_posts WHERE id = ? AND store_id = ?').run(postId, storeId);
  await persistDbToCloud();
  return NextResponse.json({ ok: true });
}
