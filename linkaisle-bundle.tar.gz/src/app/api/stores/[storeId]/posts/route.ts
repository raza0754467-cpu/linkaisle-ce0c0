import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { createId, getDb, getPlatformSettings, slugify } from '@/lib/db';
import { Store } from '@/lib/types';

export const runtime = 'nodejs';

export async function GET(_req: NextRequest, context: { params: Promise<{ storeId: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { storeId } = await context.params;
  const db = getDb();
  const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(storeId) as Store | undefined;
  if (!store || (store.user_id !== user.id && user.role !== 'admin')) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const rows = db
    .prepare('SELECT * FROM blog_posts WHERE store_id = ? ORDER BY created_at DESC')
    .all(storeId) as (Record<string, unknown> & { featured_product_ids: string })[];

  const posts = rows.map((r) => ({
    ...r,
    featured_product_ids: (() => {
      try {
        return JSON.parse(r.featured_product_ids || '[]');
      } catch {
        return [];
      }
    })(),
  }));

  return NextResponse.json({ posts });
}

export async function POST(req: NextRequest, context: { params: Promise<{ storeId: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { storeId } = await context.params;
  const db = getDb();
  const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(storeId) as Store | undefined;
  if (!store || (store.user_id !== user.id && user.role !== 'admin')) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const settings = getPlatformSettings();
  const limit = settings.plan_limits[user.plan];
  const countRow = db
    .prepare(
      `SELECT COUNT(*) as count FROM blog_posts b
       JOIN stores s ON s.id = b.store_id
       WHERE s.user_id = ?`
    )
    .get(user.id) as { count: number };

  if (user.role !== 'admin' && countRow.count >= limit.maxPosts) {
    return NextResponse.json(
      { error: `Your ${limit.label} plan allows up to ${limit.maxPosts} blog posts.` },
      { status: 403 }
    );
  }

  try {
    const body = await req.json();
    const title = String(body.title || '').trim();
    if (!title || title.length < 3) {
      return NextResponse.json({ error: 'Article title must be at least 3 characters.' }, { status: 400 });
    }

    const id = createId('pst');
    const slug = `${slugify(title)}-${id.slice(-4)}`;
    const featuredIds = Array.isArray(body.featured_product_ids) ? body.featured_product_ids : [];
    const now = new Date().toISOString();

    db.prepare(
      `INSERT INTO blog_posts (
        id, store_id, title, slug, excerpt, content, cover_image, category,
        seo_title, seo_description, featured_product_ids, status, views, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)`
    ).run(
      id,
      storeId,
      title,
      slug,
      String(body.excerpt || '').trim(),
      String(body.content || '').trim(),
      String(body.cover_image || '').trim(),
      String(body.category || 'Guides').trim() || 'Guides',
      String(body.seo_title || title).trim(),
      String(body.seo_description || body.excerpt || '').trim(),
      JSON.stringify(featuredIds),
      body.status === 'draft' ? 'draft' : 'published',
      now,
      now
    );

    const row = db.prepare('SELECT * FROM blog_posts WHERE id = ?').get(id) as Record<string, unknown> & {
      featured_product_ids: string;
    };

    return NextResponse.json(
      { post: { ...row, featured_product_ids: JSON.parse(row.featured_product_ids || '[]') } },
      { status: 201 }
    );
  } catch (err) {
    console.error('Create post error:', err);
    return NextResponse.json({ error: 'Failed to create blog post.' }, { status: 500 });
  }
}
