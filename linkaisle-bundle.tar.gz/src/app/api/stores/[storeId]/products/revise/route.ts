import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { getDb } from '@/lib/db';
import { Store } from '@/lib/types';
import { generateWithFreeAi } from '@/lib/ai-provider';

export const runtime = 'nodejs';

const AFFILIATE_PATTERNS = [
  /tag=/i,
  /amzn\.to/i,
  /impact\.com/i,
  /sjv\.io/i,
  /pxf\.io/i,
  /evyy\.net/i,
  /ref=/i,
  /aff/i,
  /partner/i,
  /clickbank/i,
  /digistore24/i,
  /daraz\./i,
  /utm_/i,
];

interface RawProductRow {
  id: string;
  title: string;
  price_display: string;
  original_price: string;
  image_url: string;
  short_description: string;
  description: string;
  benefits: string;
  available_countries: string;
  affiliate_url: string;
  merchant_name: string;
}

function computeQualityAndSuggestions(p: RawProductRow) {
  let score = 0;
  const suggestions: string[] = [];

  if (p.title && p.title.length >= 12) score += 15;
  else suggestions.push('Use a clearer descriptive title (12+ chars).');

  if (p.image_url && /^(\/uploads\/|https?:\/\/)/i.test(p.image_url)) score += 15;
  else suggestions.push('Add a clean product image.');

  if (p.price_display && /\d/.test(p.price_display)) score += 15;
  else suggestions.push('Add a clear display price.');

  if (p.description && p.description.length >= 50) score += 15;
  else suggestions.push('Expand description with real buyer details.');

  let benefits: string[] = [];
  try {
    benefits = JSON.parse(p.benefits || '[]');
  } catch {}
  if (benefits.length >= 3) score += 15;
  else suggestions.push('Add at least 3 key buyer benefits.');

  let countries: string[] = [];
  try {
    countries = JSON.parse(p.available_countries || '[]');
  } catch {}
  if (countries.length >= 1) score += 10;
  else suggestions.push('Set available shipping countries.');

  const hasTag = AFFILIATE_PATTERNS.some((rx) => rx.test(p.affiliate_url || ''));
  if (hasTag) score += 15;
  else suggestions.push('Add your affiliate tracking tag (e.g. ?tag=yourid-20 or amzn.to) so commissions track.');

  return { score: Math.min(100, score), hasTag, suggestions };
}

async function inspectLiveLink(url: string, currentPrice: string): Promise<{
  status: 'verified' | 'needs_review' | 'unreachable';
  note: string;
  detectedPrice: string | null;
}> {
  try {
    const parsed = new URL(url);
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
      return { status: 'unreachable', note: 'Invalid URL protocol.', detectedPrice: null };
    }

    const host = parsed.hostname.toLowerCase();
    const isAmazon = host.includes('amazon.') || host.includes('amzn.');

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 4500);
    let res: Response;
    try {
      res = await fetch(url, {
        method: 'GET',
        redirect: 'follow',
        signal: controller.signal,
        headers: {
          'User-Agent': 'Mozilla/5.0 (compatible; LinkAisleReviser/1.0)',
          Accept: 'text/html,application/xhtml+xml',
        },
      });
    } finally {
      clearTimeout(timer);
    }

    if (res.status >= 400 && res.status < 500 && res.status !== 403 && res.status !== 429) {
      return {
        status: 'unreachable',
        note: `Merchant returned HTTP ${res.status} — product link may be expired.`,
        detectedPrice: null,
      };
    }

    // Respect anti-bot responses honestly without bypassing
    if (res.status === 403 || res.status === 429 || res.status === 503) {
      return {
        status: 'needs_review',
        note: isAmazon
          ? 'Link reachable. For automatic live Amazon price sync, connect official Amazon PA-API credentials or confirm price manually.'
          : `Merchant rate-limited automated check (HTTP ${res.status}) — verify price manually.`,
        detectedPrice: null,
      };
    }

    const html = (await res.text()).slice(0, 60000);
    const priceMatch =
      html.match(/property=["']product:price:amount["']\s+content=["']([0-9.,]+)["']/i) ||
      html.match(/"price"\s*:\s*"?([0-9]+(?:\.[0-9]{1,2})?)"?/i);

    if (priceMatch && priceMatch[1]) {
      const detected = priceMatch[1];
      const curNumeric = (currentPrice || '').replace(/[^0-9.]/g, '');
      if (curNumeric && Math.abs(parseFloat(curNumeric) - parseFloat(detected)) > 0.5) {
        return {
          status: 'needs_review',
          note: `Price difference detected: merchant metadata shows ${detected} vs listed ${currentPrice}. Review and update price.`,
          detectedPrice: detected,
        };
      }
      return {
        status: 'verified',
        note: `Link live & price verified against merchant metadata (${detected}).`,
        detectedPrice: detected,
      };
    }

    return {
      status: isAmazon ? 'needs_review' : 'verified',
      note: isAmazon
        ? 'Amazon link is active. Add Amazon PA-API keys for automated exact price sync, or verify listed price periodically.'
        : 'Merchant page is reachable (HTTP 200). No public structured price tag exposed.',
      detectedPrice: null,
    };
  } catch {
    return {
      status: 'needs_review',
      note: 'Could not reach merchant within 4.5s (network restriction or timeout) — verify link manually.',
      detectedPrice: null,
    };
  }
}

export async function POST(
  req: NextRequest,
  context: { params: Promise<{ storeId: string }> }
) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { storeId } = await context.params;
  const db = getDb();
  const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(storeId) as Store | undefined;
  if (!store || (store.user_id !== user.id && user.role !== 'admin')) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  try {
    const body = await req.json().catch(() => ({}));
    const productId = body.productId ? String(body.productId) : null;

    const rows = (
      productId
        ? db.prepare('SELECT * FROM products WHERE store_id = ? AND id = ?').all(storeId, productId)
        : db.prepare('SELECT * FROM products WHERE store_id = ?').all(storeId)
    ) as unknown as RawProductRow[];

    if (!rows.length) {
      return NextResponse.json({ error: 'No products found to revise.' }, { status: 404 });
    }

    const now = new Date().toISOString();
    const updateStmt = db.prepare(
      `UPDATE products
       SET last_checked_at = ?, price_status = ?, last_price_note = ?, quality_score = ?, updated_at = ?
       WHERE id = ? AND store_id = ?`
    );

    const results = [];
    for (const p of rows.slice(0, 25)) {
      const audit = computeQualityAndSuggestions(p);
      const liveCheck = await inspectLiveLink(p.affiliate_url, p.price_display);
      const note =
        audit.suggestions.length > 0
          ? `${liveCheck.note} Tip: ${audit.suggestions[0]}`
          : liveCheck.note;

      updateStmt.run(now, liveCheck.status, note, audit.score, now, p.id, storeId);

      results.push({
        productId: p.id,
        title: p.title,
        price_status: liveCheck.status,
        quality_score: audit.score,
        hasAffiliateTag: audit.hasTag,
        note,
        suggestions: audit.suggestions,
        last_checked_at: now,
      });
    }

    const summaryLines = results
      .slice(0, 8)
      .map((r) => `- ${r.title}: score ${r.quality_score}/100, status=${r.price_status}, tag=${r.hasAffiliateTag}`)
      .join('\n');

    const aiAudit = await generateWithFreeAi({
      systemPrompt:
        'You are a concise affiliate storefront conversion & listing quality advisor. Give 2 crisp, practical sentences of actionable advice based on the audit results. Never fabricate metrics.',
      userPrompt: `Store: ${store.name}\nAudited ${results.length} product(s):\n${summaryLines}`,
      fallback: () =>
        `Audited ${results.length} product(s). Replace any demo or untagged URLs with your approved Amazon/Impact affiliate links so every outbound click tracks commissions accurately.`,
    });

    return NextResponse.json({
      revisedCount: results.length,
      aiMode: aiAudit.provider,
      aiProviderLabel: aiAudit.providerLabel,
      aiSummary: aiAudit.text,
      results,
    });
  } catch (err) {
    console.error('Revise error:', err);
    return NextResponse.json({ error: 'Failed to revise products.' }, { status: 500 });
  }
}
