import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { getDb } from '@/lib/db';
import { Store } from '@/lib/types';

export const runtime = 'nodejs';

function isValidHttpUrl(str: string): boolean {
  try {
    const u = new URL(str);
    return u.protocol === 'http:' || u.protocol === 'https:';
  } catch {
    return false;
  }
}

export async function PATCH(
  req: NextRequest,
  context: { params: Promise<{ storeId: string; productId: string }> }
) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { storeId, productId } = await context.params;
  const db = getDb();
  const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(storeId) as Store | undefined;
  if (!store || (store.user_id !== user.id && user.role !== 'admin')) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const existing = db
    .prepare('SELECT * FROM products WHERE id = ? AND store_id = ?')
    .get(productId, storeId) as Record<string, unknown> | undefined;

  if (!existing) {
    return NextResponse.json({ error: 'Product not found' }, { status: 404 });
  }

  try {
    const body = await req.json();
    const affiliateUrl =
      body.affiliate_url !== undefined ? String(body.affiliate_url).trim() : String(existing.affiliate_url);

    if (!isValidHttpUrl(affiliateUrl)) {
      return NextResponse.json({ error: 'Affiliate link must be a valid http:// or https:// URL.' }, { status: 400 });
    }

    let benefitsJson = String(existing.benefits || '[]');
    if (body.benefits !== undefined) {
      const arr = Array.isArray(body.benefits)
        ? body.benefits.map((b: unknown) => String(b).trim()).filter(Boolean)
        : String(body.benefits || '')
            .split('\n')
            .map((b) => b.trim())
            .filter(Boolean);
      benefitsJson = JSON.stringify(arr);
    }

    let countriesJson = String(existing.available_countries || '["US"]');
    if (body.available_countries !== undefined) {
      const arr = Array.isArray(body.available_countries)
        ? body.available_countries.map((c: unknown) => String(c).trim().toUpperCase()).filter(Boolean)
        : ['US'];
      countriesJson = JSON.stringify(arr.length ? arr : ['US']);
    }

    const now = new Date().toISOString();

    db.prepare(
      `UPDATE products SET
        title = ?, category = ?, price_display = ?, original_price = ?,
        image_url = ?, short_description = ?, description = ?, benefits = ?, available_countries = ?,
        affiliate_url = ?, merchant_name = ?, badge = ?, is_featured = ?,
        status = ?, updated_at = ?
       WHERE id = ? AND store_id = ?`
    ).run(
      body.title !== undefined ? String(body.title).trim() : String(existing.title),
      body.category !== undefined ? String(body.category).trim() : String(existing.category),
      body.price_display !== undefined ? String(body.price_display).trim() : String(existing.price_display),
      body.original_price !== undefined ? String(body.original_price).trim() : String(existing.original_price),
      body.image_url !== undefined ? String(body.image_url).trim() : String(existing.image_url),
      body.short_description !== undefined ? String(body.short_description).trim() : String(existing.short_description),
      body.description !== undefined ? String(body.description).trim() : String(existing.description),
      benefitsJson,
      countriesJson,
      affiliateUrl,
      body.merchant_name !== undefined ? String(body.merchant_name).trim() : String(existing.merchant_name),
      body.badge !== undefined ? String(body.badge).trim() : String(existing.badge),
      body.is_featured !== undefined ? (body.is_featured ? 1 : 0) : Number(existing.is_featured),
      body.status !== undefined ? (body.status === 'draft' ? 'draft' : 'published') : String(existing.status),
      now,
      productId,
      storeId
    );

    const updated = db.prepare('SELECT * FROM products WHERE id = ?').get(productId) as Record<string, unknown> & {
      benefits: string;
      available_countries?: string;
    };
    return NextResponse.json({
      product: {
        ...updated,
        benefits: JSON.parse(updated.benefits || '[]'),
        available_countries: JSON.parse(updated.available_countries || '["US"]'),
      },
    });
  } catch (err) {
    console.error('Update product error:', err);
    return NextResponse.json({ error: 'Failed to update product.' }, { status: 500 });
  }
}

export async function DELETE(
  _req: NextRequest,
  context: { params: Promise<{ storeId: string; productId: string }> }
) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { storeId, productId } = await context.params;
  const db = getDb();
  const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(storeId) as Store | undefined;
  if (!store || (store.user_id !== user.id && user.role !== 'admin')) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  db.prepare('DELETE FROM products WHERE id = ? AND store_id = ?').run(productId, storeId);
  return NextResponse.json({ ok: true });
}
