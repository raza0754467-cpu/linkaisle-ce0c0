import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { createId, getDb, getPlatformSettings, persistDbToCloud, slugify } from '@/lib/db';
import { Store } from '@/lib/types';

export const runtime = 'nodejs';

function parseCsvLine(line: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (ch === ',' && !inQuotes) {
      result.push(current.trim());
      current = '';
    } else {
      current += ch;
    }
  }
  result.push(current.trim());
  return result;
}

function isValidHttpUrl(str: string): boolean {
  try {
    const u = new URL(str);
    return u.protocol === 'http:' || u.protocol === 'https:';
  } catch {
    return false;
  }
}

export async function POST(
  req: NextRequest,
  context: { params: Promise<{ storeId: string }> }
) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { storeId } = await context.params;
  const db = getDb();
  const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(storeId) as Store | undefined;
  if (!store || (store.user_id !== user.id && user.role !== 'admin')) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  try {
    const body = await req.json();
    const csvText = String(body.csv || '').trim();
    if (!csvText) {
      return NextResponse.json({ error: 'CSV content is empty.' }, { status: 400 });
    }

    const lines = csvText
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter(Boolean);

    if (lines.length < 2) {
      return NextResponse.json(
        { error: 'CSV must include a header row and at least one product row.' },
        { status: 400 }
      );
    }

    const headers = parseCsvLine(lines[0]).map((h) => h.toLowerCase().replace(/\s+/g, '_'));
    const idx = (name: string) => headers.indexOf(name);

    const titleIdx = idx('title');
    const urlIdx = idx('affiliate_url');
    if (titleIdx === -1 || urlIdx === -1) {
      return NextResponse.json(
        { error: 'CSV headers must include at least "title" and "affiliate_url".' },
        { status: 400 }
      );
    }

    const settings = getPlatformSettings();
    const limit = settings.plan_limits[user.plan];
    const existingCount = (
      db
        .prepare(
          `SELECT COUNT(*) as count FROM products p
           JOIN stores s ON s.id = p.store_id
           WHERE s.user_id = ?`
        )
        .get(user.id) as { count: number }
    ).count;

    const remainingSlots =
      user.role === 'admin' ? 500 : Math.max(0, limit.maxProducts - existingCount);

    if (remainingSlots === 0) {
      return NextResponse.json(
        { error: `Plan limit reached (${limit.maxProducts} products). Upgrade to import more.` },
        { status: 403 }
      );
    }

    const insert = db.prepare(
      `INSERT INTO products (
        id, store_id, title, slug, category, price_display, original_price,
        image_url, short_description, description, benefits, affiliate_url,
        merchant_name, badge, is_featured, status, impressions, clicks, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'published', 0, 0, ?, ?)`
    );

    const now = new Date().toISOString();
    let imported = 0;
    const errors: string[] = [];

    for (let r = 1; r < lines.length; r++) {
      if (imported >= remainingSlots) {
        errors.push(`Stopped at row ${r + 1}: plan quota (${limit.maxProducts}) reached.`);
        break;
      }

      const cols = parseCsvLine(lines[r]);
      const title = cols[titleIdx] || '';
      const affiliateUrl = cols[urlIdx] || '';

      if (!title || !isValidHttpUrl(affiliateUrl)) {
        errors.push(`Row ${r + 1} skipped: missing title or invalid affiliate_url.`);
        continue;
      }

      const id = createId('prd');
      const slug = `${slugify(title)}-${id.slice(-4)}`;
      const getVal = (name: string, fallback = '') => {
        const i = idx(name);
        return i >= 0 && cols[i] ? cols[i] : fallback;
      };

      const benefitsRaw = getVal('benefits', '');
      const benefits = benefitsRaw
        .split('|')
        .map((b) => b.trim())
        .filter(Boolean);

      insert.run(
        id,
        storeId,
        title,
        slug,
        getVal('category', 'General'),
        getVal('price_display', ''),
        getVal('original_price', ''),
        getVal('image_url', ''),
        getVal('short_description', ''),
        getVal('description', getVal('short_description', '')),
        JSON.stringify(benefits),
        affiliateUrl,
        getVal('merchant_name', 'Amazon'),
        getVal('badge', ''),
        getVal('is_featured', '').toLowerCase() === 'true' ? 1 : 0,
        now,
        now
      );
      imported++;
    }

    if (imported > 0) {
      await persistDbToCloud();
    }
    return NextResponse.json({ imported, skipped: errors.length, errors });
  } catch (err) {
    console.error('Bulk import error:', err);
    return NextResponse.json({ error: 'Failed to import CSV.' }, { status: 500 });
  }
}
