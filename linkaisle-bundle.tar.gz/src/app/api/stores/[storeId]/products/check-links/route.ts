import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { getDb } from '@/lib/db';
import { Store } from '@/lib/types';

export const runtime = 'nodejs';

const AFFILIATE_PATTERNS = [
  /tag=/i,
  /amzn\.to/i,
  /impact\.com/i,
  /sjv\.io/i,
  /pxf\.io/i,
  /evyy\.net/i,
  /ref=/i,
  /aff/i,
  /partner/i,
  /clickbank/i,
  /digistore24/i,
  /daraz\./i,
  /utm_/i,
  /subid/i,
];

export async function POST(
  _req: NextRequest,
  context: { params: Promise<{ storeId: string }> }
) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { storeId } = await context.params;
  const db = getDb();
  const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(storeId) as Store | undefined;
  if (!store || (store.user_id !== user.id && user.role !== 'admin')) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const products = db
    .prepare('SELECT id, title, affiliate_url, merchant_name FROM products WHERE store_id = ?')
    .all(storeId) as unknown as {
    id: string;
    title: string;
    affiliate_url: string;
    merchant_name: string;
  }[];

  const report = products.map((p) => {
    try {
      const parsed = new URL(p.affiliate_url);
      const isHttps = parsed.protocol === 'https:';
      const hasAffiliateTag = AFFILIATE_PATTERNS.some((rx) => rx.test(p.affiliate_url));

      if (!isHttps) {
        return {
          productId: p.id,
          title: p.title,
          status: 'warning' as const,
          note: 'Uses HTTP instead of HTTPS — switch to https:// for buyer trust.',
        };
      }
      if (!hasAffiliateTag) {
        return {
          productId: p.id,
          title: p.title,
          status: 'plain' as const,
          note: 'Valid URL, but no affiliate tag detected (e.g. ?tag= or amzn.to) — verify you get commission!',
        };
      }
      return {
        productId: p.id,
        title: p.title,
        status: 'healthy' as const,
        note: 'HTTPS & affiliate tracking pattern detected.',
      };
    } catch {
      return {
        productId: p.id,
        title: p.title,
        status: 'broken' as const,
        note: 'Invalid URL format — visitors cannot open this link.',
      };
    }
  });

  const summary = {
    total: report.length,
    healthy: report.filter((r) => r.status === 'healthy').length,
    plain: report.filter((r) => r.status === 'plain').length,
    warnings: report.filter((r) => r.status === 'warning' || r.status === 'broken').length,
  };

  return NextResponse.json({ summary, report });
}
