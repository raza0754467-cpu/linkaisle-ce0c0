import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { createId, getDb, getPlatformSettings, persistDbToCloud, slugify } from '@/lib/db';
import { Store } from '@/lib/types';

export const runtime = 'nodejs';

function isValidHttpUrl(str: string): boolean {
  try {
    const u = new URL(str);
    return u.protocol === 'http:' || u.protocol === 'https:';
  } catch {
    return false;
  }
}

export async function GET(_req: NextRequest, context: { params: Promise<{ storeId: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { storeId } = await context.params;
  const db = getDb();
  const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(storeId) as Store | undefined;
  if (!store || (store.user_id !== user.id && user.role !== 'admin')) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const rows = db
    .prepare('SELECT * FROM products WHERE store_id = ? ORDER BY created_at DESC')
    .all(storeId) as (Record<string, unknown> & { benefits: string; available_countries?: string })[];

  const products = rows.map((r) => ({
    ...r,
    benefits: (() => {
      try {
        return JSON.parse(r.benefits || '[]');
      } catch {
        return [];
      }
    })(),
    available_countries: (() => {
      try {
        const parsed = JSON.parse(r.available_countries || '["US"]');
        return Array.isArray(parsed) && parsed.length ? parsed : ['US'];
      } catch {
        return ['US'];
      }
    })(),
  }));

  return NextResponse.json({ products });
}

export async function POST(req: NextRequest, context: { params: Promise<{ storeId: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { storeId } = await context.params;
  const db = getDb();
  const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(storeId) as Store | undefined;
  if (!store || (store.user_id !== user.id && user.role !== 'admin')) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const settings = getPlatformSettings();
  const limit = settings.plan_limits[user.plan];
  const countRow = db
    .prepare(
      `SELECT COUNT(*) as count FROM products p
       JOIN stores s ON s.id = p.store_id
       WHERE s.user_id = ?`
    )
    .get(user.id) as { count: number };

  if (user.role !== 'admin' && countRow.count >= limit.maxProducts) {
    return NextResponse.json(
      { error: `Your ${limit.label} plan allows up to ${limit.maxProducts} products. Upgrade for more.` },
      { status: 403 }
    );
  }

  try {
    const body = await req.json();
    const title = String(body.title || '').trim();
    const affiliateUrl = String(body.affiliate_url || '').trim();

    if (!title || title.length < 2) {
      return NextResponse.json({ error: 'Product title is required.' }, { status: 400 });
    }
    if (!affiliateUrl || !isValidHttpUrl(affiliateUrl)) {
      return NextResponse.json(
        { error: 'Please enter a valid http:// or https:// affiliate link.' },
        { status: 400 }
      );
    }

    const id = createId('prd');
    const slug = `${slugify(title)}-${id.slice(-4)}`;
    const benefitsArr: string[] = Array.isArray(body.benefits)
      ? body.benefits.map((b: unknown) => String(b).trim()).filter(Boolean)
      : String(body.benefits || '')
          .split('\n')
          .map((b) => b.trim())
          .filter(Boolean);

    const countriesArr: string[] = Array.isArray(body.available_countries) && body.available_countries.length
      ? body.available_countries.map((c: unknown) => String(c).trim().toUpperCase()).filter(Boolean)
      : [store.target_country || 'US'];

    const now = new Date().toISOString();

    db.prepare(
      `INSERT INTO products (
        id, store_id, title, slug, category, price_display, original_price,
        image_url, short_description, description, benefits, available_countries, affiliate_url,
        merchant_name, badge, is_featured, status, impressions, clicks, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, ?, ?)`
    ).run(
      id,
      storeId,
      title,
      slug,
      String(body.category || 'General').trim() || 'General',
      String(body.price_display || '').trim(),
      String(body.original_price || '').trim(),
      String(body.image_url || '').trim(),
      String(body.short_description || '').trim(),
      String(body.description || '').trim(),
      JSON.stringify(benefitsArr),
      JSON.stringify(countriesArr),
      affiliateUrl,
      String(body.merchant_name || 'Amazon').trim() || 'Amazon',
      String(body.badge || '').trim(),
      body.is_featured ? 1 : 0,
      body.status === 'draft' ? 'draft' : 'published',
      now,
      now
    );

    const row = db.prepare('SELECT * FROM products WHERE id = ?').get(id) as Record<string, unknown> & {
      benefits: string;
      available_countries?: string;
    };
    await persistDbToCloud();

    return NextResponse.json(
      {
        product: {
          ...row,
          benefits: JSON.parse(row.benefits || '[]'),
          available_countries: JSON.parse(row.available_countries || '["US"]'),
        },
      },
      { status: 201 }
    );
  } catch (err) {
    console.error('Create product error:', err);
    return NextResponse.json({ error: 'Failed to create product.' }, { status: 500 });
  }
}
