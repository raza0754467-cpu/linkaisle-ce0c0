import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { getDb } from '@/lib/db';
import { getStoreAnalytics } from '@/lib/analytics';
import { Store } from '@/lib/types';

export const runtime = 'nodejs';

export async function GET(_req: NextRequest, context: { params: Promise<{ storeId: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { storeId } = await context.params;
  const db = getDb();
  const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(storeId) as Store | undefined;
  if (!store || (store.user_id !== user.id && user.role !== 'admin')) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const analytics = getStoreAnalytics(storeId);
  return NextResponse.json(analytics);
}
