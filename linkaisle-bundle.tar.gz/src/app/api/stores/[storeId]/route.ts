import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { getDb, persistDbToCloud, slugify } from '@/lib/db';
import { Store } from '@/lib/types';

export const runtime = 'nodejs';

async function getAuthorizedStore(storeId: string) {
  const user = await getCurrentUser();
  if (!user) return { error: NextResponse.json({ error: 'Unauthorized' }, { status: 401 }) };

  const db = getDb();
  const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(storeId) as Store | undefined;
  if (!store) return { error: NextResponse.json({ error: 'Store not found' }, { status: 404 }) };
  if (store.user_id !== user.id && user.role !== 'admin') {
    return { error: NextResponse.json({ error: 'Forbidden' }, { status: 403 }) };
  }
  return { user, store, db };
}

export async function GET(_req: NextRequest, context: { params: Promise<{ storeId: string }> }) {
  const { storeId } = await context.params;
  const auth = await getAuthorizedStore(storeId);
  if ('error' in auth) return auth.error;
  return NextResponse.json({ store: auth.store });
}

export async function PATCH(req: NextRequest, context: { params: Promise<{ storeId: string }> }) {
  const { storeId } = await context.params;
  const auth = await getAuthorizedStore(storeId);
  if ('error' in auth) return auth.error;

  try {
    const body = await req.json();
    const { store, db } = auth;

    let nextSlug = store.slug;
    if (body.slug !== undefined && String(body.slug).trim() !== store.slug) {
      nextSlug = slugify(String(body.slug));
      const existing = db
        .prepare('SELECT id FROM stores WHERE slug = ? AND id != ?')
        .get(nextSlug, store.id);
      if (existing) {
        return NextResponse.json({ error: `URL "/s/${nextSlug}" is already taken.` }, { status: 409 });
      }
    }

    const validTemplates = ['kitchen', 'tech', 'beauty', 'pets', 'minimal'];
    const nextTemplate =
      body.template && validTemplates.includes(String(body.template))
        ? String(body.template)
        : store.template;

    const now = new Date().toISOString();

    db.prepare(
      `UPDATE stores SET
        slug = ?, name = ?, tagline = ?, description = ?, template = ?,
        primary_color = ?, accent_color = ?, logo_url = ?,
        hero_title = ?, hero_subtitle = ?, hero_cta = ?,
        disclosure_text = ?, contact_email = ?,
        social_tiktok = ?, social_instagram = ?, social_youtube = ?, social_facebook = ?,
        target_country = ?, currency = ?,
        is_published = ?, updated_at = ?
       WHERE id = ?`
    ).run(
      nextSlug,
      body.name !== undefined ? String(body.name).trim() : store.name,
      body.tagline !== undefined ? String(body.tagline).trim() : store.tagline,
      body.description !== undefined ? String(body.description).trim() : store.description,
      nextTemplate,
      body.primary_color !== undefined ? String(body.primary_color).trim() : store.primary_color,
      body.accent_color !== undefined ? String(body.accent_color).trim() : store.accent_color,
      body.logo_url !== undefined ? String(body.logo_url).trim() : store.logo_url,
      body.hero_title !== undefined ? String(body.hero_title).trim() : store.hero_title,
      body.hero_subtitle !== undefined ? String(body.hero_subtitle).trim() : store.hero_subtitle,
      body.hero_cta !== undefined ? String(body.hero_cta).trim() : store.hero_cta,
      body.disclosure_text !== undefined ? String(body.disclosure_text).trim() : store.disclosure_text,
      body.contact_email !== undefined ? String(body.contact_email).trim() : store.contact_email,
      body.social_tiktok !== undefined ? String(body.social_tiktok).trim() : store.social_tiktok,
      body.social_instagram !== undefined ? String(body.social_instagram).trim() : store.social_instagram,
      body.social_youtube !== undefined ? String(body.social_youtube).trim() : store.social_youtube,
      body.social_facebook !== undefined ? String(body.social_facebook).trim() : store.social_facebook,
      body.target_country !== undefined ? String(body.target_country).trim() : store.target_country || 'US',
      body.currency !== undefined ? String(body.currency).trim() : store.currency || 'USD',
      body.is_published !== undefined ? (body.is_published ? 1 : 0) : store.is_published,
      now,
      store.id
    );

    const updated = db.prepare('SELECT * FROM stores WHERE id = ?').get(store.id);
    await persistDbToCloud();
    return NextResponse.json({ store: updated });
  } catch (err) {
    console.error('Update store error:', err);
    return NextResponse.json({ error: 'Failed to update store.' }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, context: { params: Promise<{ storeId: string }> }) {
  const { storeId } = await context.params;
  const auth = await getAuthorizedStore(storeId);
  if ('error' in auth) return auth.error;

  auth.db.prepare('DELETE FROM stores WHERE id = ?').run(storeId);
  await persistDbToCloud();
  return NextResponse.json({ ok: true });
}
