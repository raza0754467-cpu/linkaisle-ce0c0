'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { CheckCircle2, Loader2, ShieldAlert, ShoppingBag } from 'lucide-react';

export default function AuthCallbackPage() {
  const router = useRouter();
  const [status, setStatus] = useState<'verifying' | 'success' | 'error'>('verifying');
  const [message, setMessage] = useState('Verifying your real email address...');

  useEffect(() => {
    const hashParams = new URLSearchParams(window.location.hash.replace(/^#/, ''));
    const queryParams = new URLSearchParams(window.location.search);

    const errDesc = hashParams.get('error_description') || queryParams.get('error_description');
    if (errDesc) {
      setStatus('error');
      setMessage(errDesc);
      return;
    }

    const accessToken = hashParams.get('access_token') || queryParams.get('access_token');
    if (!accessToken) {
      setStatus('error');
      setMessage('Missing verification token. Please click the verification link from your email inbox again.');
      return;
    }

    fetch('/api/auth/supabase-verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ access_token: accessToken }),
    })
      .then(async (res) => {
        const data = await res.json();
        if (!res.ok) {
          setStatus('error');
          setMessage(data.error || 'Could not verify your email.');
          return;
        }
        setStatus('success');
        setMessage('Email verified! Opening your LinkAisle Studio...');
        setTimeout(() => {
          router.push(data.redirectTo || '/dashboard');
          router.refresh();
        }, 900);
      })
      .catch(() => {
        setStatus('error');
        setMessage('Network error during verification. Please try again.');
      });
  }, [router]);

  return (
    <div className="min-h-screen bg-[#FAFAF9] flex items-center justify-center p-6">
      <div className="w-full max-w-md rounded-3xl border border-stone-200 bg-white p-8 text-center shadow-sm">
        <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-[#047857] text-white">
          <ShoppingBag className="h-6 w-6" />
        </div>

        <div className="mt-6">
          {status === 'verifying' && (
            <>
              <Loader2 className="mx-auto h-8 w-8 animate-spin text-[#047857]" />
              <h1 className="mt-4 font-display text-xl font-extrabold text-[#111315]">
                Verifying Your Email
              </h1>
              <p className="mt-2 text-sm text-stone-600">{message}</p>
            </>
          )}

          {status === 'success' && (
            <>
              <CheckCircle2 className="mx-auto h-10 w-10 text-[#047857]" />
              <h1 className="mt-4 font-display text-xl font-extrabold text-[#111315]">
                Email Verified!
              </h1>
              <p className="mt-2 text-sm text-stone-600">{message}</p>
            </>
          )}

          {status === 'error' && (
            <>
              <ShieldAlert className="mx-auto h-10 w-10 text-rose-600" />
              <h1 className="mt-4 font-display text-xl font-extrabold text-[#111315]">
                Verification Failed
              </h1>
              <p className="mt-2 text-sm text-rose-700">{message}</p>
              <div className="mt-6 flex justify-center gap-3">
                <Link
                  href="/register"
                  className="rounded-full bg-[#111315] px-5 py-2.5 text-xs font-bold text-white hover:bg-[#047857]"
                >
                  Back to Register
                </Link>
                <Link
                  href="/login"
                  className="rounded-full border border-stone-300 px-5 py-2.5 text-xs font-bold text-stone-700 hover:bg-stone-50"
                >
                  Sign In
                </Link>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
