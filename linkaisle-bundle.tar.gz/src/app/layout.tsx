import type { Metadata } from 'next';
import './globals.css';
import GoogleAnalytics from '@/components/GoogleAnalytics';
import AiAssistantWidget from '@/components/AiAssistantWidget';

export const metadata: Metadata = {
  title: 'LinkAisle — Build Your Affiliate Product Store in Minutes',
  description:
    'Learn affiliate marketing step-by-step, launch your curated multi-country product storefront for free under LinkAisle, and track visits and outbound clicks from one studio.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="min-h-screen bg-[#FAFAF9] text-[#111315] font-sans">
        <GoogleAnalytics />
        {children}
        <AiAssistantWidget />
      </body>
    </html>
  );
}
