import type { Metadata } from 'next';
import './globals.css';
import GoogleAnalytics from '@/components/GoogleAnalytics';
import AiAssistantWidget from '@/components/AiAssistantWidget';

const siteUrl = (process.env.NEXT_PUBLIC_SITE_URL || 'https://linkaisle.netlify.app').replace(/\/$/, '');

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: 'LinkAisle — Build Your Affiliate Product Store in Minutes',
    template: '%s | LinkAisle',
  },
  description:
    'Launch your curated multi-country affiliate product storefront for free under LinkAisle. Built-in AI listing tools, 5 light storefront themes, real click analytics, and affiliate academy.',
  keywords: [
    'LinkAisle',
    'affiliate storefront builder',
    'free affiliate store',
    'Amazon Associates storefront',
    'Impact affiliate links',
    'curated product store',
    'affiliate marketing platform',
  ],
  openGraph: {
    type: 'website',
    siteName: 'LinkAisle',
    title: 'LinkAisle — Build Your Affiliate Product Store in Minutes',
    description:
      'Bring your Amazon, Impact, and partner affiliate products into one clean storefront under your own LinkAisle link — no domain or coding required.',
    url: siteUrl,
  },
  twitter: {
    card: 'summary_large_image',
    title: 'LinkAisle — Build Your Affiliate Product Store in Minutes',
    description:
      'Launch a curated affiliate product storefront in minutes with AI tools and real click analytics.',
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="min-h-screen bg-[#FAFAF9] text-[#111315] font-sans">
        <GoogleAnalytics />
        {children}
        <AiAssistantWidget />
      </body>
    </html>
  );
}
