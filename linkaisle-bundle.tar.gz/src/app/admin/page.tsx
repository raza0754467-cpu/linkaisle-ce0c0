import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import AdminClient from '@/components/AdminClient';

export const dynamic = 'force-dynamic';

export default async function AdminPage() {
  const user = await getCurrentUser();
  if (!user) redirect('/login');
  if (user.role !== 'admin') redirect('/dashboard');

  return <AdminClient currentUser={user} />;
}
