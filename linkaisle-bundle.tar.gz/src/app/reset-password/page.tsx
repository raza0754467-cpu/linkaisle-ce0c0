'use client';

import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { Suspense, useState } from 'react';
import { CheckCircle2, Lock, ShoppingBag } from 'lucide-react';

function ResetPasswordForm() {
  const searchParams = useSearchParams();
  const token = searchParams.get('token') || '';
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Could not reset password.');
        return;
      }
      setDone(true);
    } catch {
      setError('Network error. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-[#FAFAF9] flex items-center justify-center p-6">
      <div className="w-full max-w-md rounded-3xl border border-stone-200 bg-white p-8 shadow-sm">
        <Link href="/" className="inline-flex items-center gap-2 text-[#111315] font-display font-extrabold">
          <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-[#047857] text-white">
            <ShoppingBag className="h-4 w-4" />
          </span>
          LinkAisle
        </Link>

        <h1 className="mt-6 font-display text-2xl font-extrabold text-[#111315]">
          Set a new password
        </h1>

        {done ? (
          <div className="mt-6 space-y-4">
            <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-xs text-emerald-950 flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-[#047857] shrink-0" />
              Your password has been updated successfully.
            </div>
            <Link
              href="/login"
              className="block w-full rounded-xl bg-[#111315] py-3 text-center text-sm font-bold text-white hover:bg-[#047857] transition-colors"
            >
              Sign In With New Password
            </Link>
          </div>
        ) : !token ? (
          <div className="mt-6 rounded-xl bg-rose-50 border border-rose-200 p-4 text-xs text-rose-700">
            Invalid reset link. Please request a fresh password reset from{' '}
            <Link href="/forgot-password" className="underline font-bold">
              Forgot Password
            </Link>
            .
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="mt-6 space-y-4">
            {error && (
              <div className="rounded-xl bg-rose-50 border border-rose-200 px-4 py-3 text-xs text-rose-700">
                {error}
              </div>
            )}
            <div>
              <label htmlFor="reset-pass" className="block text-xs font-semibold text-stone-700 mb-1.5">
                New Password (min 6 chars)
              </label>
              <div className="relative">
                <Lock className="pointer-events-none absolute left-3.5 top-3 h-4 w-4 text-stone-400" />
                <input
                  id="reset-pass"
                  type="password"
                  required
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full rounded-xl border border-stone-300 bg-white py-2.5 pl-10 pr-4 text-sm focus:border-[#047857] focus:outline-none"
                />
              </div>
            </div>
            <div>
              <label htmlFor="reset-confirm" className="block text-xs font-semibold text-stone-700 mb-1.5">
                Confirm New Password
              </label>
              <div className="relative">
                <Lock className="pointer-events-none absolute left-3.5 top-3 h-4 w-4 text-stone-400" />
                <input
                  id="reset-confirm"
                  type="password"
                  required
                  minLength={6}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full rounded-xl border border-stone-300 bg-white py-2.5 pl-10 pr-4 text-sm focus:border-[#047857] focus:outline-none"
                />
              </div>
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-xl bg-[#111315] py-3 text-sm font-bold text-white hover:bg-[#047857] disabled:opacity-60 transition-colors"
            >
              {loading ? 'Updating...' : 'Update Password'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}

export default function ResetPasswordPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-[#FAFAF9]" />}>
      <ResetPasswordForm />
    </Suspense>
  );
}
