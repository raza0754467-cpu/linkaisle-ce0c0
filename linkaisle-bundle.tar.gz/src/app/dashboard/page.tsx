import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import { getDb, getPlatformSettings } from '@/lib/db';
import { Store } from '@/lib/types';
import DashboardClient from '@/components/DashboardClient';

export const dynamic = 'force-dynamic';

export default async function DashboardPage() {
  const user = await getCurrentUser();
  if (!user) redirect('/login');

  const db = getDb();
  const settings = getPlatformSettings();
  const rawStores = db
    .prepare('SELECT * FROM stores WHERE user_id = ? ORDER BY created_at DESC')
    .all(user.id) as unknown as Store[];
  const stores: Store[] = rawStores.map((s) => ({ ...s }));

  return (
    <DashboardClient
      user={user}
      initialStores={stores}
      planLimit={settings.plan_limits[user.plan]}
      platformName={settings.platform_name}
    />
  );
}
