import type { Metadata } from 'next';
import Link from 'next/link';
import { ArrowRight, CheckCircle2, Eye, Palette, Sparkles } from 'lucide-react';
import { getCurrentUser } from '@/lib/auth';
import { getPlatformSettings } from '@/lib/db';
import { STORE_TEMPLATES } from '@/lib/types';
import Navbar from '@/components/Navbar';

export const dynamic = 'force-dynamic';

export const metadata: Metadata = {
  title: 'Storefront Themes — LinkAisle',
  description:
    'Preview 5 custom-designed affiliate storefront themes live with products, country filters, and tracked deal links.',
};

const THEME_HIGHLIGHTS: Record<string, string[]> = {
  kitchen: [
    'Announcement ribbon + Magazine 3-photo Bento Hero',
    '4-pillar buyer trust bar & Deal of the Week spotlight',
    'Editorial serif typography + Buying Journal section',
  ],
  tech: [
    'Pure white Apple-style hero + floating flagship hardware card',
    'Crisp titanium Bento Highlights strip with clean hover lift',
    '4-column desktop spec cards, discount badges & electric blue CTAs',
  ],
  beauty: [
    'Centered Shopify-Prestige luxury header & serif branding',
    '4-card vertical portrait Lookbook strip + Curator quote',
    '4:5 boutique portrait product grid & Editorial Edit journal',
  ],
  pets: [
    'Vibrant bubble hero with asymmetric floating product showcase',
    'Playful pill category selector + rounded-3xl cards',
    'Bold discount tags, benefit checklists & friendly layout',
  ],
  minimal: [
    'Architectural Swiss split-grid hero with live object index',
    'Razor-sharp 1px bordered catalog with numbered products (01, 02...)',
    'Ultra-fast zero-distraction layout built for maximum CTR',
  ],
};

export default async function TemplatesGalleryPage() {
  const user = await getCurrentUser();
  const settings = getPlatformSettings();

  return (
    <div className="min-h-screen bg-[#FAFAF9]">
      <Navbar user={user} platformName={settings.platform_name} />

      <section className="border-b border-stone-200 bg-[#111315] py-16 text-white">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="inline-flex items-center gap-2 rounded-full bg-emerald-500/15 border border-emerald-400/30 px-3.5 py-1 text-xs font-semibold text-emerald-300">
            <Palette className="h-3.5 w-3.5" />
            5 Custom-Designed Storefront Themes
          </div>
          <h1 className="mt-4 font-display text-3xl font-extrabold sm:text-5xl">
            {settings.platform_name} Theme Store
          </h1>
          <p className="mt-4 max-w-2xl text-stone-300 text-base sm:text-lg">
            Every theme below has its own unique layout, hero design, typography, and product cards — switch anytime in 1 click without losing a single product.
          </p>
        </div>
      </section>

      <main className="mx-auto max-w-6xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-8 md:grid-cols-2">
          {STORE_TEMPLATES.map((tpl) => (
            <div
              key={tpl.id}
              className="flex flex-col overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-soft hover:shadow-xl transition-shadow"
            >
              {/* VISUAL MINI WIREFRAME PREVIEW */}
              <div className={`relative h-52 bg-gradient-to-br ${tpl.previewBg} p-6 flex flex-col justify-between`}>
                <div className="flex items-center justify-between">
                  <span className="rounded-full bg-white/95 px-3 py-1 text-xs font-extrabold text-slate-900 shadow-sm">
                    {tpl.badgeText}
                  </span>
                  <div className="flex items-center gap-2">
                    <span
                      className="h-5 w-5 rounded-full border-2 border-white shadow"
                      style={{ backgroundColor: tpl.defaultPrimary }}
                    />
                    <span
                      className="h-5 w-5 rounded-full border-2 border-white shadow"
                      style={{ backgroundColor: tpl.defaultAccent }}
                    />
                  </div>
                </div>

                <div className="rounded-2xl bg-white/90 backdrop-blur p-4 shadow-lg border border-black/5">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-indigo-600">
                    {tpl.niche}
                  </p>
                  <p className="font-display text-lg font-extrabold text-slate-900">{tpl.name}</p>
                </div>
              </div>

              <div className="flex flex-1 flex-col justify-between p-6">
                <div>
                  <p className="text-sm text-slate-600 leading-relaxed">{tpl.description}</p>
                  <ul className="mt-4 space-y-2">
                    {(THEME_HIGHLIGHTS[tpl.id] || []).map((h, i) => (
                      <li key={i} className="flex items-start gap-2 text-xs text-slate-700">
                        <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{h}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-6 pt-5 border-t border-slate-100 flex flex-wrap gap-3">
                  <Link
                    href={`/s/smart-home-finds?preview=${tpl.id}`}
                    className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-xs font-bold text-slate-800 hover:bg-slate-50"
                  >
                    <Eye className="h-4 w-4 text-indigo-600" />
                    Live Preview Theme
                  </Link>
                  <Link
                    href={user ? '/dashboard' : `/register?template=${tpl.id}`}
                    className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2.5 text-xs font-bold text-white hover:bg-indigo-700"
                  >
                    <Sparkles className="h-4 w-4" />
                    Use This Theme
                    <ArrowRight className="h-3.5 w-3.5" />
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
