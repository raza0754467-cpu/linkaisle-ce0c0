import type { Metadata } from 'next';
import Link from 'next/link';
import { ArrowLeft, FileText } from 'lucide-react';
import Navbar from '@/components/Navbar';
import { getCurrentUser } from '@/lib/auth';
import { getPlatformSettings } from '@/lib/db';

export const dynamic = 'force-dynamic';

export const metadata: Metadata = {
  title: 'Terms of Service — LinkAisle',
  description: 'Terms and conditions governing use of the LinkAisle storefront builder, AI tools, and creator plans.',
};

export default async function TermsPage() {
  const user = await getCurrentUser();
  const settings = getPlatformSettings();

  return (
    <div className="min-h-screen bg-[#FAFAF9] text-[#111315]">
      <Navbar user={user} platformName={settings.platform_name} />
      <main className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8">
        <Link href="/" className="inline-flex items-center gap-1.5 text-xs font-bold text-[#047857] hover:underline">
          <ArrowLeft className="h-3.5 w-3.5" /> Back to LinkAisle
        </Link>

        <article className="mt-6 rounded-3xl border border-stone-200 bg-white p-8 sm:p-10 shadow-sm space-y-6">
          <div className="flex items-center gap-2.5 text-[#047857]">
            <FileText className="h-6 w-6" />
            <span className="text-xs font-bold uppercase tracking-widest">Platform Terms</span>
          </div>
          <h1 className="font-display text-3xl font-extrabold text-[#111315]">Terms of Service</h1>
          <p className="text-xs text-stone-500">Last updated: {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</p>

          <section className="space-y-2 text-sm leading-relaxed text-stone-700">
            <h2 className="font-display text-lg font-bold text-[#111315]">1. Platform Scope</h2>
            <p>
              LinkAisle provides software tools that allow independent creators to build curated affiliate product storefronts, publish SEO buying guides, and track visits and outbound deal clicks. LinkAisle is not a merchant of record and does not process customer product purchases directly.
            </p>
          </section>

          <section className="space-y-2 text-sm leading-relaxed text-stone-700">
            <h2 className="font-display text-lg font-bold text-[#111315]">2. Creator Responsibilities &amp; Compliance</h2>
            <ul className="list-disc pl-5 space-y-1.5">
              <li>You must use a real, verified email address or Google account to register.</li>
              <li>You are solely responsible for the affiliate links, product claims, pricing accuracy, and disclosures published on your storefront, and for complying with third-party affiliate program agreements (such as Amazon Associates and Impact.com).</li>
              <li>Malicious URLs, phishing, counterfeit goods, spam, and fabricated reviews are strictly prohibited and may result in immediate storefront suspension.</li>
            </ul>
          </section>

          <section className="space-y-2 text-sm leading-relaxed text-stone-700">
            <h2 className="font-display text-lg font-bold text-[#111315]">3. Plans &amp; Upgrades</h2>
            <p>
              LinkAisle offers a Free Starter tier ($0/month) alongside optional Starter ($9/month) and Pro ($19/month) plans with expanded store, product, and SEO guide limits. Upgrade requests submitted through Creator Studio are verified and activated by the platform administrator.
            </p>
          </section>

          <section className="space-y-2 text-sm leading-relaxed text-stone-700">
            <h2 className="font-display text-lg font-bold text-[#111315]">4. No Earnings Guarantee</h2>
            <p>
              LinkAisle does not guarantee clicks, conversions, affiliate program approvals, or income. Actual affiliate commissions depend entirely on your niche, content quality, audience trust, and merchant conversion rates.
            </p>
          </section>
        </article>
      </main>
    </div>
  );
}
