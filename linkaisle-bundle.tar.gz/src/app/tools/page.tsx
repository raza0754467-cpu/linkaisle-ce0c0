import type { Metadata } from 'next';
import Link from 'next/link';
import { ExternalLink, Sparkles, Wrench, ShieldCheck, ArrowRight } from 'lucide-react';
import { getCurrentUser } from '@/lib/auth';
import { getDb, getPlatformSettings } from '@/lib/db';
import { PartnerTool } from '@/lib/types';
import Navbar from '@/components/Navbar';

export const dynamic = 'force-dynamic';

export const metadata: Metadata = {
  title: 'Affiliate Networks & Creator Tools — LinkAisle',
  description:
    'Free affiliate networks and video/design tools for LinkAisle store creators — no domain or hosting purchase needed.',
};

export default async function ToolsPage() {
  const user = await getCurrentUser();
  const settings = getPlatformSettings();
  const db = getDb();

  const rawTools = db
    .prepare('SELECT * FROM partner_tools WHERE is_published = 1 ORDER BY category ASC, created_at ASC')
    .all() as unknown as PartnerTool[];

  const tools = rawTools.map((t) => ({ ...t }));
  const grouped = new Map<string, PartnerTool[]>();
  for (const t of tools) {
    const arr = grouped.get(t.category) || [];
    arr.push(t);
    grouped.set(t.category, arr);
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar user={user} platformName={settings.platform_name} />

      <section className="border-b border-stone-200 bg-[#111315] py-14 text-white">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="inline-flex items-center gap-2 rounded-full bg-emerald-500/15 border border-emerald-400/30 px-3.5 py-1 text-xs font-semibold text-emerald-300">
            <Wrench className="h-3.5 w-3.5" />
            Free Affiliate Networks & Video Tools
          </div>
          <h1 className="mt-4 font-display text-3xl font-extrabold sm:text-5xl">
            Affiliate Networks & Creator Tools
          </h1>
          <p className="mt-4 max-w-2xl text-stone-300 text-base sm:text-lg">
            Join free affiliate programs to get your product tracking links and use free video tools to promote your {settings.platform_name} store — no domain or hosting required.
          </p>
        </div>
      </section>

      <main className="mx-auto max-w-6xl px-4 py-12 sm:px-6 lg:px-8 space-y-12">
        {Array.from(grouped.entries()).map(([category, items]) => (
          <section key={category}>
            <h2 className="font-display text-xl font-extrabold text-slate-900 mb-5 flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-indigo-600" />
              {category}
            </h2>
            <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
              {items.map((tool) => (
                <div
                  key={tool.id}
                  className="flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-6 shadow-sm hover:border-indigo-300 hover:shadow-md transition-all"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <h3 className="font-display text-lg font-extrabold text-slate-900">
                        {tool.name}
                      </h3>
                      {tool.badge && (
                        <span className="rounded-full bg-indigo-50 px-2.5 py-0.5 text-[11px] font-bold text-indigo-700">
                          {tool.badge}
                        </span>
                      )}
                    </div>
                    <p className="mt-2 text-sm font-semibold text-slate-700">{tool.tagline}</p>
                    <p className="mt-2 text-xs leading-relaxed text-slate-500">{tool.description}</p>
                  </div>

                  <div className="mt-6 pt-4 border-t border-slate-100">
                    <a
                      href={`/api/tool-go/${tool.id}`}
                      target="_blank"
                      rel="noopener noreferrer sponsored"
                      className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-slate-900 py-2.5 text-xs font-bold text-white hover:bg-indigo-600 transition-colors"
                    >
                      Visit {tool.name}
                      <ExternalLink className="h-3.5 w-3.5" />
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </section>
        ))}

        {/* DISCLOSURE & CTA */}
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-start gap-3 max-w-2xl">
            <ShieldCheck className="h-5 w-5 text-emerald-600 shrink-0 mt-0.5" />
            <p className="text-xs leading-relaxed text-slate-600">
              <strong>Affiliate Partner Disclosure:</strong> Some outbound tool links on this page are
              affiliate partner links managed by the {settings.platform_name} platform owner. If you
              sign up or purchase through these links, the platform may earn a referral commission at
              no extra cost to you — helping keep our free starter plan available.
            </p>
          </div>
          <Link
            href={user ? '/dashboard' : '/register'}
            className="inline-flex items-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2.5 text-xs font-bold text-white hover:bg-indigo-700"
          >
            Open Creator Studio <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>
      </main>
    </div>
  );
}
