import type { MetadataRoute } from 'next';
import { getDb } from '@/lib/db';

export const dynamic = 'force-dynamic';

export default function sitemap(): MetadataRoute.Sitemap {
  const baseUrl = (process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000').replace(/\/$/, '');
  const db = getDb();
  const now = new Date();

  const entries: MetadataRoute.Sitemap = [
    { url: `${baseUrl}/`, lastModified: now, changeFrequency: 'daily', priority: 1.0 },
    { url: `${baseUrl}/templates`, lastModified: now, changeFrequency: 'weekly', priority: 0.9 },
    { url: `${baseUrl}/academy`, lastModified: now, changeFrequency: 'weekly', priority: 0.9 },
    { url: `${baseUrl}/tools`, lastModified: now, changeFrequency: 'weekly', priority: 0.8 },
  ];

  const lessons = db
    .prepare('SELECT slug, created_at FROM academy_lessons WHERE is_published = 1')
    .all() as unknown as { slug: string; created_at: string }[];

  for (const l of lessons) {
    entries.push({
      url: `${baseUrl}/academy/${l.slug}`,
      lastModified: new Date(l.created_at),
      changeFrequency: 'monthly',
      priority: 0.8,
    });
  }

  const stores = db
    .prepare('SELECT id, slug, updated_at FROM stores WHERE is_published = 1 AND is_suspended = 0')
    .all() as unknown as { id: string; slug: string; updated_at: string }[];

  for (const s of stores) {
    entries.push({
      url: `${baseUrl}/s/${s.slug}`,
      lastModified: new Date(s.updated_at),
      changeFrequency: 'daily',
      priority: 0.9,
    });

    const prods = db
      .prepare(`SELECT slug, updated_at FROM products WHERE store_id = ? AND status = 'published'`)
      .all(s.id) as unknown as { slug: string; updated_at: string }[];

    for (const pr of prods) {
      entries.push({
        url: `${baseUrl}/s/${s.slug}/p/${pr.slug}`,
        lastModified: new Date(pr.updated_at),
        changeFrequency: 'daily',
        priority: 0.85,
      });
    }

    const posts = db
      .prepare(`SELECT slug, updated_at FROM blog_posts WHERE store_id = ? AND status = 'published'`)
      .all(s.id) as unknown as { slug: string; updated_at: string }[];

    for (const p of posts) {
      entries.push({
        url: `${baseUrl}/s/${s.slug}/blog/${p.slug}`,
        lastModified: new Date(p.updated_at),
        changeFrequency: 'weekly',
        priority: 0.75,
      });
    }
  }

  return entries;
}
