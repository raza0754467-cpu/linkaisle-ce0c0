'use client';

import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { Suspense, useState } from 'react';
import { ArrowRight, Lock, Mail, ShoppingBag } from 'lucide-react';

function GoogleLogo() {
  return (
    <svg className="h-4 w-4 shrink-0" viewBox="0 0 24 24" aria-hidden="true">
      <path
        fill="#4285F4"
        d="M23.49 12.27c0-.79-.07-1.55-.2-2.27H12v4.3h6.44a5.5 5.5 0 0 1-2.39 3.61v3h3.87c2.26-2.08 3.57-5.15 3.57-8.64Z"
      />
      <path
        fill="#34A853"
        d="M12 24c3.24 0 5.95-1.07 7.93-2.91l-3.87-3c-1.07.72-2.44 1.15-4.06 1.15-3.12 0-5.77-2.11-6.71-4.95H1.29v3.1A12 12 0 0 0 12 24Z"
      />
      <path
        fill="#FBBC05"
        d="M5.29 14.29A7.2 7.2 0 0 1 4.91 12c0-.79.14-1.57.38-2.29V6.61H1.29a12 12 0 0 0 0 10.78l4-3.1Z"
      />
      <path
        fill="#EA4335"
        d="M12 4.76c1.76 0 3.34.61 4.59 1.8l3.44-3.44C17.95 1.19 15.24 0 12 0A12 12 0 0 0 1.29 6.61l4 3.1c.94-2.84 3.59-4.95 6.71-4.95Z"
      />
    </svg>
  );
}

const OAUTH_ERRORS: Record<string, string> = {
  google_not_configured:
    'Google Sign-In is ready — add GOOGLE_CLIENT_ID & GOOGLE_CLIENT_SECRET in your server environment to activate one-click Google login, or sign in with email & password below.',
  google_auth_failed: 'Google sign-in could not be completed. Please try again or use email & password.',
  google_email_unverified: 'Your Google email must be verified to sign in.',
  account_suspended: 'This account has been suspended. Please contact support.',
};

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const oauthErrorKey = searchParams.get('error') || '';

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(OAUTH_ERRORS[oauthErrorKey] || '');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Invalid email or password');
        setLoading(false);
        return;
      }
      if (data.user?.role === 'admin') {
        router.push('/admin');
      } else {
        router.push('/dashboard');
      }
      router.refresh();
    } catch {
      setError('Network error. Please try again.');
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen grid lg:grid-cols-2 bg-[#FAFAF9]">
      {/* LEFT BRAND PANEL */}
      <div className="hidden lg:flex flex-col justify-between bg-[#111315] p-12 text-white">
        <Link href="/" className="flex items-center gap-2.5">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#047857] text-white">
            <ShoppingBag className="h-5 w-5" />
          </div>
          <span className="font-display text-xl font-extrabold">LinkAisle</span>
        </Link>

        <div className="max-w-md">
          <h1 className="font-display text-4xl font-extrabold leading-tight">
            Manage Your Stores, Products &amp; Real Analytics in One Studio.
          </h1>
          <p className="mt-4 text-stone-300 leading-relaxed">
            Sign in to publish curated affiliate deals, write AI-assisted product listings, switch
            storefront themes, and monitor every real visit and outbound click.
          </p>
        </div>

        <p className="text-xs text-stone-400">
          LinkAisle · Built for independent affiliate creators
        </p>
      </div>

      {/* RIGHT SIGN-IN FORM */}
      <div className="flex items-center justify-center p-6 sm:p-12">
        <div className="w-full max-w-md">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-[#047857] font-bold text-sm lg:hidden mb-6"
          >
            <ShoppingBag className="h-4 w-4" /> LinkAisle
          </Link>

          <h2 className="font-display text-2xl font-extrabold text-[#111315]">
            Sign in to your account
          </h2>
          <p className="mt-1.5 text-sm text-stone-500">
            New to LinkAisle?{' '}
            <Link href="/register" className="font-semibold text-[#047857] hover:underline">
              Create a free store
            </Link>
          </p>

          {/* GOOGLE OAUTH BUTTON */}
          <div className="mt-6">
            <a
              href="/api/auth/google"
              className="w-full inline-flex items-center justify-center gap-2.5 rounded-xl border border-stone-300 bg-white px-4 py-3 text-sm font-bold text-[#111315] shadow-sm hover:bg-stone-50 transition-colors"
            >
              <GoogleLogo />
              Continue with Google
            </a>
          </div>

          <div className="my-5 flex items-center gap-3 text-xs text-stone-400">
            <div className="h-px flex-1 bg-stone-200" />
            <span>or sign in with email</span>
            <div className="h-px flex-1 bg-stone-200" />
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div className="rounded-xl bg-rose-50 border border-rose-200 px-4 py-3 text-xs leading-relaxed text-rose-700">
                {error}
              </div>
            )}

            <div>
              <label htmlFor="login-email" className="block text-xs font-semibold text-stone-700 mb-1.5">
                Email Address
              </label>
              <div className="relative">
                <Mail className="pointer-events-none absolute left-3.5 top-3 h-4 w-4 text-stone-400" />
                <input
                  id="login-email"
                  type="email"
                  required
                  autoComplete="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full rounded-xl border border-stone-300 bg-white py-2.5 pl-10 pr-4 text-sm text-[#111315] focus:border-[#047857] focus:outline-none focus:ring-2 focus:ring-emerald-600/20"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label htmlFor="login-password" className="block text-xs font-semibold text-stone-700">
                  Password
                </label>
                <Link
                  href="/forgot-password"
                  className="text-xs font-semibold text-[#047857] hover:underline"
                >
                  Forgot password?
                </Link>
              </div>
              <div className="relative">
                <Lock className="pointer-events-none absolute left-3.5 top-3 h-4 w-4 text-stone-400" />
                <input
                  id="login-password"
                  type="password"
                  required
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="w-full rounded-xl border border-stone-300 bg-white py-2.5 pl-10 pr-4 text-sm text-[#111315] focus:border-[#047857] focus:outline-none focus:ring-2 focus:ring-emerald-600/20"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-[#111315] py-3 text-sm font-bold text-white shadow-sm hover:bg-[#047857] disabled:opacity-60 transition-colors"
            >
              {loading ? 'Signing in...' : 'Sign In'}
              <ArrowRight className="h-4 w-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-[#FAFAF9]" />}>
      <LoginForm />
    </Suspense>
  );
}
