import type { Metadata } from 'next';
import Link from 'next/link';
import { ArrowLeft, Info } from 'lucide-react';
import Navbar from '@/components/Navbar';
import { getCurrentUser } from '@/lib/auth';
import { getPlatformSettings } from '@/lib/db';

export const dynamic = 'force-dynamic';

export const metadata: Metadata = {
  title: 'Affiliate Disclosure — LinkAisle',
  description: 'Transparent FTC-compliant affiliate disclosure explaining how affiliate links and commissions work on LinkAisle.',
};

export default async function DisclosurePage() {
  const user = await getCurrentUser();
  const settings = getPlatformSettings();

  return (
    <div className="min-h-screen bg-[#FAFAF9] text-[#111315]">
      <Navbar user={user} platformName={settings.platform_name} />
      <main className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8">
        <Link href="/" className="inline-flex items-center gap-1.5 text-xs font-bold text-[#047857] hover:underline">
          <ArrowLeft className="h-3.5 w-3.5" /> Back to LinkAisle
        </Link>

        <article className="mt-6 rounded-3xl border border-stone-200 bg-white p-8 sm:p-10 shadow-sm space-y-6">
          <div className="flex items-center gap-2.5 text-[#047857]">
            <Info className="h-6 w-6" />
            <span className="text-xs font-bold uppercase tracking-widest">Transparency Statement</span>
          </div>
          <h1 className="font-display text-3xl font-extrabold text-[#111315]">Affiliate Disclosure</h1>

          <div className="rounded-2xl border border-emerald-200 bg-emerald-50/70 p-5 text-sm leading-relaxed text-emerald-950 font-medium">
            LinkAisle and independent creators hosting storefronts on LinkAisle participate in affiliate marketing programs, including the Amazon Services LLC Associates Program and Impact.com partner programs. When you click an outbound deal link and make a qualifying purchase on a partner merchant&apos;s website, LinkAisle or the storefront creator may earn a small commission at <strong>zero additional cost to you</strong>.
          </div>

          <section className="space-y-2 text-sm leading-relaxed text-stone-700">
            <h2 className="font-display text-lg font-bold text-[#111315]">How External Checkout &amp; Pricing Work</h2>
            <p>
              All product purchases, shipping, taxes, returns, and warranties are handled directly by the official external merchant (such as Amazon or the brand&apos;s official online store). Because merchant prices and stock availability change frequently, displayed prices on LinkAisle are informational — always verify the exact live price on the merchant&apos;s checkout page before ordering.
            </p>
          </section>

          <section className="space-y-2 text-sm leading-relaxed text-stone-700">
            <h2 className="font-display text-lg font-bold text-[#111315]">Editorial Independence &amp; Honest Reviews</h2>
            <p>
              LinkAisle prohibits fabricated reviews and fake urgency tactics. Shopper comments shown on LinkAisle product pages are real community submissions, and Amazon products include direct links to Amazon&apos;s official verified customer reviews page.
            </p>
          </section>
        </article>
      </main>
    </div>
  );
}
