import Link from 'next/link';
import {
  ArrowRight,
  CheckCircle2,
  Globe,
  ShoppingBag,
  Sparkles,
} from 'lucide-react';
import { getCurrentUser } from '@/lib/auth';
import { getDb, getPlatformSettings } from '@/lib/db';
import { formatCountryLabel } from '@/lib/types';
import Navbar from '@/components/Navbar';
import PlatformVisitTracker from '@/components/PlatformVisitTracker';
import {
  FeaturedProductsSection,
  HomepageProduct,
  SimpleWorkflowSection,
} from '@/components/HomeInteractiveShowcase';

export const dynamic = 'force-dynamic';

export default async function HomePage() {
  const user = await getCurrentUser();
  const settings = getPlatformSettings();
  const db = getDb();

  const rawProducts = db
    .prepare(
      `SELECT
        p.id, p.slug, p.title, p.category, p.price_display, p.original_price, p.image_url,
        p.short_description, p.merchant_name, p.badge, p.available_countries,
        s.name as store_name, s.slug as store_slug
       FROM products p
       JOIN stores s ON s.id = p.store_id
       WHERE p.status = 'published' AND s.is_published = 1 AND s.is_suspended = 0
       ORDER BY p.is_featured DESC, p.created_at DESC
       LIMIT 12`
    )
    .all() as unknown as (Omit<HomepageProduct, 'available_countries'> & {
    available_countries?: string;
  })[];

  const homepageProducts: HomepageProduct[] = rawProducts.map((r) => ({
    ...r,
    available_countries: (() => {
      try {
        const parsed = JSON.parse(r.available_countries || '["US"]');
        return Array.isArray(parsed) && parsed.length ? parsed : ['US'];
      } catch {
        return ['US'];
      }
    })(),
  }));

  const heroPicks = homepageProducts.slice(0, 2);
  const plans = settings.plan_limits;

  return (
    <div className="min-h-screen bg-[#FAFAF9] text-[#111315]">
      <PlatformVisitTracker />
      <Navbar user={user} platformName={settings.platform_name} />

      {/* 1. CLEAN WARM-EDITORIAL HERO (SHOPIFY / AESOP INSPIRED) */}
      <section className="relative overflow-hidden border-b border-stone-200/80 bg-[#FAFAF9]">
        <div
          className="pointer-events-none absolute inset-0"
          style={{
            backgroundImage:
              'radial-gradient(ellipse 65% 55% at 75% 20%, rgba(4,120,87,0.09), transparent 70%), radial-gradient(ellipse 50% 45% at 15% 85%, rgba(180,83,9,0.06), transparent 65%)',
          }}
        />
        <div className="relative mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
          <div className="grid items-center gap-12 lg:grid-cols-12">
            {/* LEFT COPY */}
            <div className="lg:col-span-6">
              <span className="inline-flex items-center gap-2 rounded-full border border-emerald-200 bg-emerald-50 px-3.5 py-1 text-xs font-bold text-[#047857]">
                Free Affiliate Storefront Builder
              </span>

              <h1 className="mt-5 font-display text-4xl font-extrabold tracking-tight text-[#111315] sm:text-5xl lg:text-[3.5rem] leading-[1.06]">
                Build your affiliate product store in{' '}
                <span className="text-[#047857]">minutes.</span>
              </h1>

              <p className="mt-5 max-w-xl text-base sm:text-lg leading-relaxed text-stone-600">
                Bring all your Amazon, Impact, and partner affiliate products together in one clean
                storefront under your own <strong>{settings.platform_name}</strong> link — no domain,
                no hosting, and no coding required.
              </p>

              <div className="mt-8 flex flex-wrap items-center gap-3.5">
                <Link
                  href={user ? '/dashboard' : '/register'}
                  className="inline-flex items-center gap-2 rounded-full bg-[#111315] px-7 py-3.5 text-sm font-bold text-white shadow-md hover:bg-[#047857] transition-all"
                >
                  {user ? 'Open My Studio' : 'Create Free Store'}
                  <ArrowRight className="h-4 w-4" />
                </Link>
                <a
                  href="#how-it-works"
                  className="inline-flex items-center gap-2 rounded-full border border-stone-300 bg-white px-6 py-3.5 text-sm font-semibold text-stone-800 hover:bg-stone-50 transition-colors"
                >
                  See How It Works
                </a>
              </div>

              <div className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs font-medium text-stone-500">
                <span className="inline-flex items-center gap-1.5">
                  <CheckCircle2 className="h-4 w-4 text-[#047857]" /> Free store URL included
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <CheckCircle2 className="h-4 w-4 text-[#047857]" /> No domain or coding needed
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <CheckCircle2 className="h-4 w-4 text-[#047857]" /> Country availability tags
                </span>
              </div>
            </div>

            {/* RIGHT: CLEAN EDITORIAL STOREFRONT VISUAL SHOWCASE */}
            <div className="lg:col-span-6">
              <div className="rounded-3xl border border-stone-200/90 bg-white p-5 shadow-xl shadow-stone-900/5">
                <div className="flex items-center justify-between border-b border-stone-100 pb-3.5">
                  <div className="flex items-center gap-2">
                    <span className="h-2.5 w-2.5 rounded-full bg-stone-300" />
                    <span className="h-2.5 w-2.5 rounded-full bg-stone-300" />
                    <span className="h-2.5 w-2.5 rounded-full bg-stone-300" />
                    <span className="ml-2 rounded-full bg-stone-100 px-3 py-0.5 font-mono text-[11px] text-stone-600">
                      linkaisle.com/s/smart-home-finds
                    </span>
                  </div>
                  <Link
                    href="/s/smart-home-finds"
                    className="text-xs font-bold text-[#047857] hover:underline"
                  >
                    Visit Store →
                  </Link>
                </div>

                <div className="mt-5 grid gap-4 sm:grid-cols-2">
                  {heroPicks.map((p) => (
                    <Link
                      key={p.id}
                      href={`/s/${p.store_slug}/p/${p.slug}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="group overflow-hidden rounded-2xl border border-stone-200/80 bg-[#FAFAF9] hover:border-[#047857]/40 transition-all"
                    >
                      <div className="relative aspect-[4/3] overflow-hidden bg-stone-100">
                        {p.image_url ? (
                          <img
                            src={p.image_url}
                            alt={p.title}
                            className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500"
                          />
                        ) : null}
                        {p.badge && (
                          <span className="absolute left-2.5 top-2.5 rounded-full bg-[#111315]/85 px-2.5 py-0.5 text-[10px] font-bold text-white">
                            {p.badge}
                          </span>
                        )}
                      </div>
                      <div className="p-3.5">
                        <p className="text-[11px] font-semibold text-[#047857]">{p.category}</p>
                        <p className="mt-1 font-display text-sm font-bold text-[#111315] line-clamp-1">
                          {p.title}
                        </p>
                        <div className="mt-2.5 flex items-center justify-between">
                          <span className="font-display text-base font-extrabold text-[#111315]">
                            {p.price_display}
                          </span>
                          <span className="inline-flex items-center gap-1 rounded-full bg-white border border-stone-200 px-2 py-0.5 text-[10px] font-semibold text-stone-600">
                            <Globe className="h-2.5 w-2.5" />
                            {formatCountryLabel(p.available_countries[0] || 'US')}
                          </span>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>

                <div className="mt-4 flex flex-wrap items-center justify-between gap-2 rounded-2xl bg-emerald-50/70 border border-emerald-100 px-4 py-3 text-xs">
                  <span className="font-semibold text-emerald-950">
                    Your store link goes live immediately — no domain or hosting required.
                  </span>
                  <Link href="/register" className="font-bold text-[#047857] hover:underline shrink-0">
                    Start Free →
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. SIMPLE 4-STEP WORKFLOW (EN + ROMAN URDU WITH DIRECT LINKS) */}
      <SimpleWorkflowSection isLoggedIn={Boolean(user)} />

      {/* 3. FEATURED PRODUCTS RIGHT ON HOMEPAGE (4 PER ROW) */}
      <FeaturedProductsSection products={homepageProducts} />

      {/* 4. SIMPLE PRICING PLANS */}
      <section id="pricing" className="border-t border-stone-200 bg-white py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#047857]">
            Pricing
          </p>
          <h2 className="mt-2 font-display text-3xl font-extrabold tracking-tight text-[#111315]">
            Start Free. Upgrade Only When You Grow.
          </h2>
          <p className="mt-2.5 text-sm text-stone-600">
            Create your store for $0 with no credit card required.
          </p>
        </div>

        <div className="mt-12 grid gap-6 lg:grid-cols-3">
          {(['free', 'starter', 'pro'] as const).map((planKey) => {
            const tier = plans[planKey];
            const isPopular = planKey === 'starter';
            return (
              <div
                key={planKey}
                className={`relative flex flex-col justify-between rounded-3xl p-8 ${
                  isPopular
                    ? 'border-2 border-[#047857] bg-[#111315] text-white shadow-xl'
                    : 'border border-stone-200 bg-white text-[#111315]'
                }`}
              >
                {isPopular && (
                  <span className="absolute -top-3.5 left-7 rounded-full bg-[#047857] px-3.5 py-1 text-xs font-bold text-white shadow">
                    Most Popular
                  </span>
                )}
                <div>
                  <h3 className="font-display text-xl font-bold">{tier.label}</h3>
                  <div className="mt-4 flex items-baseline gap-1">
                    <span className="font-display text-4xl font-extrabold">${tier.price}</span>
                    <span className={isPopular ? 'text-stone-400 text-sm' : 'text-stone-500 text-sm'}>
                      / month
                    </span>
                  </div>
                  <ul className="mt-6 space-y-3 text-sm">
                    <li className="flex items-center gap-2.5">
                      <CheckCircle2 className={`h-4 w-4 ${isPopular ? 'text-emerald-400' : 'text-[#047857]'}`} />
                      Up to <strong>{tier.maxStores}</strong> storefront(s)
                    </li>
                    <li className="flex items-center gap-2.5">
                      <CheckCircle2 className={`h-4 w-4 ${isPopular ? 'text-emerald-400' : 'text-[#047857]'}`} />
                      Up to <strong>{tier.maxProducts >= 9999 ? 'Unlimited' : tier.maxProducts}</strong> products
                    </li>
                    <li className="flex items-center gap-2.5">
                      <CheckCircle2 className={`h-4 w-4 ${isPopular ? 'text-emerald-400' : 'text-[#047857]'}`} />
                      Up to <strong>{tier.maxPosts >= 9999 ? 'Unlimited' : tier.maxPosts}</strong> buying guides
                    </li>
                    <li className="flex items-center gap-2.5">
                      <CheckCircle2 className={`h-4 w-4 ${isPopular ? 'text-emerald-400' : 'text-[#047857]'}`} />
                      All 5 Custom Themes & Country Filters
                    </li>
                    <li className="flex items-center gap-2.5">
                      <CheckCircle2 className={`h-4 w-4 ${isPopular ? 'text-emerald-400' : 'text-[#047857]'}`} />
                      Analytics Dashboard & Promotion Scripts
                    </li>
                    <li className="flex items-center gap-2.5">
                      <CheckCircle2 className={`h-4 w-4 ${isPopular ? 'text-emerald-400' : 'text-[#047857]'}`} />
                      Full Step-by-Step Affiliate Academy
                    </li>
                  </ul>
                </div>

                <Link
                  href="/register"
                  className={`mt-8 block rounded-full py-3 text-center text-sm font-bold transition-colors ${
                    isPopular
                      ? 'bg-[#047857] text-white hover:bg-[#059669]'
                      : 'bg-[#111315] text-white hover:bg-[#047857]'
                  }`}
                >
                  {planKey === 'free' ? 'Start Free' : `Start Free, Upgrade Later`}
                </Link>
              </div>
            );
          })}
          </div>
        </div>
      </section>

      {/* CLEAN MINIMAL FOOTER */}
      <footer className="border-t border-stone-200 bg-[#111315] text-stone-400">
        <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
          <div className="grid gap-8 md:grid-cols-4">
            <div className="md:col-span-2">
              <div className="flex items-center gap-2 text-white">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#047857]">
                  <ShoppingBag className="h-4 w-4" />
                </div>
                <span className="font-display text-lg font-extrabold">{settings.platform_name}</span>
              </div>
              <p className="mt-3 max-w-md text-xs leading-relaxed text-stone-400">
                Build your curated affiliate product store under {settings.platform_name}. Creators
                provide their own approved affiliate links and remain responsible for program policies
                and disclosures. Results depend on effort, product selection, and traffic.
              </p>
            </div>
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-white">Learn & Build</h4>
              <ul className="mt-3 space-y-2 text-xs">
                <li><Link href="/academy" className="hover:text-white">Affiliate Academy</Link></li>
                <li><Link href="/tools" className="hover:text-white">Affiliate Networks</Link></li>
                <li><Link href="/templates" className="hover:text-white">Store Themes</Link></li>
                <li><Link href="/s/smart-home-finds" className="hover:text-white">Example Store</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-white">Account</h4>
              <ul className="mt-3 space-y-2 text-xs">
                <li><Link href="/register" className="hover:text-white">Create Free Store</Link></li>
                <li><Link href="/login" className="hover:text-white">Sign In</Link></li>
                <li><Link href="/dashboard" className="hover:text-white">Creator Studio</Link></li>
              </ul>
            </div>
          </div>
          <div className="mt-10 border-t border-white/10 pt-6 text-xs text-stone-500 flex flex-wrap justify-between gap-4">
            <p>© {new Date().getFullYear()} {settings.platform_name}. All rights reserved.</p>
            <p className="inline-flex items-center gap-1.5">
              <Sparkles className="h-3.5 w-3.5 text-emerald-500" /> AI-Assisted Creator Tools Ready
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
