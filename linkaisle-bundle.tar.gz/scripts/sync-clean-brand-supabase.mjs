import fs from 'node:fs';
import { DatabaseSync } from 'node:sqlite';

const env = Object.fromEntries(
  fs
    .readFileSync('.env.local', 'utf8')
    .split(/\r?\n/)
    .filter((l) => l && !l.startsWith('#') && l.includes('='))
    .map((l) => {
      const i = l.indexOf('=');
      return [l.slice(0, i).trim(), l.slice(i + 1).trim()];
    })
);

const res = await fetch(`${env.SUPABASE_URL}/storage/v1/object/linkaisle-state/affiliforge.db`, {
  headers: {
    apikey: env.SUPABASE_SERVICE_ROLE_KEY,
    Authorization: `Bearer ${env.SUPABASE_SERVICE_ROLE_KEY}`,
  },
});

const buf = Buffer.from(await res.arrayBuffer());
fs.writeFileSync('data/_supabase_live_check.db', buf);
const db = new DatabaseSync('data/_supabase_live_check.db');
console.log('BEFORE:', db.prepare("SELECT key, value FROM platform_settings WHERE key = 'platform_name'").all());

db.prepare("UPDATE platform_settings SET value = 'LinkAisle' WHERE key = 'platform_name'").run();
db.prepare(
  "UPDATE academy_lessons SET title = REPLACE(title, 'AffiliForge', 'LinkAisle'), summary = REPLACE(summary, 'AffiliForge', 'LinkAisle'), content = REPLACE(content, 'AffiliForge', 'LinkAisle'), title_ur = REPLACE(title_ur, 'AffiliForge', 'LinkAisle'), summary_ur = REPLACE(summary_ur, 'AffiliForge', 'LinkAisle'), content_ur = REPLACE(content_ur, 'AffiliForge', 'LinkAisle')"
).run();

console.log('AFTER:', db.prepare("SELECT key, value FROM platform_settings WHERE key = 'platform_name'").all());
db.close();

const cleanBuf = fs.readFileSync('data/_supabase_live_check.db');
const up = await fetch(`${env.SUPABASE_URL}/storage/v1/object/linkaisle-state/affiliforge.db`, {
  method: 'POST',
  headers: {
    apikey: env.SUPABASE_SERVICE_ROLE_KEY,
    Authorization: `Bearer ${env.SUPABASE_SERVICE_ROLE_KEY}`,
    'Content-Type': 'application/octet-stream',
    'x-upsert': 'true',
  },
  body: cleanBuf,
});
console.log('UPLOAD CLEAN SNAPSHOT:', up.status);
fs.unlinkSync('data/_supabase_live_check.db');
