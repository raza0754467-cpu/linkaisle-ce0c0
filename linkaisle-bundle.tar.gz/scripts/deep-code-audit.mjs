import fs from 'node:fs';
import path from 'node:path';

function walk(dir, list = []) {
  for (const f of fs.readdirSync(dir)) {
    const p = path.join(dir, f);
    if (fs.statSync(p).isDirectory()) walk(p, list);
    else if (p.endsWith('.ts') || p.endsWith('.tsx')) list.push(p);
  }
  return list;
}

const apiFiles = walk('src/app/api');
console.log('=== 1. API MUTATION ROUTES MISSING persistDbToCloud ===');
for (const f of apiFiles) {
  const c = fs.readFileSync(f, 'utf8');
  const hasWrite = /\.run\(|INSERT INTO|UPDATE |DELETE FROM/i.test(c);
  const hasPersist = c.includes('persistDbToCloud');
  if (hasWrite && !hasPersist) {
    console.log('  [MISSING]', f);
  }
}

console.log('\n=== 2. LEFTOVER AffiliForge STRINGS (EXCLUDING INTERNAL DB/SESSION KEYS) ===');
for (const f of walk('src')) {
  const c = fs.readFileSync(f, 'utf8');
  if (/AffiliForge/i.test(c)) {
    const lines = c
      .split('\n')
      .map((l, i) => ({ i: i + 1, l }))
      .filter(
        (x) =>
          /AffiliForge/i.test(x.l) &&
          !/affiliforge\.db|__affiliforgeDb|affiliforge_session/i.test(x.l)
      );
    if (lines.length) {
      console.log(' ', f);
      for (const x of lines) console.log(`    L${x.i}: ${x.l.trim().slice(0, 110)}`);
    }
  }
}

console.log('\n=== 3. CHECKING SQLITE WAL CHECKPOINT BEFORE SNAPSHOT UPLOAD ===');
const dbContent = fs.readFileSync('src/lib/db.ts', 'utf8');
const hasCheckpoint = /wal_checkpoint/i.test(dbContent);
console.log('  Has PRAGMA wal_checkpoint before upload:', hasCheckpoint);

console.log('\n=== 4. CHECKING AUTH/RATE-LIMIT/VALIDATION ON ALL API ROUTES ===');
for (const f of apiFiles) {
  const c = fs.readFileSync(f, 'utf8');
  const hasAuth = /getCurrentUser|requireAdmin|authorizeStore/i.test(c);
  const hasRate = /checkRateLimit/i.test(c);
  const exportsMethods = [...c.matchAll(/export async function (GET|POST|PATCH|PUT|DELETE)/g)].map(
    (m) => m[1]
  );
  console.log(`  ${f.replace(/^src[\\/]/, '')} [${exportsMethods.join(',')}] auth=${hasAuth} rl=${hasRate}`);
}

console.log('\n=== 5. CHECKING HARDCODED LOCALHOST / EXAMPLE / FAKE DATA ===');
for (const f of walk('src')) {
  const c = fs.readFileSync(f, 'utf8');
  const lines = c.split('\n');
  lines.forEach((l, idx) => {
    if (/localhost:3000|127\.0\.0\.1|TODO|FIXME|PLACEHOLDER|demo123/i.test(l)) {
      console.log(`  ${f}:${idx + 1} -> ${l.trim().slice(0, 110)}`);
    }
  });
}
