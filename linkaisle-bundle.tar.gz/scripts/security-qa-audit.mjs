import { DatabaseSync } from 'node:sqlite';

const BASE = 'http://localhost:3000';
const results = [];

function assert(name, condition, detail = '') {
  results.push({ name, pass: Boolean(condition), detail });
  const icon = condition ? 'PASS' : 'FAIL';
  console.log(`[${icon}] ${name}${detail ? ` — ${detail}` : ''}`);
}

async function run() {
  console.log('=== AffiliForge Multi-Tenant Security & API QA Audit ===\n');

  // 1. Security Headers Check
  const homeRes = await fetch(`${BASE}/`);
  assert('Home returns HTTP 200', homeRes.status === 200, `status=${homeRes.status}`);
  assert(
    'Security header X-Content-Type-Options=nosniff',
    homeRes.headers.get('x-content-type-options') === 'nosniff'
  );
  assert(
    'Security header X-Frame-Options=SAMEORIGIN',
    homeRes.headers.get('x-frame-options') === 'SAMEORIGIN'
  );

  // 2. Unauthenticated Protection Checks
  const unauthStores = await fetch(`${BASE}/api/stores`);
  assert('Unauthenticated GET /api/stores blocked (401)', unauthStores.status === 401);

  const unauthBilling = await fetch(`${BASE}/api/billing/requests`);
  assert('Unauthenticated GET /api/billing/requests blocked (401)', unauthBilling.status === 401);

  const unauthAdmin = await fetch(`${BASE}/api/admin/overview`);
  assert('Unauthenticated GET /api/admin/overview blocked (403)', unauthAdmin.status === 403);

  // 3. Register isolated QA User B
  const qaEmail = `qa_isolation_${Date.now()}@affiliforge.local`;
  const regRes = await fetch(`${BASE}/api/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name: 'QA Tenant User B',
      email: qaEmail,
      password: 'QaPassword123!',
      storeName: 'QA Isolated Store',
      template: 'tech',
    }),
  });
  const regJson = await regRes.json();
  const setCookie = regRes.headers.get('set-cookie') || '';
  const cookieHeader = setCookie.split(';')[0];

  assert('Register QA User B succeeds (200)', regRes.status === 200 && Boolean(cookieHeader));

  // Fetch User B's own store
  const bStoresRes = await fetch(`${BASE}/api/stores`, { headers: { Cookie: cookieHeader } });
  const bStoresJson = await bStoresRes.json();
  const userBStoreId = bStoresJson.stores?.[0]?.id;
  assert('QA User B sees ONLY their own store (count=1)', bStoresJson.stores?.length === 1);

  // 4. CRITICAL: Cross-Tenant Isolation Tests (User B attacking Demo User A's store str_demo_001)
  const crossGetStore = await fetch(`${BASE}/api/stores/str_demo_001`, {
    headers: { Cookie: cookieHeader },
  });
  assert('Cross-tenant GET another user store blocked (403)', crossGetStore.status === 403);

  const crossPatchStore = await fetch(`${BASE}/api/stores/str_demo_001`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json', Cookie: cookieHeader },
    body: JSON.stringify({ name: 'HACKED STORE' }),
  });
  assert('Cross-tenant PATCH another user store blocked (403)', crossPatchStore.status === 403);

  const crossDeleteStore = await fetch(`${BASE}/api/stores/str_demo_001`, {
    method: 'DELETE',
    headers: { Cookie: cookieHeader },
  });
  assert('Cross-tenant DELETE another user store blocked (403)', crossDeleteStore.status === 403);

  const crossAddProduct = await fetch(`${BASE}/api/stores/str_demo_001/products`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Cookie: cookieHeader },
    body: JSON.stringify({ title: 'Injected', affiliate_url: 'https://example.com' }),
  });
  assert('Cross-tenant POST product to another store blocked (403)', crossAddProduct.status === 403);

  const crossAnalytics = await fetch(`${BASE}/api/stores/str_demo_001/analytics`, {
    headers: { Cookie: cookieHeader },
  });
  assert('Cross-tenant GET another store analytics blocked (403)', crossAnalytics.status === 403);

  // 5. CRITICAL: Privilege Escalation Checks (User B attempting Admin APIs)
  const privAdminOverview = await fetch(`${BASE}/api/admin/overview`, {
    headers: { Cookie: cookieHeader },
  });
  assert('Non-admin GET /api/admin/overview blocked (403)', privAdminOverview.status === 403);

  const privAdminUsers = await fetch(`${BASE}/api/admin/users`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json', Cookie: cookieHeader },
    body: JSON.stringify({ userId: regJson.user?.id, role: 'admin' }),
  });
  assert('Non-admin privilege escalation PATCH /api/admin/users blocked (403)', privAdminUsers.status === 403);

  // 6. XSS / Dangerous Affiliate URL Rejection Check
  const xssProd = await fetch(`${BASE}/api/stores/${userBStoreId}/products`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Cookie: cookieHeader },
    body: JSON.stringify({ title: 'Bad Link', affiliate_url: 'javascript:alert(1)' }),
  });
  assert('Dangerous javascript: affiliate URL rejected (400)', xssProd.status === 400);

  // 7. Outbound Affiliate Redirect & Real Click Tracking Check
  const db = new DatabaseSync('./data/affiliforge.db');
  const beforeClicks = Number(
    db.prepare('SELECT clicks FROM products WHERE id = ?').get('prd_demo_01').clicks
  );
  const goRes = await fetch(`${BASE}/api/go/prd_demo_01`, { redirect: 'manual' });
  const afterClicks = Number(
    db.prepare('SELECT clicks FROM products WHERE id = ?').get('prd_demo_01').clicks
  );
  assert(
    'Outbound /api/go/prd_demo_01 redirects (302) & increments real click',
    goRes.status === 302 && afterClicks === beforeClicks + 1,
    `status=${goRes.status}, clicks=${beforeClicks}->${afterClicks}`
  );

  // Cleanup QA User B & test click so DB stays clean
  db.prepare('DELETE FROM users WHERE email = ?').run(qaEmail);
  db.prepare('UPDATE products SET clicks = ? WHERE id = ?').run(beforeClicks, 'prd_demo_01');
  db.prepare(
    `DELETE FROM analytics_events WHERE id = (
      SELECT id FROM analytics_events WHERE product_id = 'prd_demo_01' AND event_type = 'product_click' ORDER BY id DESC LIMIT 1
    )`
  ).run();

  const failed = results.filter((r) => !r.pass);
  console.log(`\n=== SUMMARY: ${results.length - failed.length}/${results.length} PASSED ===`);
  if (failed.length > 0) {
    process.exit(1);
  }
}

run().catch((err) => {
  console.error('Audit crashed:', err);
  process.exit(1);
});
