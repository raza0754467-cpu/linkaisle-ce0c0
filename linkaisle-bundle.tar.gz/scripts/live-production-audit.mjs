const BASE = 'https://linkaisle.netlify.app';
const results = [];

function check(name, ok, detail = '') {
  results.push({ name, ok: Boolean(ok) });
  console.log(`${ok ? '[PASS]' : '[FAIL]'} ${name}${detail ? ` — ${detail}` : ''}`);
}

async function run() {
  console.log(`=== LinkAisle Live Production Audit (${BASE}) ===\n`);

  // 1. Speed + Home + Branding
  const t0 = Date.now();
  const homeRes = await fetch(`${BASE}/`);
  const ms = Date.now() - t0;
  const homeHtml = await homeRes.text();
  check('1a. Branding: Zero AffiliForge on Home', !homeHtml.includes('AffiliForge') && homeHtml.includes('LinkAisle'));

  const acHtml = await (await fetch(`${BASE}/academy`)).text();
  check('1b. Branding: Zero AffiliForge on Academy', !acHtml.includes('AffiliForge') && acHtml.includes('LinkAisle'));

  // 2. Affiliate Links Redirect
  const goRes = await fetch(`${BASE}/api/go/prd_demo_01`, { redirect: 'manual' });
  check(
    '2. Affiliate Links: /api/go/prd_demo_01 redirects (302)',
    goRes.status === 302 || goRes.status === 307,
    `status=${goRes.status} -> ${(goRes.headers.get('location') || '').slice(0, 50)}`
  );

  // 3. SEO: Sitemap, Robots, Product JSON-LD, No fake 140+ reviews
  const smRes = await fetch(`${BASE}/sitemap.xml`);
  const smXml = await smRes.text();
  check(
    '3a. SEO: /sitemap.xml includes legal + products',
    smRes.status === 200 && smXml.includes('/privacy') && smXml.includes('/s/smart-home-finds/p/')
  );
  const rbRes = await fetch(`${BASE}/robots.txt`);
  check('3b. SEO: /robots.txt returns 200 OK', rbRes.status === 200);

  const prodHtml = await (await fetch(`${BASE}/s/smart-home-finds/p/precision-digital-kitchen-scale`)).text();
  check(
    '3c. SEO & Honesty: Product JSON-LD present + zero fake 140+ reviews',
    prodHtml.includes('application/ld+json') &&
      prodHtml.includes('schema.org') &&
      !prodHtml.includes('140+ reviews')
  );

  // 4. Speed & Mobile
  check('4. Speed & Mobile: 200 OK + viewport meta', homeRes.status === 200 && homeHtml.includes('viewport'), `${ms}ms`);

  // 5. Security Headers + Auth Guards + Real Google OAuth
  check(
    '5a. Security Headers (nosniff + SAMEORIGIN)',
    homeRes.headers.get('x-content-type-options') === 'nosniff' &&
      homeRes.headers.get('x-frame-options') === 'SAMEORIGIN'
  );
  const [u1, u2, u3] = await Promise.all([
    fetch(`${BASE}/api/stores`),
    fetch(`${BASE}/api/admin/overview`),
    fetch(`${BASE}/api/billing/requests`),
  ]);
  check('5b. Security Auth Guards (401/403/401)', u1.status === 401 && u2.status === 403 && u3.status === 401);

  const gRes = await fetch(`${BASE}/api/auth/google`, { redirect: 'manual' });
  check(
    '5c. Real Google OAuth Redirect (307 -> accounts.google.com)',
    gRes.status === 307 && (gRes.headers.get('location') || '').startsWith('https://accounts.google.com/o/oauth2/v2/auth')
  );

  // 6. Payments ($9 & $19 Plans)
  check('6. Payments: $9 Starter & $19 Pro visible on Home', homeHtml.includes('$9') && homeHtml.includes('$19'));

  // 7. Analytics Live Tracking
  const tr = await fetch(`${BASE}/api/track`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ eventType: 'store_visit', storeId: 'str_demo_01', utmSource: 'audit' }),
  });
  check('7. Analytics: POST /api/track live 200 OK', tr.status === 200);

  // 8. Legal Pages (/privacy, /terms, /disclosure)
  const [p1, p2, p3] = await Promise.all([
    fetch(`${BASE}/privacy`),
    fetch(`${BASE}/terms`),
    fetch(`${BASE}/disclosure`),
  ]);
  check(
    '8. Legal Pages (/privacy, /terms, /disclosure) all 200 OK + Footer links',
    p1.status === 200 &&
      p2.status === 200 &&
      p3.status === 200 &&
      homeHtml.includes('/privacy') &&
      homeHtml.includes('/terms') &&
      homeHtml.includes('/disclosure')
  );

  const passed = results.filter((r) => r.ok).length;
  console.log(`\n=== LIVE PRODUCTION AUDIT SUMMARY: ${passed}/${results.length} PASSED ===`);
  if (passed !== results.length) process.exit(1);
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
