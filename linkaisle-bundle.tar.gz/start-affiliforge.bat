@echo off
title AffiliForge SaaS Platform (Local Server)
set PATH=C:\Users\Mudeer Team 4\OneDrive\Pictures\Gemi\tools\node;%PATH%
cd /d "C:\Users\Mudeer Team 4\OneDrive\Pictures\Gemi\affiliforge"
echo Starting AffiliForge on http://localhost:3000 ...
npm.cmd run start
pause
