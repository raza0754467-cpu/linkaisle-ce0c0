# Free Cloud Deployment Guide (English + Roman Urdu)

When you are ready to take **AffiliForge** live on the public internet from your **personal home laptop or phone**, follow these simple steps (**$0 cost**).

---

## Step 1: Change Default Admin Password First!
Before putting the platform on the public internet:
1. Sign into `/admin` locally or update the seeded `admin@affiliforge.local` credentials.
2. Delete or customize the demo store if you want a clean production start.

---

## Step 2: Set Up Free Database (Supabase — $0/month)
*(Note: Local SQLite works great on a single VPS/server with persistent disk such as Render/Railway/Fly.io. On serverless hosting like Vercel or Cloudflare, use Supabase PostgreSQL so data persists permanently across serverless requests.)*

1. Go to **https://supabase.com** on your personal device → **Start your project** (1-click Google Sign-In).
2. Create a new **Free Plan** project (`affiliforge`).
3. Open **SQL Editor** → paste the entire contents of `deploy/supabase-schema.sql` → click **Run**.
4. Create a public Storage Bucket named `uploads` for store logos & product photos.
5. Copy your `SUPABASE_URL`, `SUPABASE_ANON_KEY`, and `SUPABASE_SERVICE_ROLE_KEY` from **Project Settings → API**.

---

## Step 3: Host the App for Free ($0/month)

### Option A: Single-Container Node Hosting (Keeps SQLite Working Out-of-the-Box!)
Platforms like **Render** (Web Service) or **Fly.io** (with a persistent volume mounted at `/app/data` and `/app/public/uploads`) can run this exact Next.js + `node:sqlite` codebase **without changing a single line of database code!**
- Build command: `npm install && npm run build`
- Start command: `npm run start`
- Environment variable: `NEXT_PUBLIC_SITE_URL=https://your-live-url`

### Option B: Cloudflare Pages / Vercel + Supabase
1. Push the `affiliforge` folder to a free **GitHub** repository from your personal device.
2. Connect that repository to **Cloudflare Pages** (commercial-friendly free tier) or **Vercel** (note: Vercel Hobby free tier is for personal/non-commercial testing).
3. Add environment variables from `.env.example`.

---

## Step 4: Connect Free Google Analytics (GA4)
1. Go to **https://analytics.google.com** → create a free GA4 property.
2. Copy your Measurement ID (`G-XXXXXXXXXX`).
3. Paste it into `NEXT_PUBLIC_GA_MEASUREMENT_ID` in your hosting settings — **AffiliForge automatically activates GA4 across every page!**

---

## Step 5: Custom `.com` Domain & Ad Networks (Later, After First Earnings)
- Start with your free subdomain (e.g. `affiliforge.onrender.com` or `affiliforge.pages.dev`).
- Every user gets an automatic free store link: `your-site/s/username`.
- Once your platform gets real users and first affiliate/subscription earnings, buy a `.com` domain (~$10–$15/year via Namecheap/Cloudflare) and submit your SEO `/sitemap.xml` to **Google Search Console**!
