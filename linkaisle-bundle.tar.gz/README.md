# AffiliForge — Complete Multi-User Affiliate Academy & Storefront Builder SaaS

A complete, 5-step verified multi-tenant SaaS application built with **Next.js 15 (App Router)**, **Tailwind CSS**, **TypeScript**, and **SQLite (`node:sqlite`)** — with a ready-to-run **Supabase PostgreSQL + RLS** migration pack.

## All 5 Completed Build Milestones

### Step 1: Core 7-Module SaaS Engine
- **Main Platform (`/`)** with live database stats, 5 template previews, pricing plans, and interactive Revenue vs. Net Profit Simulator.
- **Multi-User Auth (`/register`, `/login`)** with Scrypt salted password hashing, HTTP-only session cookies, and airtight tenant isolation.
- **Creator Studio (`/dashboard`)**: Store Builder (5 distinct templates + real logo upload), Products CMS (real image upload + draft/publish), SEO Blog with embedded deal cards, and Real Analytics Studio.
- **Public Multi-Tenant Storefronts (`/s/[slug]`, `/s/[slug]/blog/[postSlug]`)** with live search, category filters, Quick-View modal, and tracked outbound redirects (`/api/go/[productId]`).
- **Owner Super Admin Control Panel (`/admin`)** for platform analytics, user plans, store moderation, Academy CMS, and platform settings.

### Step 2: Pro Creator Tools & Bilingual Polish
- **Bilingual Affiliate Academy (`/academy`)** with 1-click **English / Roman Urdu** toggle and lesson completion tracker.
- **Creator Marketing Kit & Viral Script Builder** generating TikTok/Reels/Shorts scripts, Facebook Ad copy, Pinterest SEO pin copy (English + Roman Urdu), and Channel-Tracked UTM links (`?src=tiktok`, `?src=facebook`, etc.).
- **Products CMS Pro Tools**: Bulk CSV Import + Sample CSV Download, Export CSV, 1-Click Duplicate, and Affiliate Link Health Checker.

### Step 3: Owner Monetization Engine
- **Subscription Upgrade Billing** (`Studio -> Billing & Plan` + `Admin -> Billing & Revenue`) supporting Payoneer, Bank Transfer, Easypaisa/JazzCash, and Card references with 1-click Admin approval & real revenue tracking.
- **Owner's Recommended Affiliate Tools Hub (`/tools`)** with real outbound click tracking (`/api/tool-go/[toolId]`) and full Admin CRUD.
- **Admin-Controlled Display Ad / Sponsor Slots** (`Admin -> Partner Tools & Ads`).

### Step 4: Free Cloud, Dynamic SEO & Production Security
- Dynamic **`/sitemap.xml`** & **`/robots.txt`** + per-store and per-article OpenGraph metadata (`generateMetadata`).
- Security headers (`next.config.mjs`), auth rate limiting (`src/lib/rate-limit.ts`), `/api/health`, and automatic GA4 loader (`NEXT_PUBLIC_GA_MEASUREMENT_ID`).
- Cloud migration pack: `deploy/supabase-schema.sql`, `.env.example`, and `deploy/FREE_DEPLOY_GUIDE.md`.

### Step 5: Security Audit, Mobile QA & Launch Playbook
- Automated security & isolation test suite: `node scripts/security-qa-audit.mjs` (17/17 checks).
- Mobile (`390x844`) & desktop responsive QA verified with zero console errors.
- $0 Budget Growth Roadmap: `deploy/LAUNCH_PLAYBOOK.md`.

## Running Locally

Double-click `start-affiliforge.bat` or run:

```powershell
$env:PATH = "C:\Users\Mudeer Team 4\OneDrive\Pictures\Gemi\tools\node;$env:PATH"
npm.cmd run build
npm.cmd run start
```

Open `http://localhost:3000`.

## Seeded Local Demo Accounts
- **Platform Owner (Super Admin):** `admin@affiliforge.local` / `Admin@1234`
- **Demo Creator:** `demo@affiliforge.local` / `Demo@1234`
